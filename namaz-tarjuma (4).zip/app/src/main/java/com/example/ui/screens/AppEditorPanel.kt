package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Mosque
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppCustomization
import com.example.model.AppLanguage
import com.example.model.AppThemePreset
import com.example.ui.ProvideSafeTextToolbar
import com.example.ui.UiStrings
import com.example.ui.rememberDismissTextControls
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.theme.LocalNamazColors
import com.example.ui.theme.RomanFontFamily
import com.example.ui.theme.UrduFontFamily
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
fun LazyListScope.appEditorItems(
    language: AppLanguage,
    strings: UiStrings,
    draftConfig: AppCustomization,
    darkMode: Boolean,
    bigFont: Boolean,
    onUpdateBrandingDraft: (
        schoolNameUr: String,
        schoolNameEn: String,
        appTitleUr: String,
        appTitleEn: String,
        heroSubtitleUr: String,
        heroSubtitleEn: String
    ) -> Unit,
    onSaveBranding: () -> Unit,
    onSelectThemePreset: (AppThemePreset) -> Unit,
    onUpdateFontScale: (Float) -> Unit,
    onToggleDarkMode: () -> Unit,
    onToggleBigFont: () -> Unit,
    onToggleLanguage: () -> Unit,
    onToggleShowPronunciationInBoxes: () -> Unit,
    onToggleShowSecondaryTitle: () -> Unit,
    onUpdateTtsSpeed: (Float) -> Unit,
    onBuildBackupJson: () -> String,
    onShareBackupJson: (String) -> Unit,
    onImportBackupJson: (String) -> Unit,
    onResetAppDefaults: () -> Unit,
    onEmitToast: (String) -> Unit
) {
    // 0. Live Header Preview Card
    item(key = "app_editor_preview") {
        AppEditorLivePreviewCard(
            language = language,
            strings = strings,
            draftConfig = draftConfig
        )
    }

    // 1. Branding Section
    item(key = "app_editor_branding") {
        val extended = LocalNamazColors.current
        val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily
        val dismissTextControls = rememberDismissTextControls()

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = extended.cardSurface),
            border = BorderStroke(1.dp, extended.cardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = strings.appEditorBrandingHeading,
                    fontFamily = uiFont,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = extended.arabicAccent
                )

                OutlinedTextField(
                    value = draftConfig.schoolNameUr,
                    onValueChange = {
                        onUpdateBrandingDraft(
                            it,
                            draftConfig.schoolNameEn,
                            draftConfig.appTitleUr,
                            draftConfig.appTitleEn,
                            draftConfig.heroSubtitleUr,
                            draftConfig.heroSubtitleEn
                        )
                    },
                    label = { Text(strings.appEditorSchoolUr, fontFamily = uiFont) },
                    singleLine = true,
                    shape = RoundedCornerShape(11.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("app_editor_school_ur_input")
                )

                OutlinedTextField(
                    value = draftConfig.schoolNameEn,
                    onValueChange = {
                        onUpdateBrandingDraft(
                            draftConfig.schoolNameUr,
                            it,
                            draftConfig.appTitleUr,
                            draftConfig.appTitleEn,
                            draftConfig.heroSubtitleUr,
                            draftConfig.heroSubtitleEn
                        )
                    },
                    label = { Text(strings.appEditorSchoolEn, fontFamily = uiFont) },
                    singleLine = true,
                    shape = RoundedCornerShape(11.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("app_editor_school_en_input")
                )

                OutlinedTextField(
                    value = draftConfig.appTitleUr,
                    onValueChange = {
                        onUpdateBrandingDraft(
                            draftConfig.schoolNameUr,
                            draftConfig.schoolNameEn,
                            it,
                            draftConfig.appTitleEn,
                            draftConfig.heroSubtitleUr,
                            draftConfig.heroSubtitleEn
                        )
                    },
                    label = { Text(strings.appEditorTitleUr, fontFamily = uiFont) },
                    singleLine = true,
                    shape = RoundedCornerShape(11.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("app_editor_title_ur_input")
                )

                OutlinedTextField(
                    value = draftConfig.appTitleEn,
                    onValueChange = {
                        onUpdateBrandingDraft(
                            draftConfig.schoolNameUr,
                            draftConfig.schoolNameEn,
                            draftConfig.appTitleUr,
                            it,
                            draftConfig.heroSubtitleUr,
                            draftConfig.heroSubtitleEn
                        )
                    },
                    label = { Text(strings.appEditorTitleEn, fontFamily = uiFont) },
                    singleLine = true,
                    shape = RoundedCornerShape(11.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("app_editor_title_en_input")
                )

                OutlinedTextField(
                    value = draftConfig.heroSubtitleUr,
                    onValueChange = {
                        onUpdateBrandingDraft(
                            draftConfig.schoolNameUr,
                            draftConfig.schoolNameEn,
                            draftConfig.appTitleUr,
                            draftConfig.appTitleEn,
                            it,
                            draftConfig.heroSubtitleEn
                        )
                    },
                    label = { Text(strings.appEditorHeroUr, fontFamily = uiFont) },
                    shape = RoundedCornerShape(11.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("app_editor_hero_ur_input")
                )

                OutlinedTextField(
                    value = draftConfig.heroSubtitleEn,
                    onValueChange = {
                        onUpdateBrandingDraft(
                            draftConfig.schoolNameUr,
                            draftConfig.schoolNameEn,
                            draftConfig.appTitleUr,
                            draftConfig.appTitleEn,
                            draftConfig.heroSubtitleUr,
                            it
                        )
                    },
                    label = { Text(strings.appEditorHeroEn, fontFamily = uiFont) },
                    shape = RoundedCornerShape(11.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("app_editor_hero_en_input")
                )

                Button(
                    onClick = {
                        dismissTextControls()
                        onSaveBranding()
                    },
                    shape = RoundedCornerShape(11.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("app_editor_save_branding_button")
                ) {
                    Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = strings.appEditorSaveBranding,
                        fontFamily = uiFont,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    // 2. Color Theme Palette Studio
    item(key = "app_editor_themes") {
        val extended = LocalNamazColors.current
        val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = extended.cardSurface),
            border = BorderStroke(1.dp, extended.cardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Palette,
                        contentDescription = null,
                        tint = extended.arabicAccent
                    )
                    Text(
                        text = strings.appEditorThemeHeading,
                        fontFamily = uiFont,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = extended.arabicAccent
                    )
                }

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    AppThemePreset.entries.forEach { preset ->
                        val isSelected = draftConfig.themePreset == preset
                        val primaryColor = Color(preset.primaryHex)
                        val goldColor = Color(preset.goldHex)
                        Surface(
                            onClick = { onSelectThemePreset(preset) },
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) extended.greenSurface else MaterialTheme.colorScheme.background,
                            border = BorderStroke(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) goldColor else extended.cardBorder
                            ),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("theme_preset_${preset.id}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .background(primaryColor)
                                        .border(2.dp, goldColor, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Filled.Check,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = if (language == AppLanguage.ENGLISH) preset.titleEn else preset.titleUr,
                                    fontFamily = uiFont,
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // 3. Display, Typography & Audio Controls
    item(key = "app_editor_display") {
        val extended = LocalNamazColors.current
        val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily
        val pct = (draftConfig.fontScale * 100f).roundToInt()

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = extended.cardSurface),
            border = BorderStroke(1.dp, extended.cardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = strings.appEditorDisplayHeading,
                    fontFamily = uiFont,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = extended.arabicAccent
                )

                // Font scale slider + live sample
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = extended.greenSurface,
                    border = BorderStroke(1.dp, extended.cardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = strings.appEditorFontScale(pct),
                            fontFamily = uiFont,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = extended.arabicAccent
                        )
                        Text(
                            text = "سُبْحَانَ رَبِّيَ الْعَظِيمِ",
                            fontFamily = AmiriFontFamily,
                            fontSize = (24f * draftConfig.fontScale).sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Slider(
                            value = draftConfig.fontScale,
                            onValueChange = onUpdateFontScale,
                            valueRange = 0.85f..1.35f,
                            steps = 9,
                            colors = SliderDefaults.colors(
                                thumbColor = extended.gold,
                                activeTrackColor = MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.testTag("app_editor_font_scale_slider")
                        )
                    }
                }

                // Toggles
                AppEditorToggleRow(
                    title = if (language == AppLanguage.ENGLISH) "Night Mode (Dark Theme)" else "نائٹ موڈ (تاریک تھیم)",
                    subtitle = if (language == AppLanguage.ENGLISH) "Comfortable eye-care dark contrast" else "رات کے وقت آرام دہ مطالعہ کے لیے",
                    checked = darkMode,
                    onCheckedChange = { onToggleDarkMode() },
                    uiFont = uiFont,
                    testTag = "app_editor_dark_mode_switch"
                )
                HorizontalDivider(color = extended.cardBorder)

                AppEditorToggleRow(
                    title = if (language == AppLanguage.ENGLISH) "Large Classroom Font (A+)" else "بڑا فونٹ (کلاس روم موڈ)",
                    subtitle = if (language == AppLanguage.ENGLISH) "Extra boost for young students & projection" else "بچوں اور اسکرین پر واضح پڑھائی کے لیے",
                    checked = bigFont,
                    onCheckedChange = { onToggleBigFont() },
                    uiFont = uiFont,
                    testTag = "app_editor_big_font_switch"
                )
                HorizontalDivider(color = extended.cardBorder)

                AppEditorToggleRow(
                    title = if (language == AppLanguage.ENGLISH) "App Language: English (LTR)" else "ایپ کی زبان: اردو / انگلش",
                    subtitle = if (language == AppLanguage.ENGLISH) "Toggle between English (LTR) and Urdu (RTL)" else "اردو اور انگلش زبان میں فوری تبدیلی",
                    checked = language == AppLanguage.ENGLISH,
                    onCheckedChange = { onToggleLanguage() },
                    uiFont = uiFont,
                    testTag = "app_editor_language_switch"
                )
                HorizontalDivider(color = extended.cardBorder)

                AppEditorToggleRow(
                    title = strings.appEditorShowPronBoxes,
                    subtitle = strings.appEditorShowPronBoxesDesc,
                    checked = draftConfig.showPronunciationInBoxes,
                    onCheckedChange = { onToggleShowPronunciationInBoxes() },
                    uiFont = uiFont,
                    testTag = "app_editor_pron_boxes_switch"
                )
                HorizontalDivider(color = extended.cardBorder)

                AppEditorToggleRow(
                    title = strings.appEditorShowSecondaryTitle,
                    subtitle = strings.appEditorShowSecondaryTitleDesc,
                    checked = draftConfig.showSecondaryTitle,
                    onCheckedChange = { onToggleShowSecondaryTitle() },
                    uiFont = uiFont,
                    testTag = "app_editor_secondary_title_switch"
                )

                HorizontalDivider(color = extended.cardBorder)

                // Audio Speed Selector
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Speed,
                            contentDescription = null,
                            tint = extended.arabicAccent,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = strings.appEditorAudioSpeed,
                            fontFamily = uiFont,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val speeds = listOf(
                            0.65f to strings.appEditorSpeedSlow,
                            0.82f to strings.appEditorSpeedNormal,
                            1.02f to strings.appEditorSpeedFast
                        )
                        speeds.forEach { (rate, label) ->
                            val selected = kotlin.math.abs(draftConfig.ttsSpeed - rate) < 0.08f
                            Surface(
                                onClick = { onUpdateTtsSpeed(rate) },
                                shape = RoundedCornerShape(10.dp),
                                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.background,
                                contentColor = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                                border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else extended.cardBorder),
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("app_editor_speed_${(rate * 100).roundToInt()}")
                            ) {
                                Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp)) {
                                    Text(
                                        text = label,
                                        fontFamily = uiFont,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 4. Backup, Import & Reset Section
    item(key = "app_editor_backup") {
        AppEditorBackupCard(
            language = language,
            strings = strings,
            onBuildBackupJson = onBuildBackupJson,
            onShareBackupJson = onShareBackupJson,
            onImportBackupJson = onImportBackupJson,
            onResetAppDefaults = onResetAppDefaults,
            onEmitToast = onEmitToast
        )
    }
}

@Composable
private fun AppEditorLivePreviewCard(
    language: AppLanguage,
    strings: UiStrings,
    draftConfig: AppCustomization
) {
    val extended = LocalNamazColors.current
    val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily
    val previewPrimary = Color(draftConfig.themePreset.primaryHex)
    val previewDark = Color(draftConfig.themePreset.primaryDarkHex)
    val previewGold = Color(draftConfig.themePreset.goldHex)

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = extended.cardSurface),
        border = BorderStroke(1.5.dp, extended.gold),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = strings.appEditorTitle,
                fontFamily = uiFont,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = extended.arabicAccent
            )
            Text(
                text = strings.appEditorSubtitle,
                fontFamily = uiFont,
                fontSize = 12.sp,
                color = extended.mutedText
            )

            Text(
                text = strings.appEditorLivePreview,
                fontFamily = uiFont,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = extended.mutedText
            )

            Surface(
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(2.dp, previewGold),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Brush.linearGradient(listOf(previewPrimary, previewDark)))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(previewGold.copy(alpha = 0.22f))
                                .border(1.5.dp, previewGold, RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Mosque,
                                contentDescription = null,
                                tint = Color(0xFFFBE498),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = draftConfig.displaySchoolHeader(language),
                                color = Color(0xFFF8DF8B),
                                fontFamily = uiFont,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = draftConfig.displayAppTitle(language),
                                color = Color.White,
                                fontFamily = uiFont,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    Text(
                        text = draftConfig.displayHeroSubtitle(language),
                        color = Color.White.copy(alpha = 0.9f),
                        fontFamily = uiFont,
                        fontSize = 12.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun AppEditorToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    uiFont: androidx.compose.ui.text.font.FontFamily,
    testTag: String
) {
    val extended = LocalNamazColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontFamily = uiFont,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Text(
                text = subtitle,
                fontFamily = uiFont,
                fontSize = 12.sp,
                color = extended.mutedText
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag)
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AppEditorBackupCard(
    language: AppLanguage,
    strings: UiStrings,
    onBuildBackupJson: () -> String,
    onShareBackupJson: (String) -> Unit,
    onImportBackupJson: (String) -> Unit,
    onResetAppDefaults: () -> Unit,
    onEmitToast: (String) -> Unit
) {
    val extended = LocalNamazColors.current
    val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily
    val context = LocalContext.current
    val dismissTextControls = rememberDismissTextControls()

    var showImportDialog by remember { mutableStateOf(false) }
    var importText by remember { mutableStateOf("") }
    var showResetDialog by remember { mutableStateOf(false) }

    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = {
                dismissTextControls()
                showImportDialog = false
            },
            title = {
                Text(strings.appEditorImportDialogTitle, fontFamily = uiFont, fontWeight = FontWeight.Bold)
            },
            text = {
                ProvideSafeTextToolbar {
                    OutlinedTextField(
                        value = importText,
                        onValueChange = { importText = it },
                        placeholder = { Text(strings.appEditorImportPlaceholder, fontFamily = uiFont) },
                        minLines = 4,
                        maxLines = 8,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("app_editor_import_json_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        dismissTextControls()
                        showImportDialog = false
                        onImportBackupJson(importText)
                        importText = ""
                    }
                ) {
                    Text(strings.appEditorImportConfirm, fontFamily = uiFont, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        dismissTextControls()
                        showImportDialog = false
                    }
                ) {
                    Text(strings.cancelNo, fontFamily = uiFont, fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = {
                Text(strings.appEditorResetDialogTitle, fontFamily = uiFont, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(strings.appEditorResetDialogBody, fontFamily = uiFont)
            },
            confirmButton = {
                Button(
                    onClick = {
                        dismissTextControls()
                        showResetDialog = false
                        onResetAppDefaults()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text(strings.confirmRestoreYes, fontFamily = uiFont, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text(strings.cancelNo, fontFamily = uiFont, fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = extended.greenSurface),
        border = BorderStroke(1.5.dp, extended.gold),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = strings.appEditorBackupHeading,
                fontFamily = uiFont,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = extended.arabicAccent
            )
            Text(
                text = strings.appEditorBackupDesc,
                fontFamily = uiFont,
                fontSize = 12.sp,
                color = extended.mutedText
            )

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = { onShareBackupJson(onBuildBackupJson()) },
                    shape = RoundedCornerShape(11.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier
                        .heightIn(min = 48.dp)
                        .testTag("app_editor_share_backup_button")
                ) {
                    Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.appEditorShareBackup, fontFamily = uiFont, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = {
                        val json = onBuildBackupJson()
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                        clipboard?.setPrimaryClip(ClipData.newPlainText("Namaz Tarjuma Backup", json))
                        onEmitToast(
                            if (language == AppLanguage.ENGLISH) "Backup JSON copied to clipboard ✓"
                            else "بیک اپ JSON کلپ بورڈ پر کاپی ہو گیا ✓"
                        )
                    },
                    shape = RoundedCornerShape(11.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier
                        .heightIn(min = 48.dp)
                        .testTag("app_editor_copy_backup_button")
                ) {
                    Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.appEditorCopyBackup, fontFamily = uiFont, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = {
                        dismissTextControls()
                        showImportDialog = true
                    },
                    shape = RoundedCornerShape(11.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier
                        .heightIn(min = 48.dp)
                        .testTag("app_editor_import_backup_button")
                ) {
                    Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.appEditorImportBackup, fontFamily = uiFont, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = {
                        dismissTextControls()
                        showResetDialog = true
                    },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
                    border = BorderStroke(1.5.dp, Color(0xFFDC2626)),
                    shape = RoundedCornerShape(11.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier
                        .heightIn(min = 48.dp)
                        .testTag("app_editor_reset_defaults_button")
                ) {
                    Icon(Icons.Filled.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.appEditorResetDefaults, fontFamily = uiFont, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}
