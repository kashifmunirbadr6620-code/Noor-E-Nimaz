package com.example.data

import com.example.model.Lesson
import com.example.model.LessonLine
import com.example.model.LughatItem
import com.example.model.QuizQuestion
import com.example.model.WordItem
import org.json.JSONArray
import org.json.JSONObject

object LessonJsonSerializer {

    fun encodeLessonsMap(map: Map<Int, Lesson>): String {
        val array = JSONArray()
        map.values.sortedBy { it.id }.forEach { lesson ->
            array.put(lessonToJson(lesson))
        }
        return array.toString()
    }

    fun decodeLessonsMap(json: String?): Map<Int, Lesson> {
        if (json.isNullOrBlank()) return emptyMap()
        return try {
            val array = JSONArray(json)
            val result = mutableMapOf<Int, Lesson>()
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val lesson = jsonToLesson(obj)
                result[lesson.id] = lesson
            }
            result
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private fun lessonToJson(lesson: Lesson): JSONObject {
        val obj = JSONObject()
        obj.put("id", lesson.id)
        obj.put("titleUr", lesson.titleUr)
        obj.put("titleEn", lesson.titleEn)
        obj.put("romanKeys", lesson.romanKeys)
        obj.put("isCustom", lesson.isCustom)

        val linesArr = JSONArray()
        lesson.lines.forEach { line ->
            val lineObj = JSONObject()
            lineObj.put("label", line.label)
            lineObj.put("labelEn", line.labelEn)
            lineObj.put("fullUr", line.fullUr)
            lineObj.put("fullEn", line.fullEn)
            val wordsArr = JSONArray()
            line.words.forEach { w ->
                val wObj = JSONObject()
                wObj.put("ar", w.ar)
                wObj.put("ur", w.ur)
                wObj.put("en", w.en)
                wObj.put("pron", w.pron)
                wordsArr.put(wObj)
            }
            lineObj.put("words", wordsArr)
            linesArr.put(lineObj)
        }
        obj.put("lines", linesArr)

        val lughatArr = JSONArray()
        lesson.lughat.forEach { lg ->
            val lgObj = JSONObject()
            lgObj.put("ar", lg.ar)
            lgObj.put("ur", lg.ur)
            lgObj.put("en", lg.en)
            lughatArr.put(lgObj)
        }
        obj.put("lughat", lughatArr)

        if (lesson.customQuiz != null) {
            val quizArr = JSONArray()
            lesson.customQuiz.forEach { q ->
                val qObj = JSONObject()
                qObj.put("q", q.q)
                qObj.put("ar", q.ar)
                qObj.put("ans", q.ans)
                val optsArr = JSONArray()
                q.opts.forEach { optsArr.put(it) }
                qObj.put("opts", optsArr)
                quizArr.put(qObj)
            }
            obj.put("customQuiz", quizArr)
        }
        return obj
    }

    private fun jsonToLesson(obj: JSONObject): Lesson {
        val lines = mutableListOf<LessonLine>()
        val linesArr = obj.optJSONArray("lines") ?: JSONArray()
        for (i in 0 until linesArr.length()) {
            val lineObj = linesArr.optJSONObject(i) ?: continue
            val words = mutableListOf<WordItem>()
            val wordsArr = lineObj.optJSONArray("words") ?: JSONArray()
            for (j in 0 until wordsArr.length()) {
                val wObj = wordsArr.optJSONObject(j) ?: continue
                words.add(
                    WordItem(
                        ar = wObj.optString("ar"),
                        ur = wObj.optString("ur"),
                        pron = wObj.optString("pron"),
                        en = wObj.optString("en")
                    )
                )
            }
            lines.add(
                LessonLine(
                    label = lineObj.optString("label"),
                    words = words,
                    fullUr = lineObj.optString("fullUr"),
                    labelEn = lineObj.optString("labelEn"),
                    fullEn = lineObj.optString("fullEn")
                )
            )
        }

        val lughat = mutableListOf<LughatItem>()
        val lughatArr = obj.optJSONArray("lughat") ?: JSONArray()
        for (i in 0 until lughatArr.length()) {
            val lgObj = lughatArr.optJSONObject(i) ?: continue
            lughat.add(
                LughatItem(
                    ar = lgObj.optString("ar"),
                    ur = lgObj.optString("ur"),
                    en = lgObj.optString("en")
                )
            )
        }

        val customQuiz = obj.optJSONArray("customQuiz")?.let { quizArr ->
            val list = mutableListOf<QuizQuestion>()
            for (i in 0 until quizArr.length()) {
                val qObj = quizArr.optJSONObject(i) ?: continue
                val opts = mutableListOf<String>()
                val optsArr = qObj.optJSONArray("opts") ?: JSONArray()
                for (j in 0 until optsArr.length()) {
                    opts.add(optsArr.optString(j))
                }
                list.add(
                    QuizQuestion(
                        q = qObj.optString("q"),
                        ar = qObj.optString("ar"),
                        opts = opts,
                        ans = qObj.optInt("ans", 0)
                    )
                )
            }
            list
        }

        return Lesson(
            id = obj.optInt("id", 1),
            titleUr = obj.optString("titleUr"),
            titleEn = obj.optString("titleEn"),
            romanKeys = obj.optString("romanKeys"),
            lines = lines,
            lughat = lughat,
            customQuiz = customQuiz,
            isCustom = obj.optBoolean("isCustom", false)
        )
    }
}
