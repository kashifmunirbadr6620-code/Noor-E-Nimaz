package com.example.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.LessonRepository
import com.example.data.UserPreferencesRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class StudyReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val pendingResult = goAsync()
        val appContext = context.applicationContext
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val repo = UserPreferencesRepository(appContext)
                val progress = repo.progressFlow.first()
                if (!progress.reminderEnabled) return@launch

                val customLessons = repo.customLessonsFlow.first()
                val allLessons = LessonRepository.mergeLessons(customLessons)
                val activeIds = allLessons.map { it.id }.toSet()
                val doneCount = progress.completedLessons.count { it in activeIds }
                val nextTitle = StudyReminderHelper.pickNextLessonTitle(
                    lessons = allLessons,
                    completedLessons = progress.completedLessons,
                    lastLessonId = progress.lastLessonId,
                    language = progress.language
                )

                StudyReminderHelper.showStudyReminderNotification(
                    context = appContext,
                    completedCount = doneCount,
                    totalCount = allLessons.size,
                    nextLessonTitle = nextTitle,
                    language = progress.language
                )

                // Reschedule for tomorrow at the saved time
                StudyReminderHelper.scheduleDailyReminder(
                    context = appContext,
                    hour = progress.reminderHour,
                    minute = progress.reminderMinute
                )
            } finally {
                pendingResult.finish()
            }
        }
    }
}

class StudyReminderBootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) {
            return
        }
        val pendingResult = goAsync()
        val appContext = context.applicationContext
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val progress = UserPreferencesRepository(appContext).progressFlow.first()
                if (progress.reminderEnabled) {
                    StudyReminderHelper.scheduleDailyReminder(
                        context = appContext,
                        hour = progress.reminderHour,
                        minute = progress.reminderMinute
                    )
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
