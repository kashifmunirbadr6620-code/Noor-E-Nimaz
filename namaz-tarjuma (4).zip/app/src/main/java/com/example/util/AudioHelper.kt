package com.example.util

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class AudioHelper(context: Context) {

    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private var arabicAvailable = false
    private var currentSpeechRate: Float = 0.82f

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _activeLineIndex = MutableStateFlow<Int?>(null)
    val activeLineIndex: StateFlow<Int?> = _activeLineIndex.asStateFlow()

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isInitialized = true
                val engine = tts ?: return@TextToSpeech
                val saLocale = Locale("ar", "SA")
                val arLocale = Locale("ar")
                val resSa = engine.setLanguage(saLocale)
                val resAr = if (resSa == TextToSpeech.LANG_MISSING_DATA || resSa == TextToSpeech.LANG_NOT_SUPPORTED) {
                    engine.setLanguage(arLocale)
                } else {
                    resSa
                }
                arabicAvailable = resAr != TextToSpeech.LANG_MISSING_DATA &&
                    resAr != TextToSpeech.LANG_NOT_SUPPORTED
                engine.setSpeechRate(currentSpeechRate)
                engine.setPitch(1.0f)

                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                    }

                    override fun onDone(utteranceId: String?) {
                        _isSpeaking.value = false
                        _activeLineIndex.value = null
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _isSpeaking.value = false
                        _activeLineIndex.value = null
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        _isSpeaking.value = false
                        _activeLineIndex.value = null
                    }
                })
            }
        }
    }

    fun setSpeechRate(rate: Float) {
        currentSpeechRate = rate.coerceIn(0.6f, 1.15f)
        if (isInitialized) {
            tts?.setSpeechRate(currentSpeechRate)
        }
    }

    fun speak(
        text: String,
        lineIndex: Int? = null,
        silentIfUnavailable: Boolean = false,
        onUnavailable: (() -> Unit)? = null
    ) {
        val engine = tts
        if (!isInitialized || engine == null) {
            if (!silentIfUnavailable) onUnavailable?.invoke()
            return
        }
        stop()
        if (!arabicAvailable) {
            if (!silentIfUnavailable) onUnavailable?.invoke()
            return
        }
        engine.setSpeechRate(currentSpeechRate)
        _isSpeaking.value = true
        _activeLineIndex.value = lineIndex
        val result = engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "namaz_tts_${System.currentTimeMillis()}")
        if (result == TextToSpeech.ERROR) {
            stop()
            if (!silentIfUnavailable) onUnavailable?.invoke()
        }
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
        _activeLineIndex.value = null
    }

    fun release() {
        stop()
        tts?.shutdown()
        tts = null
    }
}
