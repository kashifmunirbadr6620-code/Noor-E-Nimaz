package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.AppLanguage
import com.example.model.GlobalSearchCategory
import com.example.model.GlobalSearchMatch
import com.example.ui.GlobalSearchUiState
import com.example.ui.ProvideSafeTextToolbar
import com.example.ui.UiStrings
import com.example.ui.rememberDismissTextControls
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.theme.LocalNamazColors
import com.example.ui.theme.RomanFontFamily
import com.example.ui.theme.UrduFontFamily

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GlobalSearchModal(
    language: AppLanguage,
    strings: UiStrings,
    state: GlobalSearchUiState,
    onQueryChange: (String) -> Unit,
    onCategoryChange: (GlobalSearchCategory) -> Unit,
    onResultClick: (GlobalSearchMatch) -> Unit,
    onDismiss: () -> Unit
) {
    if (!state.isOpen) return

    val extended = LocalNamazColors.current
    val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily
    val layoutDirection = if (language == AppLanguage.ENGLISH) LayoutDirection.Ltr else LayoutDirection.Rtl
    val dismissTextControls = rememberDismissTextControls()
    val focusManager = LocalFocusManager.current

    Dialog(
        onDismissRequest = {
            dismissTextControls()
            onDismiss()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
            ProvideSafeTextToolbar {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .safeDrawingPadding()
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        shape = RoundedCornerShape(22.dp),
                        color = extended.cardSurface,
                        border = BorderStroke(2.dp, extended.gold),
                        tonalElevation = 6.dp,
                        shadowElevation = 12.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = 640.dp)
                            .heightIn(max = 680.dp)
                            .testTag("global_search_dialog")
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            // Top Emerald-Gold Header
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        Brush.horizontalGradient(
                                            colors = listOf(extended.greenHeader, extended.greenHeaderDark)
                                        )
                                    )
                                    .padding(horizontal = 14.dp, vertical = 12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = extended.gold,
                                        modifier = Modifier.size(40.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Filled.Search,
                                                contentDescription = null,
                                                tint = Color(0xFF1A1A1A),
                                                modifier = Modifier.size(22.dp)
                                            )
                                        }
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = strings.globalSearchTitle,
                                            color = Color(0xFFFBE498),
                                            fontFamily = uiFont,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 18.sp
                                        )
                                        Text(
                                            text = strings.globalSearchSubtitle,
                                            color = Color.White.copy(alpha = 0.9f),
                                            fontFamily = uiFont,
                                            fontSize = 12.sp,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }

                                    IconButton(
                                        onClick = {
                                            dismissTextControls()
                                            onDismiss()
                                        },
                                        modifier = Modifier
                                            .size(48.dp)
                                            .testTag("global_search_close_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Close,
                                            contentDescription = strings.globalSearchCloseDesc,
                                            tint = Color.White
                                        )
                                    }
                                }
                            }

                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                // Search Input
                                OutlinedTextField(
                                    value = state.query,
                                    onValueChange = onQueryChange,
                                    placeholder = {
                                        Text(
                                            text = strings.globalSearchPlaceholder,
                                            fontFamily = uiFont,
                                            fontSize = 13.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Filled.Search,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    },
                                    trailingIcon = {
                                        if (state.query.isNotEmpty()) {
                                            IconButton(
                                                onClick = {
                                                    dismissTextControls()
                                                    onQueryChange("")
                                                },
                                                modifier = Modifier.testTag("global_search_clear_button")
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Filled.Clear,
                                                    contentDescription = strings.clearSearch
                                                )
                                            }
                                        }
                                    },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                    keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = extended.gold,
                                        unfocusedBorderColor = extended.cardBorder
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("global_search_input")
                                )

                                // Category Filter Chips
                                val categories = listOf(
                                    GlobalSearchCategory.ALL to strings.globalSearchCatAll,
                                    GlobalSearchCategory.LESSON to strings.globalSearchCatLessons,
                                    GlobalSearchCategory.DUA to strings.globalSearchCatDuas,
                                    GlobalSearchCategory.HADITH to strings.globalSearchCatHadith
                                )
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    categories.forEach { (cat, label) ->
                                        val selected = state.category == cat
                                        FilterChip(
                                            selected = selected,
                                            onClick = { onCategoryChange(cat) },
                                            label = {
                                                Text(
                                                    text = label,
                                                    fontFamily = uiFont,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp
                                                )
                                            },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                                selectedLabelColor = Color.White
                                            ),
                                            modifier = Modifier
                                                .heightIn(min = 48.dp)
                                                .testTag("global_search_cat_${cat.name.lowercase()}")
                                        )
                                    }
                                }

                                if (state.query.trim().isEmpty()) {
                                    Text(
                                        text = strings.globalSearchSuggestionsTitle,
                                        fontFamily = uiFont,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = extended.arabicAccent
                                    )

                                    val suggestions = if (language == AppLanguage.ENGLISH) {
                                        listOf("Fatiha", "Janaza", "Istighfar", "Bukhari", "Morning", "RABB")
                                    } else {
                                        listOf("فاتحہ", "جنازہ", "استغفار", "بخاری", "صبح", "رَبِّ")
                                    }
                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        suggestions.forEach { keyword ->
                                            Surface(
                                                onClick = { onQueryChange(keyword) },
                                                shape = RoundedCornerShape(999.dp),
                                                color = extended.greenSurface,
                                                border = BorderStroke(1.dp, extended.cardBorder),
                                                modifier = Modifier
                                                    .heightIn(min = 48.dp)
                                                    .testTag("global_search_suggestion_$keyword")
                                            ) {
                                                Box(
                                                    contentAlignment = Alignment.Center,
                                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                                ) {
                                                    Text(
                                                        text = keyword,
                                                        fontFamily = uiFont,
                                                        fontSize = 13.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = extended.arabicAccent
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(14.dp),
                                        color = extended.greenSurface,
                                        border = BorderStroke(1.dp, extended.cardBorder),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = strings.globalSearchEmptyHint,
                                            fontFamily = uiFont,
                                            fontSize = 13.sp,
                                            color = extended.mutedText,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(14.dp)
                                        )
                                    }
                                } else {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = strings.globalSearchResultsCount(state.results.size),
                                            fontFamily = uiFont,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = extended.mutedText
                                        )
                                    }

                                    if (state.results.isEmpty()) {
                                        Surface(
                                            shape = RoundedCornerShape(14.dp),
                                            color = extended.greenSurface,
                                            border = BorderStroke(1.dp, extended.cardBorder),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("global_search_no_results")
                                        ) {
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(18.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Text(
                                                    text = strings.noSearchResults,
                                                    fontFamily = uiFont,
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = extended.arabicAccent,
                                                    textAlign = TextAlign.Center
                                                )
                                                Text(
                                                    text = strings.globalSearchEmptyHint,
                                                    fontFamily = uiFont,
                                                    fontSize = 12.sp,
                                                    color = extended.mutedText,
                                                    textAlign = TextAlign.Center
                                                )
                                            }
                                        }
                                    } else {
                                        LazyColumn(
                                            verticalArrangement = Arrangement.spacedBy(8.dp),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .weight(1f, fill = false)
                                                .heightIn(max = 390.dp)
                                                .testTag("global_search_results_list")
                                        ) {
                                            items(state.results, key = { it.id }) { match ->
                                                GlobalSearchResultCard(
                                                    language = language,
                                                    strings = strings,
                                                    match = match,
                                                    onClick = {
                                                        dismissTextControls()
                                                        onResultClick(match)
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GlobalSearchResultCard(
    language: AppLanguage,
    strings: UiStrings,
    match: GlobalSearchMatch,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val extended = LocalNamazColors.current
    val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily

    val badgeLabel: String
    val badgeBg: Color
    val badgeText: Color
    val badgeIcon = when (match.category) {
        GlobalSearchCategory.LESSON -> {
            badgeLabel = strings.globalSearchBadgeLesson
            badgeBg = MaterialTheme.colorScheme.primary
            badgeText = Color.White
            Icons.AutoMirrored.Filled.MenuBook
        }
        GlobalSearchCategory.DUA -> {
            badgeLabel = strings.globalSearchBadgeDua
            badgeBg = extended.goldLight
            badgeText = extended.goldText
            Icons.Filled.AutoAwesome
        }
        GlobalSearchCategory.HADITH -> {
            badgeLabel = strings.globalSearchBadgeHadith
            badgeBg = extended.blueText.copy(alpha = 0.14f)
            badgeText = extended.blueText
            Icons.Filled.FormatQuote
        }
        GlobalSearchCategory.ALL -> {
            badgeLabel = strings.globalSearchBadgeLesson
            badgeBg = MaterialTheme.colorScheme.primary
            badgeText = Color.White
            Icons.AutoMirrored.Filled.MenuBook
        }
    }

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = extended.greenSurface,
        border = BorderStroke(1.dp, extended.cardBorder),
        modifier = modifier
            .fillMaxWidth()
            .testTag("global_search_result_${match.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = match.displayTitle(language),
                    fontFamily = uiFont,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = extended.arabicAccent,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = badgeBg,
                    border = if (match.category == GlobalSearchCategory.DUA) {
                        BorderStroke(1.dp, extended.gold)
                    } else null
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = badgeIcon,
                            contentDescription = null,
                            tint = badgeText,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = badgeLabel,
                            color = badgeText,
                            fontFamily = uiFont,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            if (match.arabic.isNotBlank()) {
                Text(
                    text = match.arabic,
                    fontFamily = AmiriFontFamily,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                    color = extended.arabicAccent,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            val meaning = match.displayMeaning(language)
            if (meaning.isNotBlank()) {
                Text(
                    text = meaning,
                    fontFamily = uiFont,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = extended.redMeaning,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            val sub = match.displaySubtitle(language)
            if (sub.isNotBlank()) {
                Text(
                    text = sub,
                    fontFamily = uiFont,
                    fontSize = 11.sp,
                    color = extended.mutedText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
