package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import com.example.model.AppThemePreset

@Immutable
data class NamazExtendedColors(
    val gold: Color,
    val goldLight: Color,
    val goldText: Color,
    val greenSurface: Color,
    val greenHeader: Color,
    val greenHeaderDark: Color,
    val redMeaning: Color,
    val blueBg: Color,
    val blueBorder: Color,
    val blueText: Color,
    val cardBorder: Color,
    val cardSurface: Color,
    val mutedText: Color,
    val arabicAccent: Color
)

@Immutable
data class NamazFontSizes(
    val arabicWordSize: TextUnit,
    val arabicHeroSize: TextUnit,
    val wordUrduSize: TextUnit,
    val fullUrduSize: TextUnit,
    val uiBodySize: TextUnit
)

val LocalNamazColors = staticCompositionLocalOf {
    NamazExtendedColors(
        gold = WarmGold,
        goldLight = WarmGoldLight,
        goldText = WarmGoldText,
        greenSurface = EmeraldLightSurface,
        greenHeader = EmeraldGreen,
        greenHeaderDark = EmeraldDark,
        redMeaning = LightRedMeaning,
        blueBg = LightBlueBg,
        blueBorder = LightBlueBorder,
        blueText = LightBlueText,
        cardBorder = LightBorder,
        cardSurface = LightCard,
        mutedText = LightMuted,
        arabicAccent = EmeraldGreen
    )
}

val LocalNamazFontSizes = staticCompositionLocalOf {
    NamazFontSizes(
        arabicWordSize = 26.sp,
        arabicHeroSize = 24.sp,
        wordUrduSize = 14.sp,
        fullUrduSize = 16.sp,
        uiBodySize = 14.sp
    )
}

@Composable
fun NamazTarjumaTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    bigFont: Boolean = false,
    themePreset: AppThemePreset = AppThemePreset.EMERALD_GOLD,
    fontScale: Float = 1.0f,
    content: @Composable () -> Unit
) {
    val presetPrimary = Color(themePreset.primaryHex)
    val presetDark = Color(themePreset.primaryDarkHex)
    val presetSurfaceLight = Color(themePreset.surfaceLightHex)
    val presetNight = Color(themePreset.primaryNightHex)
    val presetGold = Color(themePreset.goldHex)

    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = presetNight,
            onPrimary = Color(0xFF042018),
            primaryContainer = presetDark,
            onPrimaryContainer = Color(0xFFD1FAE5),
            secondary = presetGold,
            onSecondary = Color(0xFF1A1A1A),
            secondaryContainer = DarkGoldLight,
            onSecondaryContainer = DarkGoldText,
            tertiary = DarkBlueBorder,
            background = DarkBg,
            onBackground = DarkText,
            surface = DarkCard,
            onSurface = DarkText,
            surfaceVariant = DarkGreenLight,
            onSurfaceVariant = DarkMuted,
            outline = DarkBorder,
            error = DarkRedMeaning
        )
    } else {
        lightColorScheme(
            primary = presetPrimary,
            onPrimary = Color.White,
            primaryContainer = presetSurfaceLight,
            onPrimaryContainer = presetDark,
            secondary = presetGold,
            onSecondary = Color(0xFF1A1A1A),
            secondaryContainer = WarmGoldLight,
            onSecondaryContainer = WarmGoldText,
            tertiary = LightBlueBorder,
            background = LightBg,
            onBackground = LightText,
            surface = LightCard,
            onSurface = LightText,
            surfaceVariant = presetSurfaceLight,
            onSurfaceVariant = LightMuted,
            outline = LightBorder,
            error = LightRedMeaning
        )
    }

    val extendedColors = if (darkTheme) {
        NamazExtendedColors(
            gold = presetGold,
            goldLight = DarkGoldLight,
            goldText = DarkGoldText,
            greenSurface = Color(0xFF172D27),
            greenHeader = presetPrimary,
            greenHeaderDark = presetDark,
            redMeaning = DarkRedMeaning,
            blueBg = DarkBlueBg,
            blueBorder = DarkBlueBorder,
            blueText = DarkBlueText,
            cardBorder = DarkBorder,
            cardSurface = DarkCard,
            mutedText = DarkMuted,
            arabicAccent = presetNight
        )
    } else {
        NamazExtendedColors(
            gold = presetGold,
            goldLight = WarmGoldLight,
            goldText = WarmGoldText,
            greenSurface = presetSurfaceLight,
            greenHeader = presetPrimary,
            greenHeaderDark = presetDark,
            redMeaning = LightRedMeaning,
            blueBg = LightBlueBg,
            blueBorder = LightBlueBorder,
            blueText = LightBlueText,
            cardBorder = LightBorder,
            cardSurface = LightCard,
            mutedText = LightMuted,
            arabicAccent = presetPrimary
        )
    }

    val safeScale = fontScale.coerceIn(0.85f, 1.35f) * (if (bigFont) 1.22f else 1.0f)
    val fontSizes = NamazFontSizes(
        arabicWordSize = (26f * safeScale).sp,
        arabicHeroSize = (23f * safeScale).sp,
        wordUrduSize = (14f * safeScale).sp,
        fullUrduSize = (16f * safeScale).sp,
        uiBodySize = (14f * safeScale).sp
    )

    CompositionLocalProvider(
        LocalNamazColors provides extendedColors,
        LocalNamazFontSizes provides fontSizes
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
