package com.example.data

import com.example.model.AppCustomization
import com.example.model.AppThemePreset
import com.example.model.Lesson
import org.json.JSONArray
import org.json.JSONObject

data class AppBackupPayload(
    val appCustomization: AppCustomization?,
    val customLessons: Map<Int, Lesson>
)

object AppCustomizationSerializer {

    fun encode(config: AppCustomization): String = toJsonObject(config).toString()

    fun decode(json: String?): AppCustomization {
        if (json.isNullOrBlank()) return AppCustomization()
        return try {
            fromJsonObject(JSONObject(json))
        } catch (_: Exception) {
            AppCustomization()
        }
    }

    fun encodeFullBackup(config: AppCustomization, customLessons: Map<Int, Lesson>): String {
        val root = JSONObject()
        root.put("version", 1)
        root.put("appCustomization", toJsonObject(config))
        val lessonsArray = JSONArray(LessonJsonSerializer.encodeLessonsMap(customLessons))
        root.put("customLessons", lessonsArray)
        return root.toString(2)
    }

    fun decodeFullBackup(json: String): AppBackupPayload? {
        val trimmed = json.trim()
        if (trimmed.isEmpty()) return null
        return try {
            val root = JSONObject(trimmed)
            val hasConfig = root.has("appCustomization")
            val hasLessons = root.has("customLessons")
            if (!hasConfig && !hasLessons) return null
            val config = root.optJSONObject("appCustomization")?.let { fromJsonObject(it) }
            val lessonsArr = root.optJSONArray("customLessons")?.toString()
            val lessons = LessonJsonSerializer.decodeLessonsMap(lessonsArr)
            AppBackupPayload(appCustomization = config, customLessons = lessons)
        } catch (_: Exception) {
            null
        }
    }

    private fun toJsonObject(config: AppCustomization): JSONObject = JSONObject().apply {
        put("schoolNameUr", config.schoolNameUr)
        put("schoolNameEn", config.schoolNameEn)
        put("appTitleUr", config.appTitleUr)
        put("appTitleEn", config.appTitleEn)
        put("heroSubtitleUr", config.heroSubtitleUr)
        put("heroSubtitleEn", config.heroSubtitleEn)
        put("themePreset", config.themePreset.id)
        put("fontScale", config.fontScale.toDouble())
        put("ttsSpeed", config.ttsSpeed.toDouble())
        put("showPronunciationInBoxes", config.showPronunciationInBoxes)
        put("showSecondaryTitle", config.showSecondaryTitle)
    }

    private fun fromJsonObject(obj: JSONObject): AppCustomization = AppCustomization(
        schoolNameUr = obj.optString("schoolNameUr", AppCustomization.DEFAULT_SCHOOL_UR),
        schoolNameEn = obj.optString("schoolNameEn", AppCustomization.DEFAULT_SCHOOL_EN),
        appTitleUr = obj.optString("appTitleUr", AppCustomization.DEFAULT_APP_TITLE_UR),
        appTitleEn = obj.optString("appTitleEn", AppCustomization.DEFAULT_APP_TITLE_EN),
        heroSubtitleUr = obj.optString("heroSubtitleUr", AppCustomization.DEFAULT_HERO_SUBTITLE_UR),
        heroSubtitleEn = obj.optString("heroSubtitleEn", AppCustomization.DEFAULT_HERO_SUBTITLE_EN),
        themePreset = AppThemePreset.fromId(obj.optString("themePreset", AppThemePreset.EMERALD_GOLD.id)),
        fontScale = obj.optDouble("fontScale", 1.0).toFloat().coerceIn(0.85f, 1.35f),
        ttsSpeed = obj.optDouble("ttsSpeed", 0.82).toFloat().coerceIn(0.6f, 1.15f),
        showPronunciationInBoxes = obj.optBoolean("showPronunciationInBoxes", false),
        showSecondaryTitle = obj.optBoolean("showSecondaryTitle", true)
    )
}
