package com.example.data

import com.example.model.AsmaUlHusnaItem
import com.example.model.HadithItem
import com.example.model.ZikrItem

object AzkarData {

    val asmaUlHusnaList: List<AsmaUlHusnaItem> = listOf(
        AsmaUlHusnaItem(1, "اَلرَّحْمٰنُ", "الرحمن", "Ar-Rahman", "بے حد رحم کرنے والا", "The Exceedingly Compassionate"),
        AsmaUlHusnaItem(2, "اَلرَّحِيْمُ", "الرحیم", "Ar-Raheem", "نہایت مہربان", "The Most Merciful"),
        AsmaUlHusnaItem(3, "اَلْمَلِكُ", "الملک", "Al-Malik", "بادشاہ، حقیقی مالک", "The Sovereign King & Owner"),
        AsmaUlHusnaItem(4, "اَلْقُدُّوْسُ", "القدوس", "Al-Quddus", "انتہائی پاک اور بے عیب", "The Most Pure & Sacred"),
        AsmaUlHusnaItem(5, "اَلسَّلَامُ", "السلام", "As-Salam", "سلامتی دینے والا، امن کا سرچشمہ", "The Source of Peace & Safety"),
        AsmaUlHusnaItem(6, "اَلْمُؤْمِنُ", "المؤمن", "Al-Mu'min", "امن عطا کرنے والا، نگہبان", "The Granter of Security"),
        AsmaUlHusnaItem(7, "اَلْمُهَيْمِنُ", "المہیمن", "Al-Muhaimin", "پورا نگران و محافظ", "The Ever-Watchful Guardian"),
        AsmaUlHusnaItem(8, "اَلْعَزِيْزُ", "العزیز", "Al-Aziz", "سب پر غالب، عزت والا", "The Almighty"),
        AsmaUlHusnaItem(9, "اَلْخَالِقُ", "الخالق", "Al-Khaliq", "پیدا کرنے والا", "The Creator"),
        AsmaUlHusnaItem(10, "اَلْغَفَّارُ", "الغفار", "Al-Ghaffar", "بار بار بخشنے والا", "The Repeatedly Forgiving"),
        AsmaUlHusnaItem(11, "اَلْوَهَّابُ", "الوہاب", "Al-Wahhab", "بے حد عطا کرنے والا", "The Supreme Bestower"),
        AsmaUlHusnaItem(12, "اَلرَّزَّاقُ", "الرزاق", "Ar-Razzaq", "رزق دینے والا", "The Constant Provider"),
        AsmaUlHusnaItem(13, "اَلْعَلِيْمُ", "العلیم", "Al-Aleem", "سب کچھ جاننے والا", "The All-Knowing"),
        AsmaUlHusnaItem(14, "اَلسَّمِيْعُ", "السمیع", "As-Samee", "سب کچھ سننے والا", "The All-Hearing"),
        AsmaUlHusnaItem(15, "اَلْبَصِيْرُ", "البصیر", "Al-Baseer", "سب کچھ دیکھنے والا", "The All-Seeing"),
        AsmaUlHusnaItem(16, "اَلْحَكِيْمُ", "الحکیم", "Al-Hakeem", "بڑی حکمت والا", "The Most Wise"),
        AsmaUlHusnaItem(17, "اَلْوَدُوْدُ", "الودود", "Al-Wadood", "نہایت محبت کرنے والا", "The Most Loving"),
        AsmaUlHusnaItem(18, "اَلْمَجِيْدُ", "المجید", "Al-Majeed", "بڑی شان اور بزرگی والا", "The Most Glorious"),
        AsmaUlHusnaItem(19, "اَلْحَيُّ", "الحی", "Al-Hayy", "ہمیشہ زندہ رہنے والا", "The Ever-Living"),
        AsmaUlHusnaItem(20, "اَلْقَيُّوْمُ", "القیوم", "Al-Qayyum", "سب کو قائم رکھنے والا", "The Self-Subsisting Sustainer")
    )

    val childrenHadithList: List<HadithItem> = listOf(
        HadithItem(
            1,
            "إِنَّمَا الْأَعْمَالُ بِالنِّيَّاتِ",
            "اعمال کا دارومدار نیتوں پر ہے۔",
            "Actions are judged according to intentions.",
            "(حوالہ: صحیح بخاری و مسلم)",
            "(Ref: Sahih al-Bukhari & Muslim)"
        ),
        HadithItem(
            2,
            "خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ",
            "تم میں سے بہترین وہ ہے جو قرآن سیکھے اور سکھائے۔",
            "The best among you is the one who learns the Quran and teaches it.",
            "(حوالہ: صحیح بخاری: 5027)",
            "(Ref: Sahih al-Bukhari: 5027)"
        ),
        HadithItem(
            3,
            "اَلدِّيْنُ النَّصِيْحَةُ",
            "دین خیر خواہی (سچی ہمدردی اور بھلائی) کا نام ہے۔",
            "Religion is sincere good counsel and well-wishing.",
            "(حوالہ: صحیح مسلم: 55)",
            "(Ref: Sahih Muslim: 55)"
        ),
        HadithItem(
            4,
            "اَلطُّهُوْرُ شَطْرُ الْإِيْمَانِ",
            "پاکیزگی (صفائی) ایمان کا نصف حصہ ہے۔",
            "Cleanliness and purity is half of faith.",
            "(حوالہ: صحیح مسلم: 223)",
            "(Ref: Sahih Muslim: 223)"
        ),
        HadithItem(
            5,
            "تَبَسُّمُكَ فِيْ وَجْهِ أَخِيْكَ لَكَ صَدَقَةٌ",
            "تمہارا اپنے بھائی کے سامنے مسکرانا بھی تمہارے لیے صدقہ ہے۔",
            "Your smile in the face of your brother is charity for you.",
            "(حوالہ: جامع ترمذی: 1956)",
            "(Ref: Jami` at-Tirmidhi: 1956)"
        ),
        HadithItem(
            6,
            "مَنْ لَّا يَرْحَمُ لَا يُرْحَمُ",
            "جو (مخلوق پر) رحم نہیں کرتا، اس پر رحم نہیں کیا جاتا۔",
            "Whoever does not show mercy will not be shown mercy.",
            "(حوالہ: صحیح بخاری: 5997)",
            "(Ref: Sahih al-Bukhari: 5997)"
        ),
        HadithItem(
            7,
            "خَيْرُ النَّاسِ أَنْفَعُهُمْ لِلنَّاسِ",
            "لوگوں میں سب سے بہتر وہ ہے جو لوگوں کو زیادہ فائدہ پہنچائے۔",
            "The best of people are those most beneficial to others.",
            "(حوالہ: المعجم الأوسط للطبراني)",
            "(Ref: Al-Mu'jam al-Awsat)"
        ),
        HadithItem(
            8,
            "أَفْشُوا السَّلَامَ بَيْنَكُمْ",
            "اپنے درمیان سلام کو عام کرو۔",
            "Spread the greeting of peace (Salam) among yourselves.",
            "(حوالہ: صحیح مسلم: 54)",
            "(Ref: Sahih Muslim: 54)"
        ),
        HadithItem(
            9,
            "اَلْكَلِمَةُ الطَّيِّبَةُ صَدَقَةٌ",
            "اچھی اور میٹھی بات کہنا بھی صدقہ ہے۔",
            "A good and kind word is charity.",
            "(حوالہ: صحیح بخاری: 2989)",
            "(Ref: Sahih al-Bukhari: 2989)"
        ),
        HadithItem(
            10,
            "رِضَا الرَّبِّ فِيْ رِضَا الْوَالِدِ",
            "رب کی خوشنودی والدین کی خوشنودی میں ہے۔",
            "The pleasure of the Lord lies in the pleasure of the parents.",
            "(حوالہ: جامع ترمذی: 1899)",
            "(Ref: Jami` at-Tirmidhi: 1899)"
        )
    )

    // Ordered chronologically strictly according to the Sunnah right after Salam
    val afterSalahAzkarList: List<ZikrItem> = listOf(
        ZikrItem(
            orderNumber = 1,
            arabic = "أَسْتَغْفِرُ اللّٰهَ",
            speakText = "أَسْتَغْفِرُ اللّٰهَ",
            repeatUr = "تین بار (سلام پھیرتے ہی سب سے پہلے)",
            repeatEn = "3 times (Immediately after Salam)",
            translationUr = "میں اللہ سے بخشش مانگتا ہوں۔",
            translationEn = "I seek forgiveness from Allah.",
            refUr = "(حوالہ: صحیح مسلم: 591)",
            refEn = "(Ref: Sahih Muslim: 591)"
        ),
        ZikrItem(
            orderNumber = 2,
            arabic = "اَللّٰهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ، تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ",
            speakText = "اللهم أنت السلام ومنك السلام تباركت يا ذا الجلال والإكرام",
            repeatUr = "ایک بار",
            repeatEn = "1 time",
            translationUr = "اے اللہ! تو ہی سلامتی والا ہے اور تجھی سے سلامتی ہے، تو بابرکت ہے اے جلال اور بزرگی والے!",
            translationEn = "O Allah, You are Peace and from You comes peace; Blessed are You, O Possessor of Majesty and Honor.",
            refUr = "(حوالہ: صحیح مسلم: 591)",
            refEn = "(Ref: Sahih Muslim: 591)"
        ),
        ZikrItem(
            orderNumber = 3,
            arabic = "لَا إِلٰهَ إِلَّا اللّٰهُ وَحْدَهُ لَا شَرِيْكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلٰى كُلِّ شَيْءٍ قَدِيْرٌ",
            speakText = "لا إله إلا الله وحده لا شريك له له الملك وله الحمد وهو على كل شيء قدير",
            repeatUr = "ایک بار (یا فجر و مغرب کے بعد ۱۰ بار)",
            repeatEn = "1 time (or 10 times after Fajr & Maghrib)",
            translationUr = "اللہ کے سوا کوئی معبود نہیں، وہ اکیلا ہے اس کا کوئی شریک نہیں، اسی کی بادشاہی ہے اور اسی کے لیے تمام تعریف ہے، اور وہ ہر چیز پر قادر ہے۔",
            translationEn = "There is no deity except Allah alone, without partner. To Him belongs dominion and praise, and He has power over all things.",
            refUr = "(حوالہ: صحیح مسلم: 593)",
            refEn = "(Ref: Sahih Muslim: 593)"
        ),
        ZikrItem(
            orderNumber = 4,
            arabic = "رَبِّ أَعِنِّيْ عَلٰى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ",
            speakText = "رب أعني على ذكرك وشكرك وحسن عبادتك",
            repeatUr = "ایک بار",
            repeatEn = "1 time",
            translationUr = "اے میرے رب! اپنے ذکر پر، اپنے شکر پر اور اپنی بہترین عبادت پر میری مدد فرما۔",
            translationEn = "My Lord, help me to remember You, thank You, and worship You in the best manner.",
            refUr = "(حوالہ: سنن ابو داود: 1522)",
            refEn = "(Ref: Sunan Abi Dawud: 1522)"
        ),
        ZikrItem(
            orderNumber = 5,
            arabic = "سُبْحَانَ اللّٰهِ (33) • اَلْحَمْدُ لِلّٰهِ (33) • اَللّٰهُ أَكْبَرُ (34)",
            speakText = "سبحان الله والحمد لله والله أكبر",
            repeatUr = "تسبیحِ فاطمی (کل ۱۰۰ بار — نیچے کاؤنٹر استعمال کریں)",
            repeatEn = "Tasbeeh-e-Fatimi (100 total — use counter below)",
            translationUr = "اللہ پاک ہے (۳۳ بار)، تمام تعریفیں اللہ کے لیے ہیں (۳۳ بار)، اللہ سب سے بڑا ہے (۳۴ بار)۔",
            translationEn = "Glory be to Allah (33), All praise is due to Allah (33), Allah is the Greatest (34).",
            refUr = "(حوالہ: صحیح مسلم: 597)",
            refEn = "(Ref: Sahih Muslim: 597)"
        ),
        ZikrItem(
            orderNumber = 6,
            arabic = "اَللّٰهُ لَا إِلٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّوْمُ...",
            speakText = "اللهم إني أسألك علما نافعا ورزقا طيبا وعملا متقبلا",
            repeatUr = "آیۃ الکرسی + معوذات (ہر فرض نماز کے بعد 1 بار)",
            repeatEn = "Ayat-ul-Kursi & Quls (1 time after every Fard Salah)",
            translationUr = "اللہ کے سوا کوئی معبود نہیں، وہ زندہ ہے اور سب کو قائم رکھنے والا ہے (مکمل آیۃ الکرسی اور تین قل پڑھنا مسنون ہے)۔",
            translationEn = "Allah — there is no deity except Him, the Ever-Living, Sustainer of existence (recite complete Ayat-ul-Kursi & Three Quls).",
            refUr = "(حوالہ: سنن نسائی الکبریٰ: 9928)",
            refEn = "(Ref: An-Nasa'i Al-Kubra: 9928)"
        )
    )

    val morningEveningAzkarList: List<ZikrItem> = listOf(
        ZikrItem(
            orderNumber = 1,
            arabic = "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلّٰهِ، وَالْحَمْدُ لِلّٰهِ، لَا إِلٰهَ إِلَّا اللّٰهُ وَحْدَهُ لَا شَرِيْكَ لَهُ",
            speakText = "أصبحنا وأصبح الملك لله والحمد لله لا إله إلا الله وحده لا شريك له",
            repeatUr = "صبح ۱ بار (شام کو أَمْسَيْنَا پڑھیں)",
            repeatEn = "1 time (use Amsaina in the evening)",
            translationUr = "ہم نے اور تمام کائنات نے اللہ کے لیے صبح کی، اور تمام تعریفیں اللہ کے لیے ہیں، اللہ کے سوا کوئی معبود نہیں وہ اکیلا ہے اس کا کوئی شریک نہیں۔",
            translationEn = "We have reached morning and the whole kingdom belongs to Allah; all praise is for Allah, none has the right to be worshipped except Allah alone.",
            refUr = "(حوالہ: صحیح مسلم: 2723)",
            refEn = "(Ref: Sahih Muslim: 2723)"
        ),
        ZikrItem(
            orderNumber = 2,
            arabic = "اَللّٰهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوْتُ وَإِلَيْكَ النُّشُوْرُ",
            speakText = "اللهم بك أصبحنا وبك أمسينا وبك نحيا وبك نموت وإليك النشور",
            repeatUr = "صبح و شام ۱ بار",
            repeatEn = "1 time morning & evening",
            translationUr = "اے اللہ! تیرے ہی حکم سے ہم نے صبح کی، تیرے ہی حکم سے شام کی، تیرے ہی حکم سے زندہ ہیں، تیرے ہی حکم سے مرتے ہیں اور تیری ہی طرف لوٹ کر جانا ہے۔",
            translationEn = "O Allah, by You we enter morning and evening, by You we live and die, and to You is the final return.",
            refUr = "(حوالہ: جامع ترمذی: 3391)",
            refEn = "(Ref: Jami` at-Tirmidhi: 3391)"
        ),
        ZikrItem(
            orderNumber = 3,
            arabic = "سُبْحَانَ اللّٰهِ وَبِحَمْدِهِ",
            speakText = "سبحان الله وبحمده",
            repeatUr = "صبح و شام ۱۰۰ بار",
            repeatEn = "100 times morning & evening",
            translationUr = "اللہ پاک ہے اور اپنی تعریف کے ساتھ (میں اس کی پاکی بیان کرتا ہوں)۔",
            translationEn = "Glory be to Allah and praise be to Him.",
            refUr = "(حوالہ: صحیح مسلم: 2692)",
            refEn = "(Ref: Sahih Muslim: 2692)"
        ),
        ZikrItem(
            orderNumber = 4,
            arabic = "بِسْمِ اللّٰهِ الَّذِيْ لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيْعُ الْعَلِيْمُ",
            speakText = "بسم الله الذي لا يضر مع اسمه شيء في الأرض ولا في السماء وهو السميع العليم",
            repeatUr = "صبح و شام ۳ بار",
            repeatEn = "3 times morning & evening",
            translationUr = "اس اللہ کے نام سے جس کے نام کی برکت سے زمین و آسمان کی کوئی چیز نقصان نہیں پہنچا سکتی، اور وہ خوب سننے والا، سب کچھ جاننے والا ہے۔",
            translationEn = "In the name of Allah, with whose name nothing on earth or in heaven can cause harm, and He is All-Hearing, All-Knowing.",
            refUr = "(حوالہ: ابو داود: 5088 / ترمذی: 3388)",
            refEn = "(Ref: Abu Dawud: 5088 / Tirmidhi: 3388)"
        ),
        ZikrItem(
            orderNumber = 5,
            arabic = "رَضِيْتُ بِاللّٰهِ رَبًّا، وَبِالْإِسْلَامِ دِيْنًا، وَبِمُحَمَّدٍ ﷺ نَبِيًّا",
            speakText = "رضيت بالله ربا وبالإسلام دينا وبمحمد نبيا",
            repeatUr = "صبح و شام ۳ بار",
            repeatEn = "3 times morning & evening",
            translationUr = "میں اللہ کے رب ہونے، اسلام کے دین ہونے اور حضرت محمد (ﷺ) کے نبی ہونے پر راضی اور خوش ہوں۔",
            translationEn = "I am pleased with Allah as my Lord, Islam as my religion, and Muhammad (PBUH) as my Prophet.",
            refUr = "(حوالہ: سنن ابو داود: 5072)",
            refEn = "(Ref: Sunan Abi Dawud: 5072)"
        )
    )

    val janazaDuasList: List<ZikrItem> = listOf(
        ZikrItem(
            orderNumber = 1,
            arabic = "اَللّٰهُمَّ اغْفِرْ لِحَيِّنَا وَمَيِّتِنَا وَشَاهِدِنَا وَغَائِبِنَا وَصَغِيْرِنَا وَكَبِيْرِنَا وَذَكَرِنَا وَأُنْثَانَا، اَللّٰهُمَّ مَنْ أَحْيَيْتَهُ مِنَّا فَأَحْيِهِ عَلَى الْإِسْلَامِ، وَمَنْ تَوَفَّيْتَهُ مِنَّا فَتَوَفَّهُ عَلَى الْإِيْمَانِ",
            speakText = "اللهم اغفر لحينا وميتنا وشاهدنا وغائبنا وصغيرنا وكبيرنا وذكرنا وأنثانا اللهم من أحييته منا فأحيه على الإسلام ومن توفيته منا فتوفه على الإيمان",
            repeatUr = "دعا ۱ (بالغ میت کے لیے جامع مسنون دعا)",
            repeatEn = "Dua 1 (Comprehensive Dua for Adult Deceased)",
            translationUr = "اے اللہ! ہمارے زندوں اور مردوں، حاضر اور غائب، چھوٹوں اور بڑوں، مردوں اور عورتوں کی مغفرت فرما۔ ہم میں سے جسے تو زندہ رکھے اسے اسلام پر زندہ رکھ اور جسے وفات دے اسے ایمان پر وفات دے۔",
            translationEn = "O Allah, forgive our living and dead, present and absent, young and old, males and females. Whomever You keep alive, keep upon Islam; whomever You cause to die, let die upon Iman.",
            refUr = "(حوالہ: سنن ترمذی: 1024 / ابو داود: 3201)",
            refEn = "(Ref: Jami` at-Tirmidhi: 1024 / Abu Dawud: 3201)"
        ),
        ZikrItem(
            orderNumber = 2,
            arabic = "اَللّٰهُمَّ اغْفِرْ لَهُ وَارْحَمْهُ وَعَافِهِ وَاعْفُ عَنْهُ، وَأَكْرِمْ نُزُلَهُ، وَوَسِّعْ مُدْخَلَهُ، وَاغْسِلْهُ بِالْمَاءِ وَالثَّلْجِ وَالْبَرَدِ، وَنَقِّهِ مِنَ الْخَطَايَا كَمَا نَقَّيْتَ الثَّوْبَ الْأَبْيَضَ مِنَ الدَّنَسِ، وَأَبْدِلْهُ دَارًا خَيْرًا مِّنْ دَارِهِ، وَأَهْلًا خَيْرًا مِّنْ أَهْلِهِ، وَزَوْجًا خَيْرًا مِّنْ زَوْجِهِ، وَأَدْخِلْهُ الْجَنَّةَ وَأَعِذْهُ مِنْ عَذَابِ الْقَبْرِ وَمِنْ عَذَابِ النَّارِ",
            speakText = "اللهم اغفر له وارحمه وعافه واعف عنه وأكرم نزله ووسع مدخله واغسله بالماء والثلج والبرد ونقه من الخطايا كما نقيت الثوب الأبيض من الدنس وأبدله دارا خيرا من داره وأهلا خيرا من أهله وزوجا خيرا من زوجه وأدخله الجنة وأعذه من عذاب القبر ومن عذاب النار",
            repeatUr = "دعا ۲ (میت کے لیے بخشش، رحمت اور جنت کی بڑی دعا)",
            repeatEn = "Dua 2 (Great Dua for Forgiveness, Mercy & Paradise)",
            translationUr = "اے اللہ! اسے بخش دے، اس پر رحم فرما، اسے عافیت دے اور اس سے درگزر فرما۔ اس کی مہمانی عزت والی کر، اس کی قبر کشادہ فرما، اسے پانی، برف اور اولوں سے دھو دے اور گناہوں سے یوں پاک کر دے جیسے سفید کپڑا میل سے پاک کیا جاتا ہے۔ اسے اس کے گھر، گھر والوں اور ساتھی سے بہتر عطا فرما، اسے جنت میں داخل فرما اور قبر و جہنم کے عذاب سے بچا۔",
            translationEn = "O Allah, forgive him, have mercy upon him, give him peace and pardon him. Honor his reception, widen his grave, wash him with water, snow and ice, and cleanse him of sins as a white garment is cleansed of stain. Grant him a better home, family and spouse, admit him to Paradise and protect him from the torment of the grave and Fire.",
            refUr = "(حوالہ: صحیح مسلم: 963 — عورت کے لیے ضمیر مؤنث: لَهَا، ارْحَمْهَا، عَافِهَا پڑھیں)",
            refEn = "(Ref: Sahih Muslim: 963 — use feminine pronouns Laha/Irhamha for a female)"
        ),
        ZikrItem(
            orderNumber = 3,
            arabic = "اَللّٰهُمَّ إِنَّ فُلَانَ بْنَ فُلَانٍ فِيْ ذِمَّتِكَ، وَحَبْلِ جِوَارِكَ، فَقِهِ مِنْ فِتْنَةِ الْقَبْرِ وَعَذَابِ النَّارِ، وَأَنْتَ أَهْلُ الْوَفَاءِ وَالْحَقِّ، فَاغْفِرْ لَهُ وَارْحَمْهُ، إِنَّكَ أَنْتَ الْغَفُوْرُ الرَّحِيْمُ",
            speakText = "اللهم إن فلان بن فلان في ذمتك وحبل جوارك فقه من فتنة القبر وعذاب النار وأنت أهل الوفاء والحق فاغفر له وارحمه إنك أنت الغفور الرحيم",
            repeatUr = "دعا ۳ (میت کی امان اور قبر و جہنم سے حفاظت کی دعا)",
            repeatEn = "Dua 3 (Dua for Allah's Protection & Refuge)",
            translationUr = "اے اللہ! بے شک فلاں بن فلاں تیری پناہ اور امان میں ہے، پس تو اسے قبر کے فتنے اور آگ کے عذاب سے بچا، تو ہی وفا اور حق والا ہے، پس اسے بخش دے اور اس پر رحم فرما، بے شک تو ہی بڑا بخشنے والا نہایت رحم والا ہے۔",
            translationEn = "O Allah, indeed [name] is under Your protection and covenant, so protect him from the trial of the grave and punishment of the Fire. You are the Possessor of faithfulness and truth, so forgive him and have mercy on him; indeed You are All-Forgiving, Most Merciful.",
            refUr = "(حوالہ: سنن ابو داود: 3202)",
            refEn = "(Ref: Sunan Abi Dawud: 3202)"
        ),
        ZikrItem(
            orderNumber = 4,
            arabic = "اَللّٰهُمَّ اجْعَلْهُ لَنَا فَرَطًا، وَّاجْعَلْهُ لَنَا سَلَفًا وَّأَجْرًا وَّذُخْرًا، وَّاجْعَلْهُ لَنَا شَافِعًا وَّمُشَفَّعًا",
            speakText = "اللهم اجعله لنا فرطا واجعله لنا سلفا وأجرا وذخرا واجعله لنا شافعا ومشفعا",
            repeatUr = "دعا ۴ (نابالغ بچے کے لیے مسنون دعا)",
            repeatEn = "Dua 4 (Masnoon Dua for Deceased Young Child)",
            translationUr = "اے اللہ! اس بچے کو ہمارے لیے آگے جا کر سامانِ راحت تیار کرنے والا (پیش رو)، پیشگی اجر و ذخیرۂ آخرت، اور ایسا سفارشی بنا جس کی سفارش قبول ہو۔",
            translationEn = "O Allah, make him a forerunner for us, an advance reward and stored treasure, and an intercessor whose intercession is accepted.",
            refUr = "(حوالہ: صحیح بخاری / سنن البیہقی — نابالغ بچی کے لیے اجْعَلْهَا اور شَافِعَةً وَّمُشَفَّعَةً پڑھیں)",
            refEn = "(Ref: Sahih al-Bukhari / Al-Bayhaqi — for a girl say Aj'alha & Shafi'atan wa Mushaffa'ah)"
        )
    )
}
