# نور کاشف (Noor Kashif) — Complete Offline PWA & Android Capacitor Folder

- **App Name:** نور کاشف (Noor Kashif)
- **Package ID:** `com.noorkashif.app`
- **Architecture:** 100% Offline-First HTML/CSS/JS + Service Worker (`www/sw.js`) + Capacitor Android APK Builder (`.github/workflows/build-apk.yml`)

## Folder Structure
- `noor-kashif.html` — **Complete all-in-one standalone HTML file** (open directly on any phone or PC browser, 100% offline, zero external files needed)
- `www/index.html` — Main Urdu RTL app shell & built-in splash overlay (for PWA / Capacitor APK builds)
- `www/styles.css` — Mobile-first `360px–460px` theme, dark/night mode, large font mode
- `www/app.js` — All 17 Namaz lessons, Asma-ul-Husna, Ahadees, After-Salah & Morning/Evening Azkar, Janaza Duas, Tasbeeh counter, 17-lesson Progress Tracker, Global Search, 5-MCQ Quick Quiz, About section, and hidden 5-tap (`7860`) admin editor
- `www/manifest.json` — Offline PWA manifest (`com.noorkashif.app`)
- `www/sw.js` — Cache-first Service Worker for offline reliability
- `www/icons/icon-512.svg` — `512x512` launcher icon vector asset
- `resources/splash.svg` — `1080x1920` splash screen vector asset
- `package.json` & `capacitor.config.json` — Capacitor Android packaging config
- `.github/workflows/build-apk.yml` — Cloud APK builder for GitHub Actions (outputs Debug & Unsigned Release APKs)

## Quick Build Guide (Without PC)
1. Upload everything inside this `noor-kashif-pwa/` folder to a GitHub repository.
2. Open the **Actions** tab on GitHub — **Build Noor Kashif Android APK** will run automatically.
3. Download **`noor-kashif-debug-apk`** from **Artifacts**, unzip it on your phone, and install the `.apk`.
