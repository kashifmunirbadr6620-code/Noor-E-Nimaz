package com.example.data

import com.example.model.Lesson
import com.example.model.LessonLine
import com.example.model.LughatItem
import com.example.model.QuizQuestion
import com.example.model.WordItem

internal val lessonsPart2: List<Lesson> = listOf(
    Lesson(
        id = 8,
        titleUr = "سجدہ کی تسبیح",
        titleEn = "Sajda Tasbeeh",
        romanKeys = "sajda tasbeeh subhana rabbiyal ala",
        lines = listOf(
            LessonLine(
                label = "سجدہ کی تسبیح",
                words = listOf(
                    WordItem("سُبْحَانَ", "پاک ہے", "سُب-حَا-نَ (Subhana)"),
                    WordItem("رَبِّيَ", "میرا رب", "رَب-بِ-یَ (Rabbiya)"),
                    WordItem("الْأَعْلٰى", "سب سے بلند", "اَل-اَع-لٰی (Al-A'la)")
                ),
                fullUr = "پاک ہے میرا رب جو سب سے بلند و بالا ہے۔"
            )
        ),
        lughat = listOf(
            LughatItem("سُبْحَانَ", "پاک ہے"),
            LughatItem("رَبِّيَ", "میرا رب"),
            LughatItem("الْأَعْلٰى", "سب سے بلند و بالا")
        ),
        customQuiz = listOf(
            QuizQuestion("سجدے میں کون سی تسبیح پڑھی جاتی ہے؟", "", listOf("سُبْحَانَ رَبِّيَ الْأَعْلٰى", "سُبْحَانَ رَبِّيَ الْعَظِيْمِ", "رَبَّنَا وَلَكَ الْحَمْدُ", "أَعُوْذُ بِاللّٰهِ"), 0),
            QuizQuestion("\"الْأَعْلٰى\" کا مطلب کیا ہے؟", "الْأَعْلٰى", listOf("سب سے بلند و بالا", "بخشنے والا", "سننے والا", "دیکھنے والا"), 0),
            QuizQuestion("سُبْحَانَ رَبِّيَ الْأَعْلٰى کا مکمل ترجمہ کیا ہے؟", "سُبْحَانَ رَبِّيَ الْأَعْلٰى", listOf("پاک ہے میرا رب جو سب سے بلند و بالا ہے", "پاک ہے میرا رب جو عظمت والا ہے", "اللہ سب سے بڑا ہے", "تیرے سوا کوئی معبود نہیں"), 0),
            QuizQuestion("\"سُبْحَانَ\" کا اردو معنی کیا ہے؟", "سُبْحَانَ", listOf("پاک ہے", "پالنے والا", "آخری", "شکر گزار"), 0),
            QuizQuestion("\"رَبِّيَ\" کس کے لیے استعمال ہوا ہے؟", "رَبِّيَ", listOf("میرا رب", "تیرا نام", "ان کا گھر", "ہمارا دین"), 0),
            QuizQuestion("سجدے میں جب بندہ سب سے نیچے (زمین پر) ہوتا ہے تو اللہ کو کس نام سے یاد کرتا ہے؟", "الْأَعْلٰى", listOf("الْأَعْلٰى (سب سے بلند)", "الْخَنَّاسِ", "الْفَلَقِ", "الرَّجِيْمِ"), 0),
            QuizQuestion("ہر رکعت میں کتنے سجدے ہوتے ہیں؟", "", listOf("دو", "تین", "چار", "ایک"), 0),
            QuizQuestion("سجدے کی تسبیح کم از کم کتنی بار پڑھنا سنت ہے؟", "", listOf("تین بار", "سات بار", "بارہ بار", "بیس بار"), 0),
            QuizQuestion("جملہ مکمل کریں: سُبْحَانَ رَبِّيَ _____", "سُبْحَانَ رَبِّيَ ___", listOf("الْأَعْلٰى", "الْعَظِيْمِ", "الرَّحِيْمِ", "الصَّمَدُ"), 0),
            QuizQuestion("بندہ اپنے رب کے سب سے زیادہ قریب کس حالت میں ہوتا ہے؟", "", listOf("سجدے کی حالت میں", "چلتے ہوئے", "کھیلتے ہوئے", "سوتے ہوئے"), 0)
        )
    ),
    Lesson(
        id = 9,
        titleUr = "تشہد / التحیات",
        titleEn = "Tashahhud / Attahiyyat",
        romanKeys = "tashahhud attahiyyat lillahi wassalawatu tayyibat ashadu an la ilaha illallah",
        lines = listOf(
            LessonLine(
                label = "سطر ۱",
                words = listOf(
                    WordItem("اَلتَّحِيَّاتُ", "تمام قولی عبادتیں", "اَت-تَ-حِی-یَا-تُ (Attahiyyatu)"),
                    WordItem("لِلّٰهِ", "اللہ کے لیے ہیں", "لِل-لٰ-ہِ (Lillahi)"),
                    WordItem("وَالصَّلَوَاتُ", "اور تمام بدنی عبادتیں", "وَص-صَ-لَ-وَا-تُ (Wassalawatu)"),
                    WordItem("وَالطَّيِّبَاتُ", "اور تمام مالی عبادتیں", "وَط-طَی-یِ-بَا-تُ (Wat-Tayyibat)")
                ),
                fullUr = "تمام قولی، بدنی اور مالی عبادتیں اللہ ہی کے لیے ہیں۔"
            ),
            LessonLine(
                label = "سطر ۲",
                words = listOf(
                    WordItem("اَلسَّلَامُ", "سلامتی ہو", "اَس-سَ-لَا-مُ (Assalamu)"),
                    WordItem("عَلَيْكَ", "آپ پر", "عَ-لَی-کَ (Alaika)"),
                    WordItem("أَيُّهَا النَّبِيُّ", "اے نبی ﷺ", "اَی-یُ-ہَن-نَ-بِی-یُ (Ayyuhan-Nabiyyu)"),
                    WordItem("وَرَحْمَةُ اللّٰهِ", "اور اللہ کی رحمت", "وَ-رَح-مَ-تُ-ل-لٰہِ (Wa Rahmatullahi)"),
                    WordItem("وَبَرَكَاتُهُ", "اور اس کی برکتیں", "وَ-بَ-رَ-کَا-تُہُ (Wa Barakatuh)")
                ),
                fullUr = "اے نبی (ﷺ)! آپ پر سلامتی ہو اور اللہ کی رحمت اور اس کی برکتیں نازل ہوں۔"
            ),
            LessonLine(
                label = "سطر ۳",
                words = listOf(
                    WordItem("اَلسَّلَامُ", "سلامتی ہو", "اَس-سَ-لَا-مُ (Assalamu)"),
                    WordItem("عَلَيْنَا", "ہم پر", "عَ-لَی-نَا (Alaina)"),
                    WordItem("وَعَلٰى", "اور پر", "وَ-عَ-لٰی (Wa Ala)"),
                    WordItem("عِبَادِ اللّٰهِ", "اللہ کے بندوں", "عِ-بَا-دِل-لٰہِ (Ibadillahi)"),
                    WordItem("الصَّالِحِيْنَ", "نیک", "اَص-صَا-لِ-حِی-نَ (As-Saliheen)")
                ),
                fullUr = "ہم پر اور اللہ کے تمام نیک بندوں پر سلامتی ہو۔"
            ),
            LessonLine(
                label = "سطر ۴",
                words = listOf(
                    WordItem("أَشْهَدُ", "میں گواہی دیتا ہوں", "اَش-ہَ-دُ (Ash-hadu)"),
                    WordItem("أَنْ لَّا إِلٰهَ", "کہ کوئی معبود نہیں", "اَن-لَا اِ-لٰ-ہَ (An La Ilaha)"),
                    WordItem("إِلَّا اللّٰهُ", "سوائے اللہ کے", "اِل-لَل-لٰہُ (Illallahu)")
                ),
                fullUr = "میں گواہی دیتا ہوں کہ اللہ کے سوا کوئی معبود نہیں۔"
            ),
            LessonLine(
                label = "سطر ۵",
                words = listOf(
                    WordItem("وَأَشْهَدُ", "اور میں گواہی دیتا ہوں", "وَ-اَش-ہَ-دُ (Wa Ash-hadu)"),
                    WordItem("أَنَّ مُحَمَّدًا", "کہ بے شک محمد ﷺ", "اَن-نَ مُ-حَم-مَ-دَن (Anna Muhammadan)"),
                    WordItem("عَبْدُهُ", "اس کے بندے", "عَب-دُ-ہُ (Abduhu)"),
                    WordItem("وَرَسُوْلُهُ", "اور اس کے رسول ہیں", "وَ-رَ-سُو-لُہُ (Wa Rasuluh)")
                ),
                fullUr = "اور میں گواہی دیتا ہوں کہ حضرت محمد (ﷺ) اللہ کے بندے اور اس کے رسول ہیں۔"
            )
        ),
        lughat = listOf(
            LughatItem("اَلتَّحِيَّاتُ", "تمام قولی عبادتیں"),
            LughatItem("وَالصَّلَوَاتُ", "اور بدنی عبادتیں / نمازیں"),
            LughatItem("وَالطَّيِّبَاتُ", "اور مالی / پاکیزہ عبادتیں"),
            LughatItem("اَلسَّلَامُ", "سلامتی"),
            LughatItem("أَيُّهَا النَّبِيُّ", "اے نبی ﷺ"),
            LughatItem("عِبَادِ اللّٰهِ", "اللہ کے بندے"),
            LughatItem("الصَّالِحِيْنَ", "نیک لوگ"),
            LughatItem("أَشْهَدُ", "میں گواہی دیتا ہوں"),
            LughatItem("عَبْدُهُ", "اس کے بندے"),
            LughatItem("وَرَسُوْلُهُ", "اور اس کے رسول")
        )
    ),
    Lesson(
        id = 10,
        titleUr = "درودِ ابراہیم",
        titleEn = "Durood-e-Ibrahim",
        romanKeys = "durood ibrahim allahumma salli ala muhammadin barik hameed majeed",
        lines = listOf(
            LessonLine(
                label = "سطر ۱",
                words = listOf(
                    WordItem("اَللّٰهُمَّ", "اے اللہ", "اَل-لٰ-ہُم-مَ (Allahumma)"),
                    WordItem("صَلِّ", "رحمت نازل فرما", "صَل-لِ (Salli)"),
                    WordItem("عَلٰى مُحَمَّدٍ", "محمد ﷺ پر", "عَ-لٰی مُ-حَم-مَ-دٍ (Ala Muhammadin)"),
                    WordItem("وَّعَلٰى آلِ مُحَمَّدٍ", "اور محمد ﷺ کی آل پر", "وَ-عَ-لٰی آ-لِ مُ-حَم-مَ-دٍ (Wa Ala Ali Muhammad)")
                ),
                fullUr = "اے اللہ! حضرت محمد (ﷺ) پر اور حضرت محمد (ﷺ) کی آل پر رحمت نازل فرما۔"
            ),
            LessonLine(
                label = "سطر ۲",
                words = listOf(
                    WordItem("كَمَا صَلَّيْتَ", "جیسا کہ تو نے رحمت نازل فرمائی", "کَ-مَا صَل-لَی-تَ (Kama Sallaita)"),
                    WordItem("عَلٰى إِبْرَاهِيْمَ", "ابراہیمؑ پر", "عَ-لٰی اِب-رَا-ہِی-مَ (Ala Ibrahima)"),
                    WordItem("وَعَلٰى آلِ إِبْرَاهِيْمَ", "اور ابراہیمؑ کی آل پر", "وَ-عَ-لٰی آ-لِ اِب-رَا-ہِی-مَ (Wa Ala Ali Ibrahim)"),
                    WordItem("إِنَّكَ حَمِيْدٌ مَّجِيْدٌ", "بے شک تو تعریف کے لائق، بزرگی والا ہے", "اِن-نَ-کَ حَ-مِی-دُم مَ-جِی-دُ (Innaka Hameedum Majeed)")
                ),
                fullUr = "جیسا کہ تو نے حضرت ابراہیم (علیہ السلام) اور ان کی آل پر رحمت نازل فرمائی، بے شک تو تعریف کے لائق، بڑی بزرگی والا ہے۔"
            ),
            LessonLine(
                label = "سطر ۳",
                words = listOf(
                    WordItem("اَللّٰهُمَّ", "اے اللہ", "اَل-لٰ-ہُم-مَ (Allahumma)"),
                    WordItem("بَارِكْ", "برکت نازل فرما", "بَا-رِک (Barik)"),
                    WordItem("عَلٰى مُحَمَّدٍ", "محمد ﷺ پر", "عَ-لٰی مُ-حَم-مَ-دٍ (Ala Muhammadin)"),
                    WordItem("وَّعَلٰى آلِ مُحَمَّدٍ", "اور محمد ﷺ کی آل پر", "وَ-عَ-لٰی آ-لِ مُ-حَم-مَ-دٍ (Wa Ala Ali Muhammad)")
                ),
                fullUr = "اے اللہ! حضرت محمد (ﷺ) پر اور حضرت محمد (ﷺ) کی آل پر برکت نازل فرما۔"
            ),
            LessonLine(
                label = "سطر ۴",
                words = listOf(
                    WordItem("كَمَا بَارَكْتَ", "جیسا کہ تو نے برکت نازل فرمائی", "کَ-مَا بَا-رَک-تَ (Kama Barakta)"),
                    WordItem("عَلٰى إِبْرَاهِيْمَ", "ابراہیمؑ پر", "عَ-لٰی اِب-رَا-ہِی-مَ (Ala Ibrahima)"),
                    WordItem("وَعَلٰى آلِ إِبْرَاهِيْمَ", "اور ابراہیمؑ کی آل پر", "وَ-عَ-لٰی آ-لِ اِب-رَا-ہِی-مَ (Wa Ala Ali Ibrahim)"),
                    WordItem("إِنَّكَ حَمِيْدٌ مَّجِيْدٌ", "بے شک تو تعریف کے لائق، بزرگی والا ہے", "اِن-نَ-کَ حَ-مِی-دُم مَ-جِی-دُ (Innaka Hameedum Majeed)")
                ),
                fullUr = "جیسا کہ تو نے حضرت ابراہیم (علیہ السلام) اور ان کی آل پر برکت نازل فرمائی، بے شک تو تعریف کے لائق، بڑی بزرگی والا ہے۔"
            )
        ),
        lughat = listOf(
            LughatItem("صَلِّ", "رحمت نازل فرما"),
            LughatItem("آلِ", "اولاد / گھرانہ / پیروکار"),
            LughatItem("كَمَا", "جیسا کہ"),
            LughatItem("بَارِكْ", "برکت نازل فرما"),
            LughatItem("إِنَّكَ", "بے شک تو"),
            LughatItem("حَمِيْدٌ", "تعریف کے لائق"),
            LughatItem("مَّجِيْدٌ", "بزرگی والا")
        )
    ),
    Lesson(
        id = 11,
        titleUr = "درود کے بعد کی دعا",
        titleEn = "Dua after Durood (Dua-e-Masura)",
        romanKeys = "dua after durood masura allahumma inni zalamtu nafsi zulman kaseeran ghafurur raheem",
        lines = listOf(
            LessonLine(
                label = "سطر ۱",
                words = listOf(
                    WordItem("اَللّٰهُمَّ", "اے اللہ", "اَل-لٰ-ہُم-مَ (Allahumma)"),
                    WordItem("إِنِّيْ", "بے شک میں نے", "اِن-نِی (Inni)"),
                    WordItem("ظَلَمْتُ", "ظلم کیا", "ظَ-لَم-تُ (Zalamtu)"),
                    WordItem("نَفْسِيْ", "اپنی جان پر", "نَف-سِی (Nafsi)"),
                    WordItem("ظُلْمًا كَثِيْرًا", "بہت بڑا ظلم", "ظُل-مَن کَ-ثِی-رَا (Zulman Kaseeran)")
                ),
                fullUr = "اے اللہ! بے شک میں نے اپنی جان پر بہت بڑا ظلم کیا ہے۔"
            ),
            LessonLine(
                label = "سطر ۲",
                words = listOf(
                    WordItem("وَلَا يَغْفِرُ", "اور نہیں بخشتا", "وَ-لَا یَغ-فِ-رُ (Wa La Yaghfiru)"),
                    WordItem("الذُّنُوْبَ", "گناہوں کو", "اَذ-ذُ-نُو-بَ (Az-Zunooba)"),
                    WordItem("إِلَّا أَنْتَ", "سوائے تیرے", "اِل-لَا اَن-تَ (Illa Anta)")
                ),
                fullUr = "اور تیرے سوا گناہوں کو کوئی بخشنے والا نہیں۔"
            ),
            LessonLine(
                label = "سطر ۳",
                words = listOf(
                    WordItem("فَاغْفِرْ لِيْ", "پس تو مجھے بخش دے", "فَغ-فِر لِی (Faghfir Li)"),
                    WordItem("مَغْفِرَةً", "بخشش", "مَغ-فِ-رَ-تَن (Maghfiratan)"),
                    WordItem("مِّنْ عِنْدِكَ", "اپنے پاس سے", "مِن عِن-دِ-کَ (Min Indika)"),
                    WordItem("وَارْحَمْنِيْ", "اور مجھ پر رحم فرما", "وَر-حَم-نِی (Warhamni)")
                ),
                fullUr = "پس تو مجھے اپنے پاس سے خاص بخشش عطا فرما اور مجھ پر رحم فرما۔"
            ),
            LessonLine(
                label = "سطر ۴",
                words = listOf(
                    WordItem("إِنَّكَ", "بے شک تو", "اِن-نَ-کَ (Innaka)"),
                    WordItem("أَنْتَ", "ہی", "اَن-تَ (Anta)"),
                    WordItem("الْغَفُوْرُ", "بڑا بخشنے والا", "اَل-غَ-فُو-رُ (Al-Ghafooru)"),
                    WordItem("الرَّحِيْمُ", "نہایت رحم والا ہے", "اَر-رَ-حِی-مُ (Ar-Raheem)")
                ),
                fullUr = "بے شک تو ہی بڑا بخشنے والا، نہایت رحم کرنے والا ہے۔"
            )
        ),
        lughat = listOf(
            LughatItem("ظَلَمْتُ", "میں نے ظلم کیا"),
            LughatItem("نَفْسِيْ", "اپنی جان پر"),
            LughatItem("كَثِيْرًا", "بہت زیادہ"),
            LughatItem("يَغْفِرُ", "بخشتا ہے"),
            LughatItem("الذُّنُوْبَ", "گناہ"),
            LughatItem("فَاغْفِرْ لِيْ", "پس مجھے معاف کر دے"),
            LughatItem("مِّنْ عِنْدِكَ", "اپنے پاس سے"),
            LughatItem("وَارْحَمْنِيْ", "اور مجھ پر رحم فرما"),
            LughatItem("الْغَفُوْرُ", "بہت بخشنے والا")
        )
    ),
    Lesson(
        id = 12,
        titleUr = "دعائے قنوت",
        titleEn = "Dua Qunoot",
        romanKeys = "dua qunoot allahumma inna nastaeenuka nastaghfiruka numinu bika natawakkalu iyyaka nabudu",
        lines = listOf(
            LessonLine(
                label = "سطر ۱",
                words = listOf(
                    WordItem("اَللّٰهُمَّ", "اے اللہ", "اَل-لٰ-ہُم-مَ (Allahumma)"),
                    WordItem("إِنَّا", "بے شک ہم", "اِن-نَا (Inna)"),
                    WordItem("نَسْتَعِيْنُكَ", "تجھ سے مدد مانگتے ہیں", "نَس-تَ-عِی-نُ-کَ (Nasta'eenuka)"),
                    WordItem("وَنَسْتَغْفِرُكَ", "اور تجھ سے بخشش مانگتے ہیں", "وَ-نَس-تَغ-فِ-رُ-کَ (Wa Nastaghfiruka)")
                ),
                fullUr = "اے اللہ! بے شک ہم تجھ سے مدد مانگتے ہیں اور تجھ سے بخشش طلب کرتے ہیں۔"
            ),
            LessonLine(
                label = "سطر ۲",
                words = listOf(
                    WordItem("وَنُؤْمِنُ بِكَ", "اور ہم تجھ پر ایمان رکھتے ہیں", "وَ-نُؤ-مِ-نُ بِ-کَ (Wa Nu'minu Bika)"),
                    WordItem("وَنَتَوَكَّلُ عَلَيْكَ", "اور تجھ پر بھروسہ کرتے ہیں", "وَ-نَ-تَ-وَک-کَ-لُ عَ-لَی-کَ (Wa Natawakkalu Alaika)"),
                    WordItem("وَنُثْنِيْ عَلَيْكَ الْخَيْرَ", "اور تیری بہترین تعریف کرتے ہیں", "وَ-نُث-نِی عَ-لَی-کَل خَی-رَ (Wa Nusni Alaikal Khair)")
                ),
                fullUr = "اور ہم تجھ پر ایمان لاتے ہیں اور تجھی پر بھروسہ کرتے ہیں اور تیری بہترین تعریف کرتے ہیں۔"
            ),
            LessonLine(
                label = "سطر ۳",
                words = listOf(
                    WordItem("وَنَشْكُرُكَ", "اور ہم تیرا شکر کرتے ہیں", "وَ-نَش-کُ-رُ-کَ (Wa Nashkuruka)"),
                    WordItem("وَلَا نَكْفُرُكَ", "اور تیری ناشکری نہیں کرتے", "وَ-لَا نَک-فُ-رُ-کَ (Wa La Nakfuruka)"),
                    WordItem("وَنَخْلَعُ وَنَتْرُكُ", "اور ہم الگ ہوتے اور چھوڑتے ہیں", "وَ-نَخ-لَ-عُ وَ-نَت-رُ-کُ (Wa Nakhla'u Wa Natruku)"),
                    WordItem("مَنْ يَّفْجُرُكَ", "اسے جو تیری نافرمانی کرے", "مَن یَف-جُ-رُ-کَ (Man Yafjuruka)")
                ),
                fullUr = "اور ہم تیرا شکر ادا کرتے ہیں اور تیری ناشکری نہیں کرتے، اور ہر اس شخص سے الگ ہو کر اسے چھوڑ دیتے ہیں جو تیری نافرمانی کرے۔"
            ),
            LessonLine(
                label = "سطر ۴",
                words = listOf(
                    WordItem("اَللّٰهُمَّ", "اے اللہ", "اَل-لٰ-ہُم-مَ (Allahumma)"),
                    WordItem("إِيَّاكَ نَعْبُدُ", "ہم تیری ہی عبادت کرتے ہیں", "اِی-یَا-کَ نَع-بُ-دُ (Iyyaka Na'budu)"),
                    WordItem("وَلَكَ نُصَلِّيْ", "اور تیرے ہی لیے نماز پڑھتے ہیں", "وَ-لَ-کَ نُ-صَل-لِی (Wa Laka Nusalli)"),
                    WordItem("وَنَسْجُدُ", "اور سجدہ کرتے ہیں", "وَ-نَس-جُ-دُ (Wa Nasjudu)")
                ),
                fullUr = "اے اللہ! ہم صرف تیری ہی عبادت کرتے ہیں اور تیرے ہی لیے نماز پڑھتے ہیں اور سجدہ کرتے ہیں۔"
            ),
            LessonLine(
                label = "سطر ۵",
                words = listOf(
                    WordItem("وَإِلَيْكَ نَسْعٰى", "اور تیری طرف دوڑتے ہیں", "وَ-اِ-لَی-کَ نَس-عٰی (Wa Ilaika Nas'a)"),
                    WordItem("وَنَحْفِدُ", "اور خدمت میں حاضر ہوتے ہیں", "وَ-نَح-فِ-دُ (Wa Nahfidu)"),
                    WordItem("وَنَرْجُوْ رَحْمَتَكَ", "اور تیری رحمت کی امید رکھتے ہیں", "وَ-نَر-جُو رَح-مَ-تَ-کَ (Wa Narju Rahmataka)"),
                    WordItem("وَنَخْشٰى عَذَابَكَ", "اور تیرے عذاب سے ڈرتے ہیں", "وَ-نَخ-شٰی عَ-ذَا-بَ-کَ (Wa Nakhsha Azabaka)")
                ),
                fullUr = "اور تیری ہی طرف دوڑتے اور جلد حاضر ہوتے ہیں، تیری رحمت کے امیدوار ہیں اور تیرے عذاب سے ڈرتے ہیں۔"
            ),
            LessonLine(
                label = "سطر ۶",
                words = listOf(
                    WordItem("إِنَّ عَذَابَكَ", "بے شک تیرا عذاب", "اِن-نَ عَ-ذَا-بَ-کَ (Inna Azabaka)"),
                    WordItem("بِالْكُفَّارِ", "کافروں کو", "بِل-کُف-فَا-رِ (Bil-Kuffari)"),
                    WordItem("مُلْحِقٌ", "پہنچنے والا ہے", "مُل-حِ-قُ (Mulhiq)")
                ),
                fullUr = "بے شک تیرا عذاب کافروں کو پہنچنے والا ہے۔"
            )
        ),
        lughat = listOf(
            LughatItem("نَسْتَعِيْنُكَ", "ہم تجھ سے مدد مانگتے ہیں"),
            LughatItem("نَسْتَغْفِرُكَ", "ہم تجھ سے بخشش مانگتے ہیں"),
            LughatItem("نَتَوَكَّلُ", "ہم بھروسہ کرتے ہیں"),
            LughatItem("نَشْكُرُكَ", "ہم تیرا شکر کرتے ہیں"),
            LughatItem("لَا نَكْفُرُكَ", "ہم تیری ناشکری نہیں کرتے"),
            LughatItem("نَخْلَعُ", "ہم الگ ہوتے ہیں"),
            LughatItem("يَّفْجُرُكَ", "تیری نافرمانی کرے"),
            LughatItem("نَسْعٰى", "ہم دوڑتے ہیں"),
            LughatItem("نَحْفِدُ", "ہم جلد حاضر ہوتے ہیں"),
            LughatItem("نَخْشٰى", "ہم ڈرتے ہیں"),
            LughatItem("مُلْحِقٌ", "پہنچنے والا")
        )
    ),
    Lesson(
        id = 13,
        titleUr = "تین قل (اخلاص، فلق، ناس)",
        titleEn = "Surah Ikhlas, Surah Falaq, Surah Naas",
        romanKeys = "surah ikhlas qul huwallahu ahad samad falaq rabbil falaq naas rabbin naas",
        lines = listOf(
            LessonLine(
                label = "سورۃ الاخلاص (۱)",
                words = listOf(
                    WordItem("قُلْ", "آپ کہہ دیجیے", "قُل (Qul)"),
                    WordItem("هُوَ", "وہ", "ہُ-وَ (Huwa)"),
                    WordItem("اللّٰهُ", "اللہ", "اَل-لٰ-ہُ (Allahu)"),
                    WordItem("أَحَدٌ", "ایک ہے", "اَ-حَ-دُ (Ahad)")
                ),
                fullUr = "آپ کہہ دیجیے کہ وہ اللہ ایک ہے۔"
            ),
            LessonLine(
                label = "سورۃ الاخلاص (۲)",
                words = listOf(
                    WordItem("اللّٰهُ", "اللہ", "اَل-لٰ-ہُ (Allahu)"),
                    WordItem("الصَّمَدُ", "بے نیاز ہے", "اَص-صَ-مَ-دُ (As-Samad)")
                ),
                fullUr = "اللہ بے نیاز ہے۔"
            ),
            LessonLine(
                label = "سورۃ الاخلاص (۳)",
                words = listOf(
                    WordItem("لَمْ يَلِدْ", "نہ اس نے کسی کو جنا", "لَم یَ-لِد (Lam Yalid)"),
                    WordItem("وَلَمْ يُوْلَدْ", "اور نہ وہ کسی سے جنا گیا", "وَ-لَم یُو-لَد (Wa Lam Yoolad)")
                ),
                fullUr = "نہ اس کی کوئی اولاد ہے اور نہ وہ کسی کی اولاد ہے۔"
            ),
            LessonLine(
                label = "سورۃ الاخلاص (۴)",
                words = listOf(
                    WordItem("وَلَمْ يَكُنْ", "اور نہیں ہے", "وَ-لَم یَ-کُن (Wa Lam Yakun)"),
                    WordItem("لَّهُ", "اس کا", "لَ-ہُ (Lahu)"),
                    WordItem("كُفُوًا", "ہمسر / برابر", "کُ-فُ-وَن (Kufuwan)"),
                    WordItem("أَحَدٌ", "کوئی ایک", "اَ-حَ-دُ (Ahad)")
                ),
                fullUr = "اور اس کے برابر کوئی ایک بھی نہیں ہے۔"
            ),
            LessonLine(
                label = "سورۃ الفلق (۱-۲)",
                words = listOf(
                    WordItem("قُلْ أَعُوْذُ", "کہہ دیجیے میں پناہ مانگتا ہوں", "قُل اَ-عُو-ذُ (Qul A'uzu)"),
                    WordItem("بِرَبِّ الْفَلَقِ", "صبح کے رب کی", "بِ-رَب-بِل فَ-لَ-قِ (Bi-Rabbil Falaq)"),
                    WordItem("مِنْ شَرِّ", "شر سے", "مِن شَر-رِ (Min Sharri)"),
                    WordItem("مَا خَلَقَ", "جو اس نے پیدا کیا", "مَا خَ-لَ-قَ (Ma Khalaq)")
                ),
                fullUr = "کہہ دیجیے: میں صبح کے رب کی پناہ مانگتا ہوں ہر اس چیز کے شر سے جو اس نے پیدا کی۔"
            ),
            LessonLine(
                label = "سورۃ الفلق (۳-۵)",
                words = listOf(
                    WordItem("وَمِنْ شَرِّ غَاسِقٍ إِذَا وَقَبَ", "اور اندھیری رات کے شر سے جب وہ چھا جائے", "غَا-سِ-قٍ اِ-ذَا وَ-قَ-بَ (Ghasiqin Iza Waqab)"),
                    WordItem("وَمِنْ شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ", "اور گرہوں میں پھونک مارنے والیوں کے شر سے", "اَن-نَف-فَا-ثَا-تِ فِل عُ-قَ-دِ (Naffasati Fil Uqad)"),
                    WordItem("وَمِنْ شَرِّ حَاسِدٍ إِذَا حَسَدَ", "اور حسد کرنے والے کے شر سے جب وہ حسد کرے", "حَا-سِ-دٍ اِ-ذَا حَ-سَ-دَ (Hasidin Iza Hasad)")
                ),
                fullUr = "اور اندھیری رات کے شر سے جب وہ چھا جائے، اور گرہوں میں پھونکنے والیوں کے شر سے، اور حسد کرنے والے کے شر سے جب وہ حسد کرے۔"
            ),
            LessonLine(
                label = "سورۃ الناس (۱-۳)",
                words = listOf(
                    WordItem("قُلْ أَعُوْذُ", "کہہ دیجیے میں پناہ مانگتا ہوں", "قُل اَ-عُو-ذُ (Qul A'uzu)"),
                    WordItem("بِرَبِّ النَّاسِ", "لوگوں کے رب کی", "بِ-رَب-بِن نَا-سِ (Bi-Rabbin Naas)"),
                    WordItem("مَلِكِ النَّاسِ", "لوگوں کے بادشاہ", "مَ-لِ-کِن نَا-سِ (Malikin Naas)"),
                    WordItem("إِلٰهِ النَّاسِ", "لوگوں کے معبود", "اِ-لٰ-ہِن نَا-سِ (Ilahin Naas)")
                ),
                fullUr = "کہہ دیجیے: میں تمام لوگوں کے رب، لوگوں کے بادشاہ اور لوگوں کے حقیقی معبود کی پناہ مانگتا ہوں۔"
            ),
            LessonLine(
                label = "سورۃ الناس (۴-۶)",
                words = listOf(
                    WordItem("مِنْ شَرِّ الْوَسْوَاسِ الْخَنَّاسِ", "وسوسہ ڈالنے والے پیچھے ہٹ جانے والے کے شر سے", "اَل-وَس-وَا-سِل خَن-نَا-سِ (Al-Waswasil Khannas)"),
                    WordItem("الَّذِيْ يُوَسْوِسُ فِيْ صُدُوْرِ النَّاسِ", "جو لوگوں کے سینوں میں وسوسہ ڈالتا ہے", "یُ-وَس-وِ-سُ فِی صُ-دُو-رِن نَا-سِ (Yuwaswisu Fi Sudoorin Naas)"),
                    WordItem("مِنَ الْجِنَّةِ وَالنَّاسِ", "جنوں میں سے ہو یا انسانوں میں سے", "مِ-نَل جِن-نَ-تِ وَن-نَا-سِ (Minal Jinnati Wan-Naas)")
                ),
                fullUr = "وسوسہ ڈالنے والے، پیچھے ہٹ جانے والے (شیطان) کے شر سے جو لوگوں کے سینوں میں وسوسہ ڈالتا ہے، خواہ وہ جنوں میں سے ہو یا انسانوں میں سے۔"
            )
        ),
        lughat = listOf(
            LughatItem("أَحَدٌ", "ایک / یکتا"),
            LughatItem("الصَّمَدُ", "بے نیاز"),
            LughatItem("كُفُوًا", "ہمسر / برابر"),
            LughatItem("الْفَلَقِ", "صبح"),
            LughatItem("شَرِّ", "برائی / شر"),
            LughatItem("غَاسِقٍ", "اندھیری رات"),
            LughatItem("حَاسِدٍ", "حسد کرنے والا"),
            LughatItem("النَّاسِ", "انسان / لوگ"),
            LughatItem("الْخَنَّاسِ", "پیچھے ہٹ جانے والا"),
            LughatItem("صُدُوْرِ", "سینے"),
            LughatItem("الْجِنَّةِ", "جنات")
        )
    ),
    Lesson(
        id = 14,
        titleUr = "والدین اور مغفرت کی دعا",
        titleEn = "Dua for Parents & Dua for Forgiveness",
        romanKeys = "dua parents forgiveness rabbir hamhuma kama rabbayani sagheera rabbana ghfir li waliwalidayya zalamna anfusana",
        lines = listOf(
            LessonLine(
                label = "والدین کے لیے دعا (۱)",
                words = listOf(
                    WordItem("رَبِّ", "اے میرے رب", "رَب-بِ (Rabbi)"),
                    WordItem("ارْحَمْهُمَا", "ان دونوں پر رحم فرما", "اِر-حَم-ہُ-مَا (Irhamhuma)"),
                    WordItem("كَمَا", "جیسا کہ", "کَ-مَا (Kama)"),
                    WordItem("رَبَّيَانِيْ", "ان دونوں نے مجھے پالا", "رَب-بَ-یَا-نِی (Rabbayani)"),
                    WordItem("صَغِيْرًا", "بچپن میں", "صَ-غِی-رَا (Sagheera)")
                ),
                fullUr = "اے میرے رب! میرے والدین پر رحم فرما جیسا کہ انہوں نے بچپن میں مجھے پیار سے پالا۔"
            ),
            LessonLine(
                label = "والدین اور مومنین کی مغفرت (۲)",
                words = listOf(
                    WordItem("رَبَّنَا", "اے ہمارے رب", "رَب-بَ-نَا (Rabbana)"),
                    WordItem("اغْفِرْ لِيْ", "مجھے بخش دے", "اِغ-فِر لِی (Ighfir Li)"),
                    WordItem("وَلِوَالِدَيَّ", "اور میرے والدین کو", "وَ-لِ-وَا-لِ-دَی-یَ (Wa Li-Walidayya)"),
                    WordItem("وَلِلْمُؤْمِنِيْنَ", "اور تمام مومنوں کو", "وَ-لِل-مُؤ-مِ-نِی-نَ (Wa Lil-Mu'mineen)"),
                    WordItem("يَوْمَ يَقُوْمُ الْحِسَابُ", "جس دن حساب قائم ہوگا", "یَو-مَ یَ-قُو-مُل حِ-سَا-بُ (Yauma Yaqoomul Hisab)")
                ),
                fullUr = "اے ہمارے رب! مجھے، میرے والدین کو اور تمام مومنوں کو اس دن بخش دے جس دن حساب قائم ہوگا۔"
            ),
            LessonLine(
                label = "مغفرت کی دعا (۳)",
                words = listOf(
                    WordItem("رَبَّنَا", "اے ہمارے رب", "رَب-بَ-نَا (Rabbana)"),
                    WordItem("ظَلَمْنَا أَنْفُسَنَا", "ہم نے اپنی جانوں پر ظلم کیا", "ظَ-لَم-نَا اَن-فُ-سَ-نَا (Zalamna Anfusana)"),
                    WordItem("وَإِنْ لَّمْ تَغْفِرْ لَنَا", "اور اگر تو نے ہمیں نہ بخشا", "وَ-اِن لَم تَغ-فِر لَ-نَا (Wa In Lam Taghfir Lana)"),
                    WordItem("وَتَرْحَمْنَا", "اور ہم پر رحم نہ کیا", "وَ-تَر-حَم-نَا (Wa Tarhamna)"),
                    WordItem("لَنَكُوْنَنَّ مِنَ الْخَاسِرِيْنَ", "تو ہم ضرور نقصان اٹھانے والوں میں سے ہو جائیں گے", "لَ-نَ-کُو-نَن-نَ مِ-نَل خَا-سِ-رِی-نَ (Lanakunanna Minal Khasireen)")
                ),
                fullUr = "اے ہمارے رب! ہم نے اپنی جانوں پر ظلم کیا اور اگر تو نے ہمیں نہ بخشا اور ہم پر رحم نہ فرمایا تو ہم ضرور نقصان اٹھانے والوں میں سے ہو جائیں گے۔"
            ),
            LessonLine(
                label = "توبہ و استغفار کی دعا (۴)",
                words = listOf(
                    WordItem("رَبِّ اغْفِرْ لِيْ", "اے میرے رب مجھے بخش دے", "رَب-بِغ-فِر لِی (Rabbighfir Li)"),
                    WordItem("وَتُبْ عَلَيَّ", "اور میری توبہ قبول فرما", "وَ-تُب عَ-لَی-یَ (Wa Tub Alayya)"),
                    WordItem("إِنَّكَ أَنْتَ", "بے شک تو ہی", "اِن-نَ-کَ اَن-تَ (Innaka Anta)"),
                    WordItem("التَّوَّابُ الرَّحِيْمُ", "توبہ قبول کرنے والا، رحم والا ہے", "اَت-تَو-وَا-بُر رَ-حِی-مُ (At-Tawwabur Raheem)")
                ),
                fullUr = "اے میرے رب! مجھے معاف فرما اور میری توبہ قبول فرما، بے شک تو ہی بہت توبہ قبول کرنے والا، نہایت رحم فرمانے والا ہے۔"
            )
        ),
        lughat = listOf(
            LughatItem("ارْحَمْهُمَا", "ان دونوں پر رحم فرما"),
            LughatItem("رَبَّيَانِيْ", "ان دونوں نے مجھے پالا"),
            LughatItem("صَغِيْرًا", "بچپن میں / چھوٹا"),
            LughatItem("وَلِوَالِدَيَّ", "اور میرے والدین کو"),
            LughatItem("الْحِسَابُ", "حساب (قیامت)"),
            LughatItem("ظَلَمْنَا", "ہم نے ظلم کیا"),
            LughatItem("الْخَاسِرِيْنَ", "نقصان اٹھانے والے"),
            LughatItem("تُبْ عَلَيَّ", "میری توبہ قبول فرما"),
            LughatItem("التَّوَّابُ", "توبہ قبول کرنے والا")
        )
    ),
    Lesson(
        id = 15,
        titleUr = "نماز کے بعد مسنون اذکار (ترتیب وار)",
        titleEn = "Masnoon Azkar After Salah (In Order)",
        romanKeys = "masnoon azkar after namaz salah astaghfirullah antas salam tasbeeh fatimi subhanallah alhamdulillah allahu akbar",
        lines = listOf(
            LessonLine(
                label = "ترتیب ۱: استغفار (۳ بار)",
                labelEn = "Step 1: Istighfar (3 times)",
                words = listOf(
                    WordItem("أَسْتَغْفِرُ", "میں بخشش مانگتا ہوں", "اَس-تَغ-فِ-رُ (Astaghfiru)", "I seek forgiveness"),
                    WordItem("اللّٰهَ", "اللہ سے", "اَل-لٰ-ہَ (Allaha)", "from Allah")
                ),
                fullUr = "میں اللہ سے بخشش مانگتا ہوں۔ (سلام پھیرتے ہی تین بار پڑھیں — صحیح مسلم: 591)",
                fullEn = "I seek forgiveness from Allah. (Recite 3 times right after Salam — Sahih Muslim: 591)"
            ),
            LessonLine(
                label = "ترتیب ۲: سلامتی کی دعا",
                labelEn = "Step 2: Dua of Peace",
                words = listOf(
                    WordItem("اَللّٰهُمَّ", "اے اللہ", "اَل-لٰ-ہُم-مَ (Allahumma)", "O Allah"),
                    WordItem("أَنْتَ", "تو ہی", "اَن-تَ (Anta)", "You are"),
                    WordItem("السَّلَامُ", "سلامتی والا ہے", "اَس-سَ-لَا-مُ (As-Salam)", "The Peace"),
                    WordItem("وَمِنْكَ السَّلَامُ", "اور تجھی سے سلامتی ہے", "وَ-مِن-کَس سَ-لَا-مُ (Wa Minkas-Salam)", "and from You is peace"),
                    WordItem("تَبَارَكْتَ", "تو بابرکت ہے", "تَ-بَا-رَک-تَ (Tabarakta)", "Blessed are You"),
                    WordItem("يَا ذَا الْجَلَالِ وَالْإِكْرَامِ", "اے جلال و بزرگی والے", "یَا ذَل-جَ-لَا-لِ وَل-اِک-رَا-مِ (Ya Zal-Jalali Wal-Ikram)", "O Possessor of Majesty & Honor")
                ),
                fullUr = "اے اللہ! تو ہی سلامتی والا ہے اور تجھی سے سلامتی ہے، تو بابرکت ہے اے جلال اور بزرگی والے! (صحیح مسلم: 591)",
                fullEn = "O Allah, You are Peace and from You comes peace; Blessed are You, O Possessor of Majesty and Honor. (Sahih Muslim: 591)"
            ),
            LessonLine(
                label = "ترتیب ۳: کلمۂ توحید",
                labelEn = "Step 3: Declaration of Tawheed",
                words = listOf(
                    WordItem("لَا إِلٰهَ إِلَّا اللّٰهُ", "اللہ کے سوا کوئی معبود نہیں", "لَا اِ-لٰ-ہَ اِل-لَل-لٰہُ (La Ilaha Illallahu)", "No deity except Allah"),
                    WordItem("وَحْدَهُ لَا شَرِيْكَ لَهُ", "وہ اکیلا ہے اس کا کوئی شریک نہیں", "وَح-دَہُ لَا شَ-رِی-کَ لَہُ (Wahdahu La Shareeka Lahu)", "Alone without partner"),
                    WordItem("لَهُ الْمُلْكُ", "اسی کی بادشاہی ہے", "لَ-ہُل مُل-کُ (Lahul Mulk)", "His is the dominion"),
                    WordItem("وَلَهُ الْحَمْدُ", "اور اسی کے لیے تعریف ہے", "وَ-لَ-ہُل حَم-دُ (Wa Lahul Hamd)", "And His is all praise"),
                    WordItem("وَهُوَ عَلٰى كُلِّ شَيْءٍ قَدِيْرٌ", "اور وہ ہر چیز پر قادر ہے", "وَ-ہُ-وَ عَ-لٰی کُل-لِ شَی-ئٍ قَ-دِی-رُ (Ala Kulli Shai'in Qadeer)", "Over all things Capable")
                ),
                fullUr = "اللہ کے سوا کوئی معبود نہیں، وہ اکیلا ہے اس کا کوئی شریک نہیں، اسی کی بادشاہی اور تعریف ہے، اور وہ ہر چیز پر قادر ہے۔ (صحیح مسلم: 593)",
                fullEn = "There is no deity except Allah alone, with no partner; His is dominion and praise, and He is Powerful over all things. (Sahih Muslim: 593)"
            ),
            LessonLine(
                label = "ترتیب ۴: ذکر و شکر کی دعا",
                labelEn = "Step 4: Dua for Zikr & Gratitude",
                words = listOf(
                    WordItem("رَبِّ", "اے میرے رب", "رَب-بِ (Rabbi)", "My Lord"),
                    WordItem("أَعِنِّيْ", "میری مدد فرما", "اَ-عِن-نِی (A'inni)", "help me"),
                    WordItem("عَلٰى ذِكْرِكَ", "اپنے ذکر پر", "عَ-لٰی ذِک-رِ-کَ (Ala Zikrika)", "to remember You"),
                    WordItem("وَشُكْرِكَ", "اور اپنے شکر پر", "وَ-شُک-رِ-کَ (Wa Shukrika)", "and to thank You"),
                    WordItem("وَحُسْنِ عِبَادَتِكَ", "اور اپنی بہترین عبادت پر", "وَ-حُس-نِ عِ-بَا-دَ-تِ-کَ (Wa Husni Ibadatika)", "and worship You well")
                ),
                fullUr = "اے میرے رب! اپنے ذکر پر، اپنے شکر پر اور اپنی بہترین عبادت پر میری مدد فرما۔ (ابو داود: 1522)",
                fullEn = "My Lord, help me to remember You, thank You, and worship You in the best manner. (Abu Dawud: 1522)"
            ),
            LessonLine(
                label = "ترتیب ۵: تسبیحِ فاطمی (۳۳+۳۳+۳۴)",
                labelEn = "Step 5: Tasbeeh-e-Fatimi (33+33+34)",
                words = listOf(
                    WordItem("سُبْحَانَ اللّٰهِ", "اللہ پاک ہے (۳۳ بار)", "سُب-حَا-نَل-لٰہِ (SubhanAllah)", "Glory be to Allah (33x)"),
                    WordItem("اَلْحَمْدُ لِلّٰهِ", "تمام تعریف اللہ کے لیے (۳۳ بار)", "اَل-حَم-دُ لِل-لٰہِ (Alhamdulillah)", "All praise is for Allah (33x)"),
                    WordItem("اَللّٰهُ أَكْبَرُ", "اللہ سب سے بڑا ہے (۳۴ بار)", "اَل-لٰ-ہُ اَک-بَرُ (Allahu Akbar)", "Allah is Greatest (34x)")
                ),
                fullUr = "نماز کے بعد ۳۳ مرتبہ سبحان اللہ، ۳۳ مرتبہ الحمد للہ اور ۳۴ مرتبہ اللہ اکبر پڑھنا مسنون ہے۔ (صحیح مسلم: 597)",
                fullEn = "After Salah, recite SubhanAllah 33 times, Alhamdulillah 33 times, and Allahu Akbar 34 times. (Sahih Muslim: 597)"
            )
        ),
        lughat = listOf(
            LughatItem("أَسْتَغْفِرُ اللّٰهَ", "میں اللہ سے بخشش مانگتا ہوں", "I seek forgiveness from Allah"),
            LughatItem("السَّلَامُ", "سلامتی والا", "Source of Peace"),
            LughatItem("تَبَارَكْتَ", "تو بابرکت ہے", "Blessed are You"),
            LughatItem("ذَا الْجَلَالِ", "جلال و عظمت والا", "Possessor of Majesty"),
            LughatItem("وَحْدَهُ", "وہ اکیلا ہے", "He is Alone"),
            LughatItem("لَا شَرِيْكَ لَهُ", "اس کا کوئی شریک نہیں", "No partner with Him"),
            LughatItem("الْمُلْكُ", "بادشاہی", "Sovereignty / Dominion"),
            LughatItem("قَدِيْرٌ", "قدرت رکھنے والا", "All-Powerful"),
            LughatItem("أَعِنِّيْ", "میری مدد فرما", "Help me"),
            LughatItem("حُسْنِ عِبَادَتِكَ", "تیری بہترین عبادت", "Excellence in Your worship")
        )
    ),
    Lesson(
        id = 16,
        titleUr = "صبح و شام کے مسنون اذکار",
        titleEn = "Morning & Evening Masnoon Azkar",
        romanKeys = "subah shaam morning evening azkar asbahna amsaina subhanallahi wa bihamdihi la yadurru",
        lines = listOf(
            LessonLine(
                label = "صبح کا ذکر (۱)",
                labelEn = "Morning Zikr (1)",
                words = listOf(
                    WordItem("أَصْبَحْنَا", "ہم نے صبح کی", "اَص-بَح-نَا (Asbahna)", "We reached morning"),
                    WordItem("وَأَصْبَحَ الْمُلْكُ", "اور صبح کی بادشاہی نے", "وَ-اَص-بَ-حَل مُل-کُ (Wa Asbahal Mulk)", "and the dominion"),
                    WordItem("لِلّٰهِ", "اللہ کے لیے", "لِل-لٰ-ہِ (Lillahi)", "belongs to Allah"),
                    WordItem("وَالْحَمْدُ لِلّٰهِ", "اور تمام تعریف اللہ کے لیے ہے", "وَل-حَم-دُ لِل-لٰہِ (Wal-Hamdu Lillah)", "all praise to Allah")
                ),
                fullUr = "ہم نے اور تمام کائنات نے اللہ کے لیے صبح کی، اور تمام تعریفیں اللہ ہی کے لیے ہیں۔ (صحیح مسلم: 2723)",
                fullEn = "We have entered a new morning and the entire dominion belongs to Allah; all praise is for Allah. (Sahih Muslim: 2723)"
            ),
            LessonLine(
                label = "صبح و شام کی دعا (۲)",
                labelEn = "Morning & Evening Dua (2)",
                words = listOf(
                    WordItem("اَللّٰهُمَّ", "اے اللہ", "اَل-لٰ-ہُم-مَ (Allahumma)", "O Allah"),
                    WordItem("بِكَ أَصْبَحْنَا", "تیرے حکم سے ہم نے صبح کی", "بِ-کَ اَص-بَح-نَا (Bika Asbahna)", "by You we enter morning"),
                    WordItem("وَبِكَ أَمْسَيْنَا", "اور تیرے حکم سے شام کی", "وَ-بِ-کَ اَم-سَی-نَا (Wa Bika Amsaina)", "and by You evening"),
                    WordItem("وَبِكَ نَحْيَا", "اور تیرے حکم سے زندہ ہیں", "وَ-بِ-کَ نَح-یَا (Wa Bika Nahya)", "by You we live"),
                    WordItem("وَبِكَ نَمُوْتُ", "اور تیرے حکم سے مرتے ہیں", "وَ-بِ-کَ نَ-مُو-تُ (Wa Bika Namoot)", "by You we die"),
                    WordItem("وَإِلَيْكَ النُّشُوْرُ", "اور تیری طرف لوٹنا ہے", "وَ-اِ-لَی-کَن نُ-شُو-رُ (Wa Ilaikan-Nushoor)", "to You is resurrection")
                ),
                fullUr = "اے اللہ! تیرے ہی حکم سے ہم نے صبح کی، تیرے ہی حکم سے شام کی، تیرے ہی حکم سے زندہ رہتے اور مرتے ہیں اور تیری ہی طرف لوٹ کر جانا ہے۔ (ترمذی: 3391)",
                fullEn = "O Allah, by You we reach morning and evening, by You we live and die, and to You is the final return. (Tirmidhi: 3391)"
            ),
            LessonLine(
                label = "تسبیح و تحمید (۳ — ۱۰۰ بار)",
                labelEn = "Tasbeeh & Praise (3 — 100x)",
                words = listOf(
                    WordItem("سُبْحَانَ", "پاک ہے", "سُب-حَا-نَ (Subhana)", "Glory be to"),
                    WordItem("اللّٰهِ", "اللہ", "اَل-لٰ-ہِ (Allahi)", "Allah"),
                    WordItem("وَبِحَمْدِهِ", "اور اپنی تعریف کے ساتھ", "وَ-بِ-حَم-دِ-ہِ (Wa Bihamdihi)", "and with His praise")
                ),
                fullUr = "اللہ پاک ہے اور تمام تعریفیں اسی کے لیے ہیں۔ (صبح و شام سو مرتبہ — صحیح مسلم: 2692)",
                fullEn = "Glory be to Allah and praise be to Him. (100 times morning & evening — Sahih Muslim: 2692)"
            ),
            LessonLine(
                label = "ہر نقصان سے حفاظت کی دعا (۴)",
                labelEn = "Dua for Protection (4 — 3x)",
                words = listOf(
                    WordItem("بِسْمِ اللّٰهِ", "اللہ کے نام سے", "بِس-مِل-لٰہِ (Bismillahi)", "In Allah's name"),
                    WordItem("الَّذِيْ لَا يَضُرُّ", "جس کے نام کے ساتھ نقصان نہیں دیتی", "اَل-لَ-ذِی لَا یَ-ضُر-رُ (Allazi La Yadurru)", "with whose name harms not"),
                    WordItem("مَعَ اسْمِهِ شَيْءٌ", "کوئی بھی چیز", "مَ-عَس-مِ-ہِ شَی-ءُ (Ma'asmihi Shai'un)", "anything at all"),
                    WordItem("فِي الْأَرْضِ وَلَا فِي السَّمَاءِ", "زمین میں اور نہ آسمان میں", "فِل اَر-ضِ وَ-لَا فِس سَ-مَاءِ (Fil Ardi Wa La Fis-Sama)", "on earth or in heaven"),
                    WordItem("وَهُوَ السَّمِيْعُ الْعَلِيْمُ", "اور وہ سننے والا جاننے والا ہے", "وَ-ہُ-وَس سَ-مِی-عُل عَ-لِی-مُ (Was-Samee'ul Aleem)", "All-Hearing, All-Knowing")
                ),
                fullUr = "اس اللہ کے نام سے جس کے نام کی برکت سے زمین و آسمان کی کوئی چیز نقصان نہیں پہنچا سکتی، اور وہ خوب سننے والا، سب کچھ جاننے والا ہے۔ (ابو داود: 5088)",
                fullEn = "In the name of Allah, with whose name nothing in earth or heaven can harm; He is the All-Hearing, All-Knowing. (Abu Dawud: 5088)"
            )
        ),
        lughat = listOf(
            LughatItem("أَصْبَحْنَا", "ہم نے صبح کی", "We entered morning"),
            LughatItem("أَمْسَيْنَا", "ہم نے شام کی", "We entered evening"),
            LughatItem("نَحْيَا", "ہم زندہ رہتے ہیں", "We live"),
            LughatItem("نَمُوْتُ", "ہم مرتے ہیں", "We die"),
            LughatItem("النُّشُوْرُ", "اٹھ کر لوٹنا", "Resurrection / Return"),
            LughatItem("وَبِحَمْدِهِ", "اور اس کی تعریف کے ساتھ", "And with His praise"),
            LughatItem("لَا يَضُرُّ", "نقصان نہیں پہنچاتا", "Cannot cause harm"),
            LughatItem("السَّمَاءِ", "آسمان", "Sky / Heaven"),
            LughatItem("السَّمِيْعُ", "خوب سننے والا", "The All-Hearing"),
            LughatItem("الْعَلِيْمُ", "سب جاننے والا", "The All-Knowing")
        )
    ),
    Lesson(
        id = 17,
        titleUr = "نمازِ جنازہ کی مسنون دعائیں",
        titleEn = "Namaz-e-Janaza Masnoon Duas",
        romanKeys = "namaz janaza funeral prayer dua allahummaghfir li hayyina wa mayyitina warhamhu wa afihi zimmatika faratan ajran zukhran shafian",
        lines = listOf(
            LessonLine(
                label = "دعا ۱ (بالغ میت): زندوں اور مردوں کی مغفرت (حصہ ۱)",
                labelEn = "Dua 1 (Adult): Forgiveness for Living & Dead (Part 1)",
                words = listOf(
                    WordItem("اَللّٰهُمَّ اغْفِرْ", "اے اللہ بخش دے", "اَل-لٰہُم-مَغ-فِر (Allahummaghfir)", "O Allah forgive"),
                    WordItem("لِحَيِّنَا وَمَيِّتِنَا", "ہمارے زندوں اور مردوں کو", "لِ-حَی-یِ-نَا وَ-مَی-یِ-تِ-نَا (Li-Hayyina Wa Mayyitina)", "our living and our dead"),
                    WordItem("وَشَاهِدِنَا وَغَائِبِنَا", "ہمارے حاضر اور غائب کو", "وَ-شَا-ہِ-دِ-نَا وَ-غَا-ئِ-بِ-نَا (Wa Shahidina Wa Gha'ibina)", "those present and absent"),
                    WordItem("وَصَغِيْرِنَا وَكَبِيْرِنَا", "ہمارے چھوٹوں اور بڑوں کو", "وَ-صَ-غِی-رِ-نَا وَ-کَ-بِی-رِ-نَا (Wa Sagheerina Wa Kabeerina)", "our young and our old"),
                    WordItem("وَذَكَرِنَا وَأُنْثَانَا", "ہمارے مردوں اور عورتوں کو", "وَ-ذَ-کَ-رِ-نَا وَ-اُن-ثَا-نَا (Wa Zakarina Wa Unsana)", "our males and our females")
                ),
                fullUr = "اے اللہ! ہمارے زندوں اور ہمارے فوت شدگان، ہمارے حاضر اور غائب، ہمارے چھوٹوں اور بڑوں، اور ہمارے مردوں اور عورتوں سب کی مغفرت فرما۔ (سنن ترمذی: 1024 / ابو داود: 3201)",
                fullEn = "O Allah, forgive our living and our dead, those present and absent, our young and old, and our males and females. (Tirmidhi: 1024 / Abu Dawud: 3201)"
            ),
            LessonLine(
                label = "دعا ۱ (بالغ میت): اسلام و ایمان پر خاتمہ (حصہ ۲)",
                labelEn = "Dua 1 (Adult): Living on Islam & Dying on Iman (Part 2)",
                words = listOf(
                    WordItem("اَللّٰهُمَّ مَنْ أَحْيَيْتَهُ مِنَّا", "اے اللہ جسے تو ہم میں سے زندہ رکھے", "اَل-لٰہُم-مَ مَن اَح-یَی-تَہُ مِن-نَا (Man Ahyaitahu Minna)", "Whomever You keep alive among us"),
                    WordItem("فَأَحْيِهِ عَلَى الْإِسْلَامِ", "تو اسے اسلام پر زندہ رکھ", "فَ-اَح-یِ-ہِ عَ-لَل اِس-لَا-مِ (Fa-Ahyihi Alal Islam)", "keep them alive upon Islam"),
                    WordItem("وَمَنْ تَوَفَّيْتَهُ مِنَّا", "اور جسے تو ہم میں سے وفات دے", "وَ-مَن تَ-وَف-فَی-تَہُ مِن-نَا (Wa Man Tawaffaitahu Minna)", "and whomever You take in death"),
                    WordItem("فَتَوَفَّهُ عَلَى الْإِيْمَانِ", "تو اسے ایمان پر وفات دے", "فَ-تَ-وَف-فَہُ عَ-لَل اِی-مَا-نِ (Fatawaffahu Alal Iman)", "cause them to die upon Iman")
                ),
                fullUr = "اے اللہ! ہم میں سے جسے تو زندہ رکھے اسے اسلام پر زندہ رکھ، اور ہم میں سے جسے تو وفات دے اسے ایمان پر وفات عطا فرما۔",
                fullEn = "O Allah, whomever among us You keep alive, keep them alive upon Islam, and whomever among us You cause to die, let them die upon faith."
            ),
            LessonLine(
                label = "دعا ۲ (بالغ میت): مغفرت و عافیت اور اکرامِ قبر (حصہ ۱)",
                labelEn = "Dua 2 (Adult): Pardon, Mercy & Honor in Grave (Part 1)",
                words = listOf(
                    WordItem("اَللّٰهُمَّ اغْفِرْ لَهُ وَارْحَمْهُ", "اے اللہ اسے بخش دے اور رحم فرما", "اَل-لٰہُم-مَغ-فِر لَہُ وَر-حَم-ہُ (Allahummaghfir Lahu Warhamhu)", "O Allah forgive him & have mercy"),
                    WordItem("وَعَافِهِ وَاعْفُ عَنْهُ", "اسے عافیت دے اور درگزر فرما", "وَ-عَا-فِ-ہِ وَع-فُ عَن-ہُ (Wa Afihi Wa'fu Anhu)", "grant him peace & pardon him"),
                    WordItem("وَأَكْرِمْ نُزُلَهُ", "اور اس کی مہمانی عزت والی کر", "وَ-اَک-رِم نُ-زُ-لَ-ہُ (Wa Akrim Nuzulahu)", "honor his reception"),
                    WordItem("وَوَسِّعْ مُدْخَلَهُ", "اور اس کی قبر کشادہ فرما", "وَ-وَس-سِع مُد-خَ-لَ-ہُ (Wa Wassi Mudkhalahu)", "and widen his entrance")
                ),
                fullUr = "اے اللہ! اسے بخش دے اور اس پر رحم فرما، اسے عافیت عطا فرما اور اس سے درگزر فرما، اس کی مہمانی باعزت کر اور اس کی قبر کو کشادہ فرما۔ (صحیح مسلم: 963)",
                fullEn = "O Allah, forgive him and have mercy upon him, give him peace and pardon him, honor his reception and widen his grave. (Sahih Muslim: 963)"
            ),
            LessonLine(
                label = "دعا ۲ (بالغ میت): گناہوں سے پاکیزگی (حصہ ۲)",
                labelEn = "Dua 2 (Adult): Cleansing from Sins (Part 2)",
                words = listOf(
                    WordItem("وَاغْسِلْهُ بِالْمَاءِ وَالثَّلْجِ وَالْبَرَدِ", "اسے پانی، برف اور اولوں سے دھو دے", "وَاغ-سِل-ہُ بِال-مَاءِ وَث-ثَل-جِ وَل-بَ-رَدِ (Bisma'i Was-Salji Wal-Barad)", "Wash him with water, snow & ice"),
                    WordItem("وَنَقِّهِ مِنَ الْخَطَايَا", "اور اسے خطاؤں سے پاک کر دے", "وَ-نَق-قِ-ہِ مِ-نَل خَ-طَا-یَا (Wa Naqqihi Minal Khataya)", "cleanse him from sins"),
                    WordItem("كَمَا نَقَّيْتَ الثَّوْبَ الْأَبْيَضَ", "جیسا تو نے سفید کپڑے کو صاف کیا", "کَ-مَا نَق-قَی-تَث ثَو-بَل اَب-یَ-ضَ (As-Saubal Abyad)", "as You cleansed white garment"),
                    WordItem("مِنَ الدَّنَسِ", "میل کچیل سے", "مِ-نَد دَ-نَ-سِ (Minad-Danas)", "from stain / impurity")
                ),
                fullUr = "اور اسے پانی، برف اور اولوں کے ساتھ دھو دے، اور اسے گناہوں سے اس طرح پاک کر دے جس طرح سفید کپڑا میل کچیل سے پاک کیا جاتا ہے۔",
                fullEn = "And wash him with water, snow, and hail, and cleanse him from sins just as a white garment is cleansed from dirt."
            ),
            LessonLine(
                label = "دعا ۲ (بالغ میت): جنت کا عطیہ و عذاب سے پناہ (حصہ ۳)",
                labelEn = "Dua 2 (Adult): Paradise & Refuge from Torment (Part 3)",
                words = listOf(
                    WordItem("وَأَبْدِلْهُ دَارًا خَيْرًا مِّنْ دَارِهِ", "اسے اس کے گھر سے بہتر گھر عطا فرما", "دَا-رَن خَی-رَن مِن دَا-رِ-ہِ (Daran Khairan Min Darihi)", "Grant a home better than his"),
                    WordItem("وَأَهْلًا خَيْرًا مِّنْ أَهْلِهِ وَزَوْجًا خَيْرًا مِّنْ زَوْجِهِ", "اور بہتر گھر والے اور بہتر ساتھی عطا فرما", "اَہ-لَن خَی-رَن مِن اَہ-لِ-ہِ (Ahlan & Zaujan Khairan)", "and better family & spouse"),
                    WordItem("وَأَدْخِلْهُ الْجَنَّةَ", "اور اسے جنت میں داخل فرما", "وَ-اَد-خِل-ہُل جَن-نَ-ةَ (Ad-khilhul Jannah)", "Admit him to Paradise"),
                    WordItem("وَأَعِذْهُ مِنْ عَذَابِ الْقَبْرِ وَمِنْ عَذَابِ النَّارِ", "اور اسے قبر اور آگ کے عذاب سے پناہ دے", "عَ-ذَا-بِل قَب-رِ وَ-مِن عَ-ذَا-بِن نَارِ (Min Azabil Qabr Wan-Nar)", "Protect from grave & Fire")
                ),
                fullUr = "اور اسے اس کے گھر سے بہتر گھر، اس کے گھر والوں سے بہتر گھر والے اور بہتر ساتھی عطا فرما، اسے جنت میں داخل فرما اور قبر و جہنم کے عذاب سے پناہ دے۔ (عورت کے لیے لَهَا/ارْحَمْهَا پڑھیں)",
                fullEn = "Grant him a home better than his home, a family better than his family, admit him to Paradise and protect him from the punishment of the grave and Fire. (Use feminine pronouns for a female)"
            ),
            LessonLine(
                label = "دعا ۳ (بالغ میت): اللہ کی امان اور قبر سے حفاظت کی دعا",
                labelEn = "Dua 3 (Adult): Dua in Allah's Protection",
                words = listOf(
                    WordItem("اَللّٰهُمَّ إِنَّ فُلَانًا فِيْ ذِمَّتِكَ وَحَبْلِ جِوَارِكَ", "اے اللہ فلاں تیری پناہ و امان میں ہے", "فِی ذِمَّتِکَ وَحَب-لِ جِوَارِکَ (Fi Zimmatika Wa Habli Jiwarik)", "Under Your protection & covenant"),
                    WordItem("فَقِهِ مِنْ فِتْنَةِ الْقَبْرِ وَعَذَابِ النَّارِ", "اسے قبر کے فتنے و آگ کے عذاب سے بچا", "فَقِہِ مِن فِت-نَتِل قَب-رِ وَعَذَابِن نَارِ (Min Fitnatil Qabr Wan-Nar)", "Protect from grave trial & Fire"),
                    WordItem("وَأَنْتَ أَهْلُ الْوَفَاءِ وَالْحَقِّ", "اور تو ہی وفا اور حق والا ہے", "اَہ-لُل وَ-فَا-ءِ وَل-حَق-قِ (Ahlul Wafa'i Wal-Haqq)", "You are Faithful and True"),
                    WordItem("فَاغْفِرْ لَهُ وَارْحَمْهُ إِنَّكَ أَنْتَ الْغَفُوْرُ الرَّحِيْمُ", "پس اسے بخش کر رحم فرما تو بخشنے والا مہربان ہے", "فَغ-فِر لَہُ وَر-حَم-ہُ (Faghfir Lahu Warhamhu)", "Forgive him; You are Most Merciful")
                ),
                fullUr = "اے اللہ! بے شک فلاں بن فلاں تیری پناہ اور امان میں ہے، پس تو اسے قبر کے فتنے اور آگ کے عذاب سے بچا، تو ہی وفا اور حق والا ہے، پس اسے بخش دے اور اس پر رحم فرما۔ (سنن ابو داود: 3202)",
                fullEn = "O Allah, indeed [name] is under Your protection and covenant; protect him from the trial of the grave and torment of the Fire, and forgive and have mercy on him. (Abu Dawud: 3202)"
            ),
            LessonLine(
                label = "دعا ۴: نابالغ بچے کے لیے مسنون دعا",
                labelEn = "Dua 4: Masnoon Dua for Deceased Young Child",
                words = listOf(
                    WordItem("اَللّٰهُمَّ اجْعَلْهُ لَنَا", "اے اللہ اسے ہمارے لیے بنا دے", "اَل-لٰہُم-مَج-عَل-ہُ لَ-نَا (Allahummaj'alhu Lana)", "O Allah make him for us"),
                    WordItem("فَرَطًا", "آگے پہنچ کر انتظام کرنے والا", "فَ-رَ-طَن (Faratan)", "a forerunner / pioneer"),
                    WordItem("وَّاجْعَلْهُ لَنَا سَلَفًا وَّأَجْرًا وَّذُخْرًا", "اور اسے ہمارے لیے پیش رو، اجر اور ذخیرہ بنا", "سَ-لَ-فَن وَّ-اَج-رَن وَذُخ-رَا (Salafan Wa Ajran Wa Zukhran)", "an advance reward & treasure"),
                    WordItem("وَّاجْعَلْهُ لَنَا شَافِعًا وَّمُشَفَّعًا", "اور اسے ہمارا مقبول سفارشی بنا", "شَا-فِ-عَن وَمُ-شَف-فَ-عَا (Shafi'an Wa Mushaffa'a)", "an accepted intercessor")
                ),
                fullUr = "اے اللہ! اس بچے کو ہمارے لیے آگے جا کر سامانِ راحت تیار کرنے والا، پیش رو، اجر و ذخیرۂ آخرت، اور ایسا سفارشی بنا جس کی سفارش قبول ہو۔ (نابالغ بچی کے لیے اجْعَلْهَا اور شَافِعَةً وَّمُشَفَّعَةً پڑھیں — صحیح بخاری / سنن البیہقی)",
                fullEn = "O Allah, make him a forerunner for us, an advance reward and stored treasure, and an intercessor whose intercession is accepted. (For a girl say Aj'alha & Shafi'atan wa Mushaffa'ah)"
            )
        ),
        lughat = listOf(
            LughatItem("لِحَيِّنَا وَمَيِّتِنَا", "ہمارے زندوں و فوت شدگان کو", "For our living & dead"),
            LughatItem("عَافِهِ وَاعْفُ عَنْهُ", "اسے عافیت دے اور درگزر فرما", "Grant peace & pardon him"),
            LughatItem("نُزُلَهُ", "اس کی مہمانی", "His reception / hospitality"),
            LughatItem("مُدْخَلَهُ", "اس کے داخل ہونے کی جگہ (قبر)", "His grave / entrance"),
            LughatItem("الدَّنَسِ", "میل کچیل", "Stain / dirt"),
            LughatItem("ذِمَّتِكَ", "تیری پناہ و امان", "Your protection & covenant"),
            LughatItem("عَذَابِ الْقَبْرِ", "قبر کا عذاب", "Punishment of the grave"),
            LughatItem("فَرَطًا", "پیش رو / آگے جا کر سامان کرنے والا", "Forerunner / Pioneer"),
            LughatItem("ذُخْرًا", "آخرت کا ذخیرہ", "Stored treasure"),
            LughatItem("شَافِعًا وَّمُشَفَّعًا", "سفارش کرنے والا جس کی سفارش قبول ہو", "Accepted intercessor")
        )
    )
)

