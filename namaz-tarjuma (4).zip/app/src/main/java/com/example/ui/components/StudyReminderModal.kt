package com.example.ui.components

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.AppLanguage
import com.example.ui.UiStrings
import com.example.ui.theme.LocalNamazColors
import com.example.ui.theme.RomanFontFamily
import com.example.ui.theme.UrduFontFamily
import com.example.util.StudyReminderHelper

private data class ReminderPreset(
    val hour: Int,
    val minute: Int,
    val labelUr: String,
    val labelEn: String
)

private val StudyPresets = listOf(
    ReminderPreset(6, 0, "فجر / صبح 6:00", "Fajr 6:00 AM"),
    ReminderPreset(16, 30, "عصر / شام 4:30", "Asr 4:30 PM"),
    ReminderPreset(18, 30, "مغرب / شام 6:30", "Maghrib 6:30 PM"),
    ReminderPreset(20, 30, "عشاء / رات 8:30", "Isha 8:30 PM")
)

private enum class PendingPermissionAction {
    NONE,
    SAVE_REMINDER,
    TEST_NOTIFICATION
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StudyReminderModal(
    isVisible: Boolean,
    language: AppLanguage,
    strings: UiStrings,
    currentEnabled: Boolean,
    currentHour: Int,
    currentMinute: Int,
    onSaveReminder: (enabled: Boolean, hour: Int, minute: Int) -> Unit,
    onSendTestReminder: () -> Unit,
    onDismiss: () -> Unit
) {
    if (!isVisible) return

    val context = LocalContext.current
    val extended = LocalNamazColors.current
    val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily
    val layoutDirection = if (language == AppLanguage.ENGLISH) LayoutDirection.Ltr else LayoutDirection.Rtl

    var selectedHour by remember(isVisible, currentHour) { mutableIntStateOf(currentHour.coerceIn(0, 23)) }
    var selectedMinute by remember(isVisible, currentMinute) { mutableIntStateOf(currentMinute.coerceIn(0, 59)) }
    var hasPermission by remember(isVisible) {
        mutableStateOf(StudyReminderHelper.hasNotificationPermission(context))
    }
    var pendingAction by remember { mutableStateOf(PendingPermissionAction.NONE) }

    LaunchedEffect(isVisible) {
        if (isVisible) {
            hasPermission = StudyReminderHelper.hasNotificationPermission(context)
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasPermission = granted || StudyReminderHelper.hasNotificationPermission(context)
        if (hasPermission) {
            when (pendingAction) {
                PendingPermissionAction.SAVE_REMINDER -> {
                    onSaveReminder(true, selectedHour, selectedMinute)
                    onDismiss()
                }
                PendingPermissionAction.TEST_NOTIFICATION -> {
                    onSendTestReminder()
                }
                PendingPermissionAction.NONE -> Unit
            }
        }
        pendingAction = PendingPermissionAction.NONE
    }

    val requestPermissionFor: (PendingPermissionAction) -> Unit = { action ->
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pendingAction = action
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            hasPermission = true
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .safeDrawingPadding()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = extended.cardSurface,
                    border = BorderStroke(2.dp, extended.gold),
                    tonalElevation = 6.dp,
                    shadowElevation = 12.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 560.dp)
                        .testTag("study_reminder_dialog")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                    ) {
                        // Header
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(extended.greenHeader, extended.greenHeaderDark)
                                    )
                                )
                                .padding(horizontal = 14.dp, vertical = 12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = extended.gold,
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Filled.NotificationsActive,
                                            contentDescription = null,
                                            tint = Color(0xFF1A1A1A),
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = strings.reminderModalTitle,
                                        color = Color(0xFFFBE498),
                                        fontFamily = uiFont,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    )
                                    Text(
                                        text = strings.reminderModalSubtitle,
                                        color = Color.White.copy(alpha = 0.9f),
                                        fontFamily = uiFont,
                                        fontSize = 12.sp
                                    )
                                }
                                IconButton(
                                    onClick = onDismiss,
                                    modifier = Modifier
                                        .size(48.dp)
                                        .testTag("reminder_modal_close_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Close,
                                        contentDescription = strings.reminderCloseDesc,
                                        tint = Color.White
                                    )
                                }
                            }
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            if (!hasPermission) {
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = extended.goldLight,
                                    border = BorderStroke(1.dp, extended.gold),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = strings.reminderPermissionNeeded,
                                            fontFamily = uiFont,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = extended.goldText
                                        )
                                        Button(
                                            onClick = { requestPermissionFor(PendingPermissionAction.NONE) },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = extended.gold,
                                                contentColor = Color(0xFF1A1A1A)
                                            ),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier
                                                .heightIn(min = 48.dp)
                                                .testTag("reminder_grant_permission_btn")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.Notifications,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = strings.reminderGrantPermissionBtn,
                                                fontFamily = uiFont,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }

                            // Selected Time Preview + Steppers
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = extended.greenSurface,
                                border = BorderStroke(1.dp, extended.cardBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text(
                                        text = strings.reminderCustomTimeLabel,
                                        fontFamily = uiFont,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = extended.arabicAccent
                                    )
                                    Text(
                                        text = StudyReminderHelper.formatTimeDisplay(selectedHour, selectedMinute, language),
                                        fontFamily = uiFont,
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = extended.arabicAccent,
                                        modifier = Modifier.testTag("reminder_selected_time_text")
                                    )

                                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            TimeStepperBlock(
                                                label = if (language == AppLanguage.ENGLISH) "Hour" else "گھنٹہ",
                                                valueText = selectedHour.toString().padStart(2, '0'),
                                                uiFont = uiFont,
                                                onDecrement = { selectedHour = (selectedHour + 23) % 24 },
                                                onIncrement = { selectedHour = (selectedHour + 1) % 24 }
                                            )
                                            Text(
                                                text = ":",
                                                fontFamily = RomanFontFamily,
                                                fontSize = 24.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = extended.arabicAccent
                                            )
                                            TimeStepperBlock(
                                                label = if (language == AppLanguage.ENGLISH) "Min" else "منٹ",
                                                valueText = selectedMinute.toString().padStart(2, '0'),
                                                uiFont = uiFont,
                                                onDecrement = { selectedMinute = (selectedMinute + 55) % 60 },
                                                onIncrement = { selectedMinute = (selectedMinute + 5) % 60 }
                                            )
                                        }
                                    }
                                }
                            }

                            // Presets
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = strings.reminderPresetsLabel,
                                    fontFamily = uiFont,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = extended.arabicAccent
                                )
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    StudyPresets.forEach { preset ->
                                        val isSelected = selectedHour == preset.hour && selectedMinute == preset.minute
                                        FilterChip(
                                            selected = isSelected,
                                            onClick = {
                                                selectedHour = preset.hour
                                                selectedMinute = preset.minute
                                            },
                                            label = {
                                                Text(
                                                    text = if (language == AppLanguage.ENGLISH) preset.labelEn else preset.labelUr,
                                                    fontFamily = uiFont,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = extended.goldLight,
                                                selectedLabelColor = extended.goldText
                                            ),
                                            modifier = Modifier.heightIn(min = 48.dp)
                                        )
                                    }
                                }
                            }

                            OutlinedButton(
                                onClick = {
                                    if (StudyReminderHelper.hasNotificationPermission(context)) {
                                        onSendTestReminder()
                                    } else {
                                        requestPermissionFor(PendingPermissionAction.TEST_NOTIFICATION)
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, extended.cardBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 48.dp)
                                    .testTag("send_test_reminder_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Notifications,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = strings.reminderTestBtn,
                                    fontFamily = uiFont,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                if (currentEnabled) {
                                    OutlinedButton(
                                        onClick = {
                                            onSaveReminder(false, selectedHour, selectedMinute)
                                            onDismiss()
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            contentColor = Color(0xFFDC2626)
                                        ),
                                        border = BorderStroke(1.dp, Color(0xFFDC2626).copy(alpha = 0.6f)),
                                        modifier = Modifier
                                            .weight(1f)
                                            .heightIn(min = 48.dp)
                                            .testTag("disable_reminder_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.NotificationsOff,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = strings.reminderDisableBtn,
                                            fontFamily = uiFont,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Button(
                                    onClick = {
                                        if (StudyReminderHelper.hasNotificationPermission(context)) {
                                            onSaveReminder(true, selectedHour, selectedMinute)
                                            onDismiss()
                                        } else {
                                            requestPermissionFor(PendingPermissionAction.SAVE_REMINDER)
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.primary
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .weight(1.3f)
                                        .heightIn(min = 48.dp)
                                        .testTag("save_reminder_button")
                                ) {
                                    Text(
                                        text = strings.reminderSaveBtn,
                                        fontFamily = uiFont,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TimeStepperBlock(
    label: String,
    valueText: String,
    uiFont: androidx.compose.ui.text.font.FontFamily,
    onDecrement: () -> Unit,
    onIncrement: () -> Unit
) {
    val extended = LocalNamazColors.current
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = label,
            fontFamily = uiFont,
            fontSize = 11.sp,
            color = extended.mutedText
        )
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            IconButton(
                onClick = onDecrement,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Remove,
                    contentDescription = "Decrease $label"
                )
            }
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = extended.cardSurface,
                border = BorderStroke(1.dp, extended.gold)
            ) {
                Text(
                    text = valueText,
                    fontFamily = RomanFontFamily,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = extended.arabicAccent,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
            IconButton(
                onClick = onIncrement,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Add,
                    contentDescription = "Increase $label"
                )
            }
        }
    }
}
