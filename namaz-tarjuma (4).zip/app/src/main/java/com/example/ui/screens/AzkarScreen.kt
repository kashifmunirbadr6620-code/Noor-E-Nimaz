package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AzkarData
import com.example.model.AppLanguage
import com.example.model.AzkarSection
import com.example.ui.AzkarFocusTarget
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.theme.LocalNamazColors
import com.example.ui.theme.LocalNamazFontSizes
import com.example.ui.theme.RomanFontFamily
import com.example.ui.theme.UrduFontFamily
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AzkarScreen(
    language: AppLanguage,
    activeSection: AzkarSection,
    tasbeehCount: Int,
    isSpeaking: Boolean,
    onSelectSection: (AzkarSection) -> Unit,
    onBackHome: () -> Unit,
    onSpeakText: (String) -> Unit,
    onStopAudio: () -> Unit,
    onIncrementTasbeeh: () -> Unit,
    onResetTasbeeh: () -> Unit,
    onOpenLesson: (Int) -> Unit,
    focusTarget: AzkarFocusTarget? = null,
    modifier: Modifier = Modifier
) {
    val extended = LocalNamazColors.current
    val fontSizes = LocalNamazFontSizes.current
    val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily
    val isEn = language == AppLanguage.ENGLISH

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    var asmaIndex by remember { mutableIntStateOf(0) }
    var hadithIndex by remember { mutableIntStateOf(0) }
    var salahZikrIndex by remember { mutableIntStateOf(0) }
    var mornEveIndex by remember { mutableIntStateOf(0) }
    var janazaIndex by remember { mutableIntStateOf(0) }

    fun sectionItemIndex(section: AzkarSection): Int = when (section) {
        AzkarSection.ASMA_UL_HUSNA -> 1
        AzkarSection.AHADEES -> 2
        AzkarSection.SALAH_AZKAR -> 3
        AzkarSection.MORNING_EVENING -> 4
        AzkarSection.JANAZA_DUAS -> 5
        AzkarSection.TASBEEH_COUNTER -> 6
    }

    LaunchedEffect(activeSection) {
        listState.animateScrollToItem(sectionItemIndex(activeSection))
    }

    LaunchedEffect(focusTarget?.requestId) {
        if (focusTarget != null) {
            when (focusTarget.section) {
                AzkarSection.ASMA_UL_HUSNA ->
                    asmaIndex = focusTarget.index.coerceIn(0, AzkarData.asmaUlHusnaList.lastIndex)
                AzkarSection.AHADEES ->
                    hadithIndex = focusTarget.index.coerceIn(0, AzkarData.childrenHadithList.lastIndex)
                AzkarSection.SALAH_AZKAR ->
                    salahZikrIndex = focusTarget.index.coerceIn(0, AzkarData.afterSalahAzkarList.lastIndex)
                AzkarSection.MORNING_EVENING ->
                    mornEveIndex = focusTarget.index.coerceIn(0, AzkarData.morningEveningAzkarList.lastIndex)
                AzkarSection.JANAZA_DUAS ->
                    janazaIndex = focusTarget.index.coerceIn(0, AzkarData.janazaDuasList.lastIndex)
                AzkarSection.TASBEEH_COUNTER -> Unit
            }
            listState.animateScrollToItem(sectionItemIndex(focusTarget.section))
        }
    }

    LazyColumn(
        state = listState,
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = modifier.fillMaxSize()
    ) {
        // 0. Header & Quick-Jump Section Chips
        item(key = "azkar_header") {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = extended.cardSurface),
                border = BorderStroke(1.5.dp, extended.gold),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        OutlinedButton(
                            onClick = onBackHome,
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("azkar_back_home_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isEn) "Home" else "ہوم",
                                fontFamily = uiFont,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }

                        if (isSpeaking) {
                            Button(
                                onClick = onStopAudio,
                                colors = ButtonDefaults.buttonColors(containerColor = extended.redMeaning),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier.heightIn(min = 48.dp)
                            ) {
                                Icon(Icons.Filled.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isEn) "Stop" else "آواز بند",
                                    fontFamily = uiFont,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    Text(
                        text = if (isEn) "🕌 Islamic Azkar, Hadith, Janaza & Tasbeeh"
                        else "🕌 اسلامی اسباق، مسنون اذکار، جنازہ و تسبیح",
                        fontFamily = uiFont,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = extended.arabicAccent
                    )
                    Text(
                        text = if (isEn) "Explore Allah's Names, Ahadees, ordered post-Salah Azkar, Morning/Evening duas, Namaz-e-Janaza, and live Tasbeeh-e-Fatimi counter."
                        else "اسماء الحسنیٰ، منتخب احادیث، نماز کے بعد اور صبح و شام کے مسنون اذکار (ترتیب وار)، نمازِ جنازہ کی دعائیں اور تسبیحِ فاطمی کاؤنٹر۔",
                        fontFamily = uiFont,
                        fontSize = 12.sp,
                        color = extended.mutedText
                    )

                    val navChips = listOf(
                        AzkarSection.ASMA_UL_HUSNA to (if (isEn) "1. Asma-ul-Husna" else "۱۔ اسماء الحسنیٰ"),
                        AzkarSection.AHADEES to (if (isEn) "2. Ahadees" else "۲۔ احادیث"),
                        AzkarSection.SALAH_AZKAR to (if (isEn) "3. After Salah" else "۳۔ بعد نماز اذکار"),
                        AzkarSection.MORNING_EVENING to (if (isEn) "4. Morning/Evening" else "۴۔ صبح و شام"),
                        AzkarSection.JANAZA_DUAS to (if (isEn) "5. Namaz-e-Janaza" else "۵۔ نمازِ جنازہ"),
                        AzkarSection.TASBEEH_COUNTER to (if (isEn) "6. Tasbeeh Counter" else "۶۔ تسبیح کاؤنٹر")
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        navChips.forEach { (sec, label) ->
                            val selected = sec == activeSection
                            Surface(
                                onClick = {
                                    onSelectSection(sec)
                                    coroutineScope.launch {
                                        listState.animateScrollToItem(sectionItemIndex(sec))
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                color = if (selected) MaterialTheme.colorScheme.primary else extended.greenSurface,
                                contentColor = if (selected) Color.White else extended.arabicAccent,
                                border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else extended.cardBorder),
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .testTag("azkar_chip_${sec.name.lowercase()}")
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                                ) {
                                    Text(
                                        text = label,
                                        fontFamily = uiFont,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 1. Asma-ul-Husna
        item(key = "section_asma") {
            val item = AzkarData.asmaUlHusnaList[asmaIndex]
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = extended.cardSurface),
                border = BorderStroke(1.dp, extended.cardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SectionHeadingBadge(
                        title = if (isEn) "1. Beautiful Names of Allah (Asma-ul-Husna)"
                        else "۱۔ اللہ تعالیٰ کے صفاتی نام (اسماء الحسنیٰ)",
                        counter = "${asmaIndex + 1} / ${AzkarData.asmaUlHusnaList.size}",
                        uiFont = uiFont
                    )

                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = extended.greenSurface,
                        border = BorderStroke(1.dp, extended.gold),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = item.arabic,
                                fontFamily = AmiriFontFamily,
                                fontSize = fontSizes.arabicWordSize * 1.25f,
                                fontWeight = FontWeight.Bold,
                                color = extended.arabicAccent,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = if (isEn) "${item.nameEn} — ${item.meaningEn}"
                                else "${item.nameUr} | مفہوم: ${item.meaningUr}",
                                fontFamily = uiFont,
                                fontSize = fontSizes.fullUrduSize,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    PagerControlsRow(
                        language = language,
                        onPrev = {
                            asmaIndex = (asmaIndex - 1 + AzkarData.asmaUlHusnaList.size) % AzkarData.asmaUlHusnaList.size
                        },
                        onListen = { onSpeakText(item.arabic) },
                        onNext = {
                            asmaIndex = (asmaIndex + 1) % AzkarData.asmaUlHusnaList.size
                        },
                        testTagPrefix = "asma"
                    )
                }
            }
        }

        // 2. Children Ahadees
        item(key = "section_hadith") {
            val hadith = AzkarData.childrenHadithList[hadithIndex]
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = extended.cardSurface),
                border = BorderStroke(1.dp, extended.cardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SectionHeadingBadge(
                        title = if (isEn) "2. Selected Ahadees for Students"
                        else "۲۔ طلبہ کے لیے منتخب مسنون احادیث",
                        counter = "${hadithIndex + 1} / ${AzkarData.childrenHadithList.size}",
                        uiFont = uiFont
                    )

                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = extended.greenSurface,
                        border = BorderStroke(1.dp, extended.cardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = hadith.arabic,
                                fontFamily = AmiriFontFamily,
                                fontSize = fontSizes.arabicWordSize,
                                fontWeight = FontWeight.Bold,
                                color = extended.arabicAccent,
                                textAlign = TextAlign.Center,
                                lineHeight = fontSizes.arabicWordSize * 1.45f
                            )
                            Text(
                                text = if (isEn) hadith.translationEn else hadith.translationUr,
                                fontFamily = uiFont,
                                fontSize = fontSizes.fullUrduSize,
                                fontWeight = FontWeight.Bold,
                                color = extended.blueText,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = if (isEn) hadith.refEn else hadith.refUr,
                                fontFamily = uiFont,
                                fontSize = 12.sp,
                                color = extended.mutedText,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    PagerControlsRow(
                        language = language,
                        onPrev = {
                            hadithIndex = (hadithIndex - 1 + AzkarData.childrenHadithList.size) % AzkarData.childrenHadithList.size
                        },
                        onListen = { onSpeakText(hadith.arabic) },
                        onNext = {
                            hadithIndex = (hadithIndex + 1) % AzkarData.childrenHadithList.size
                        },
                        testTagPrefix = "hadith"
                    )
                }
            }
        }

        // 3. Masnoon Azkar After Salah (Ordered)
        item(key = "section_salah_azkar") {
            val zikr = AzkarData.afterSalahAzkarList[salahZikrIndex]
            OrderedZikrSectionCard(
                language = language,
                heading = if (isEn) "3. Masnoon Azkar After Salah (In Order)"
                else "۳۔ نماز کے بعد کے مسنون اذکار (ترتیب وار)",
                item = zikr,
                totalCount = AzkarData.afterSalahAzkarList.size,
                onPrev = {
                    salahZikrIndex = (salahZikrIndex - 1 + AzkarData.afterSalahAzkarList.size) % AzkarData.afterSalahAzkarList.size
                },
                onListen = { onSpeakText(zikr.speakText) },
                onNext = {
                    salahZikrIndex = (salahZikrIndex + 1) % AzkarData.afterSalahAzkarList.size
                },
                lessonButtonLabel = if (isEn) "Open Full Lesson 15 (Word-by-Word)" else "سبق ۱۵ کھولیں (لفظ بہ لفظ ترجمہ)",
                onOpenLesson = { onOpenLesson(15) },
                testTagPrefix = "salah_zikr"
            )
        }

        // 4. Morning & Evening Masnoon Azkar
        item(key = "section_morning_evening") {
            val zikr = AzkarData.morningEveningAzkarList[mornEveIndex]
            OrderedZikrSectionCard(
                language = language,
                heading = if (isEn) "4. Morning & Evening Masnoon Azkar"
                else "۴۔ صبح و شام کے مسنون اذکار",
                item = zikr,
                totalCount = AzkarData.morningEveningAzkarList.size,
                onPrev = {
                    mornEveIndex = (mornEveIndex - 1 + AzkarData.morningEveningAzkarList.size) % AzkarData.morningEveningAzkarList.size
                },
                onListen = { onSpeakText(zikr.speakText) },
                onNext = {
                    mornEveIndex = (mornEveIndex + 1) % AzkarData.morningEveningAzkarList.size
                },
                lessonButtonLabel = if (isEn) "Open Full Lesson 16 (Word-by-Word)" else "سبق ۱۶ کھولیں (لفظ بہ لفظ ترجمہ)",
                onOpenLesson = { onOpenLesson(16) },
                testTagPrefix = "morn_eve"
            )
        }

        // 5. Namaz-e-Janaza Masnoon Duas
        item(key = "section_janaza") {
            val janaza = AzkarData.janazaDuasList[janazaIndex]
            OrderedZikrSectionCard(
                language = language,
                heading = if (isEn) "5. Namaz-e-Janaza Masnoon Duas"
                else "۵۔ نمازِ جنازہ کی مسنون دعائیں",
                item = janaza,
                totalCount = AzkarData.janazaDuasList.size,
                onPrev = {
                    janazaIndex = (janazaIndex - 1 + AzkarData.janazaDuasList.size) % AzkarData.janazaDuasList.size
                },
                onListen = { onSpeakText(janaza.speakText) },
                onNext = {
                    janazaIndex = (janazaIndex + 1) % AzkarData.janazaDuasList.size
                },
                lessonButtonLabel = if (isEn) "Open Full Lesson 17 (Word-by-Word)" else "سبق ۱۷ کھولیں (لفظ بہ لفظ ترجمہ)",
                onOpenLesson = { onOpenLesson(17) },
                testTagPrefix = "janaza_dua",
                showOrderPrefix = false
            )
        }

        // 6. Tasbeeh-e-Fatimi Counter
        item(key = "section_tasbeeh") {
            val phaseArabic: String
            val phaseTitle: String
            val phaseProgress: String
            val phaseSpeak: String

            when {
                tasbeehCount == 0 -> {
                    phaseArabic = "سُبْحَانَ اللّٰهِ"
                    phaseTitle = if (isEn) "SubhanAllah (33 times)" else "سُبْحَانَ اللّٰهِ (۳۳ بار)"
                    phaseProgress = "0 / 33"
                    phaseSpeak = "سبحان الله"
                }
                tasbeehCount <= 33 -> {
                    phaseArabic = "سُبْحَانَ اللّٰهِ"
                    phaseTitle = if (isEn) "Phase 1/3: SubhanAllah (33 times)" else "پہلا مرحلہ: سُبْحَانَ اللّٰهِ (۳۳ بار)"
                    phaseProgress = "$tasbeehCount / 33"
                    phaseSpeak = "سبحان الله"
                }
                tasbeehCount <= 66 -> {
                    phaseArabic = "اَلْحَمْدُ لِلّٰهِ"
                    phaseTitle = if (isEn) "Phase 2/3: Alhamdulillah (33 times)" else "دوسرا مرحلہ: اَلْحَمْدُ لِلّٰهِ (۳۳ بار)"
                    phaseProgress = "${tasbeehCount - 33} / 33"
                    phaseSpeak = "الحمد لله"
                }
                tasbeehCount < 100 -> {
                    phaseArabic = "اَللّٰهُ أَكْبَرُ"
                    phaseTitle = if (isEn) "Phase 3/3: Allahu Akbar (34 times)" else "تیسرا مرحلہ: اَللّٰهُ أَكْبَرُ (۳۴ بار)"
                    phaseProgress = "${tasbeehCount - 66} / 34"
                    phaseSpeak = "الله أكبر"
                }
                else -> {
                    phaseArabic = "تَسْبِيْحُ فَاطِمَةَ مُكَمَّلٌ ✓"
                    phaseTitle = if (isEn) "MashaAllah! All 100 Tasbeeh Complete!" else "ماشاء اللہ! تسبیحِ فاطمی (۱۰۰ بار) مکمل ہو گئی!"
                    phaseProgress = "34 / 34"
                    phaseSpeak = "سبحان الله والحمد لله والله أكبر"
                }
            }

            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = extended.cardSurface),
                border = BorderStroke(2.dp, extended.gold),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SectionHeadingBadge(
                        title = if (isEn) "6. Tasbeeh-e-Fatimi Counter (Post-Salah)"
                        else "۶۔ تسبیحِ فاطمی کاؤنٹر (نماز کے بعد)",
                        counter = "$tasbeehCount / 100",
                        uiFont = uiFont
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(extended.greenHeader, extended.greenHeaderDark)
                                )
                            )
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = phaseArabic,
                                fontFamily = AmiriFontFamily,
                                fontSize = 30.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFBE498),
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = phaseTitle,
                                fontFamily = uiFont,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "$tasbeehCount",
                                fontFamily = RomanFontFamily,
                                fontSize = 44.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White,
                                modifier = Modifier.testTag("tasbeeh_count_text")
                            )
                            Surface(
                                shape = RoundedCornerShape(999.dp),
                                color = Color.White.copy(alpha = 0.18f)
                            ) {
                                Text(
                                    text = if (isEn) "Current Step: $phaseProgress" else "موجودہ مرحلہ: $phaseProgress",
                                    color = Color(0xFFFBE498),
                                    fontFamily = uiFont,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    LinearProgressIndicator(
                        progress = { tasbeehCount / 100f },
                        color = extended.gold,
                        trackColor = extended.greenSurface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(999.dp))
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onIncrementTasbeeh,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1.6f)
                                .height(54.dp)
                                .testTag("tasbeeh_increment_button")
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isEn) "Count Tasbeeh (+1)" else "تسبیح گنیں (+1)",
                                fontFamily = uiFont,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        OutlinedButton(
                            onClick = { onSpeakText(phaseSpeak) },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .height(54.dp)
                                .testTag("tasbeeh_audio_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = "Listen", modifier = Modifier.size(20.dp))
                        }

                        OutlinedButton(
                            onClick = onResetTasbeeh,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = extended.redMeaning),
                            border = BorderStroke(1.dp, extended.redMeaning),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .height(54.dp)
                                .testTag("tasbeeh_reset_button")
                        ) {
                            Icon(Icons.Filled.RestartAlt, contentDescription = "Reset", modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionHeadingBadge(
    title: String,
    counter: String,
    uiFont: androidx.compose.ui.text.font.FontFamily
) {
    val extended = LocalNamazColors.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            fontFamily = uiFont,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = extended.arabicAccent,
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Surface(
            shape = RoundedCornerShape(999.dp),
            color = extended.goldLight,
            border = BorderStroke(1.dp, extended.gold)
        ) {
            Text(
                text = counter,
                fontFamily = RomanFontFamily,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = extended.goldText,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
            )
        }
    }
}

@Composable
private fun PagerControlsRow(
    language: AppLanguage,
    onPrev: () -> Unit,
    onListen: () -> Unit,
    onNext: () -> Unit,
    testTagPrefix: String
) {
    val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily
    val isEn = language == AppLanguage.ENGLISH
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OutlinedButton(
            onClick = onPrev,
            shape = RoundedCornerShape(10.dp),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
            modifier = Modifier
                .weight(1f)
                .heightIn(min = 48.dp)
                .testTag("${testTagPrefix}_prev_btn")
        ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(if (isEn) "Prev" else "پچھلا", fontFamily = uiFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }

        Button(
            onClick = onListen,
            shape = RoundedCornerShape(10.dp),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
            modifier = Modifier
                .weight(1.2f)
                .heightIn(min = 48.dp)
                .testTag("${testTagPrefix}_audio_btn")
        ) {
            Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(if (isEn) "Listen" else "آڈیو سنیں", fontFamily = uiFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }

        OutlinedButton(
            onClick = onNext,
            shape = RoundedCornerShape(10.dp),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
            modifier = Modifier
                .weight(1f)
                .heightIn(min = 48.dp)
                .testTag("${testTagPrefix}_next_btn")
        ) {
            Text(if (isEn) "Next" else "اگلا", fontFamily = uiFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(modifier = Modifier.width(4.dp))
            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
private fun OrderedZikrSectionCard(
    language: AppLanguage,
    heading: String,
    item: com.example.model.ZikrItem,
    totalCount: Int,
    onPrev: () -> Unit,
    onListen: () -> Unit,
    onNext: () -> Unit,
    lessonButtonLabel: String,
    onOpenLesson: () -> Unit,
    testTagPrefix: String,
    showOrderPrefix: Boolean = true
) {
    val extended = LocalNamazColors.current
    val fontSizes = LocalNamazFontSizes.current
    val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily
    val isEn = language == AppLanguage.ENGLISH

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = extended.cardSurface),
        border = BorderStroke(1.dp, extended.cardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SectionHeadingBadge(
                title = heading,
                counter = "${item.orderNumber} / $totalCount",
                uiFont = uiFont
            )

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
            ) {
                val badgeText = when {
                    !showOrderPrefix -> if (isEn) item.repeatEn else item.repeatUr
                    isEn -> "Order #${item.orderNumber}: ${item.repeatEn}"
                    else -> "ترتیب ${item.orderNumber}: ${item.repeatUr}"
                }
                Text(
                    text = badgeText,
                    fontFamily = uiFont,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = extended.arabicAccent,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                )
            }

            Surface(
                shape = RoundedCornerShape(14.dp),
                color = extended.greenSurface,
                border = BorderStroke(1.dp, extended.cardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = item.arabic,
                        fontFamily = AmiriFontFamily,
                        fontSize = fontSizes.arabicWordSize * 0.95f,
                        fontWeight = FontWeight.Bold,
                        color = extended.arabicAccent,
                        textAlign = TextAlign.Center,
                        lineHeight = fontSizes.arabicWordSize * 1.45f
                    )
                    HorizontalDivider(color = extended.cardBorder)
                    Text(
                        text = if (isEn) item.translationEn else item.translationUr,
                        fontFamily = uiFont,
                        fontSize = fontSizes.fullUrduSize,
                        fontWeight = FontWeight.Bold,
                        color = extended.blueText,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = if (isEn) item.refEn else item.refUr,
                        fontFamily = uiFont,
                        fontSize = 12.sp,
                        color = extended.mutedText,
                        textAlign = TextAlign.Center
                    )
                }
            }

            PagerControlsRow(
                language = language,
                onPrev = onPrev,
                onListen = onListen,
                onNext = onNext,
                testTagPrefix = testTagPrefix
            )

            OutlinedButton(
                onClick = onOpenLesson,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, extended.gold),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = extended.goldLight,
                    contentColor = extended.goldText
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag("${testTagPrefix}_open_lesson_btn")
            ) {
                Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(lessonButtonLabel, fontFamily = uiFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}
