package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AppCustomization
import com.example.model.AppLanguage
import com.example.model.AzkarSection
import com.example.model.GlobalSearchCategory
import com.example.model.GlobalSearchMatch
import com.example.model.Lesson
import com.example.model.SearchMatch
import com.example.model.UserProgressState
import com.example.ui.UiStrings
import com.example.ui.components.GlobalSearchResultCard
import com.example.ui.rememberDismissTextControls
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.theme.LocalNamazColors
import com.example.ui.theme.LocalNamazFontSizes
import com.example.ui.theme.RomanFontFamily
import com.example.ui.theme.UrduFontFamily

private enum class LessonStatusFilter {
    ALL,
    COMPLETED,
    REMAINING
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    language: AppLanguage,
    strings: UiStrings,
    appConfig: AppCustomization,
    lessons: List<Lesson>,
    progress: UserProgressState,
    searchQuery: String,
    searchResults: List<SearchMatch>,
    onSearchQueryChange: (String) -> Unit,
    onClearSearch: () -> Unit,
    onOpenLesson: (Int) -> Unit,
    onStartQuiz: (Int) -> Unit,
    onStartQuickQuiz: () -> Unit,
    onToggleLessonComplete: (Int) -> Unit,
    onOpenProgress: () -> Unit,
    onOpenAzkar: (AzkarSection) -> Unit,
    onToggleReminder: (Boolean) -> Unit = {},
    onOpenReminderSettings: () -> Unit = {},
    onOpenAbout: () -> Unit = {},
    onShareApp: () -> Unit = {},
    homeSearchCategory: GlobalSearchCategory = GlobalSearchCategory.ALL,
    homeGlobalSearchResults: List<GlobalSearchMatch> = emptyList(),
    onHomeSearchCategoryChange: (GlobalSearchCategory) -> Unit = {},
    onOpenGlobalSearchResult: (GlobalSearchMatch) -> Unit = { match ->
        match.lessonId?.let(onOpenLesson) ?: match.azkarSection?.let(onOpenAzkar)
    },
    onOpenFullSearch: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val extended = LocalNamazColors.current
    val fontSizes = LocalNamazFontSizes.current
    val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily
    val dismissTextControls = rememberDismissTextControls()
    var statusFilter by remember { mutableStateOf(LessonStatusFilter.ALL) }

    val activeLessonIds = remember(lessons) { lessons.map { it.id }.toSet() }
    val doneCount = progress.completedLessons.count { it in activeLessonIds }
    val total = lessons.size.coerceAtLeast(1)
    val remainingCount = (lessons.size - doneCount).coerceAtLeast(0)
    val pct = ((doneCount * 100f) / total).toInt()
    val quizzesDoneCount = progress.quizScores.keys.count { it in activeLessonIds }
    val animatedCompletionRatio by animateFloatAsState(
        targetValue = doneCount.toFloat() / total.toFloat(),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "dashboard_completion_ratio"
    )

    val filteredLessons = remember(lessons, progress.completedLessons, statusFilter) {
        when (statusFilter) {
            LessonStatusFilter.ALL -> lessons
            LessonStatusFilter.COMPLETED -> lessons.filter { progress.completedLessons.contains(it.id) }
            LessonStatusFilter.REMAINING -> lessons.filter { !progress.completedLessons.contains(it.id) }
        }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val columns = when {
            maxWidth >= 840.dp -> 3
            maxWidth >= 560.dp -> 2
            else -> 1
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(columns),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Hero Banner
            item(span = { GridItemSpan(columns) }) {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(2.dp, extended.gold),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Image(
                            painter = painterResource(id = R.drawable.img_hero_banner),
                            contentDescription = strings.appName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.matchParentSize()
                        )
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            extended.greenHeader.copy(alpha = 0.86f),
                                            extended.greenHeaderDark.copy(alpha = 0.92f)
                                        )
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.hero_bismillah),
                                color = Color(0xFFFBE498),
                                fontFamily = AmiriFontFamily,
                                fontSize = fontSizes.arabicHeroSize,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = appConfig.displayHeroSubtitle(language),
                                color = Color.White.copy(alpha = 0.95f),
                                fontFamily = uiFont,
                                fontSize = fontSizes.uiBodySize
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { onOpenLesson(progress.lastLessonId) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = extended.gold,
                                        contentColor = Color(0xFF1A1A1A)
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .heightIn(min = 48.dp)
                                        .testTag("continue_learning_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.MenuBook,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = strings.continueLearning,
                                        fontFamily = uiFont,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }

                                OutlinedButton(
                                    onClick = onStartQuickQuiz,
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = Color.Black.copy(alpha = 0.22f),
                                        contentColor = Color(0xFFFBE498)
                                    ),
                                    border = BorderStroke(1.5.dp, Color(0xFFFBE498)),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .heightIn(min = 48.dp)
                                        .testTag("quick_quiz_launch_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Bolt,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text(
                                        text = strings.quickQuizBtn,
                                        fontFamily = uiFont,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                            LinearProgressIndicator(
                                progress = { animatedCompletionRatio },
                                color = Color(0xFFFBE498),
                                trackColor = Color.Black.copy(alpha = 0.28f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(10.dp)
                                    .clip(RoundedCornerShape(999.dp))
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = strings.completedLessonsSummary(doneCount, total),
                                    color = Color(0xFFFBE498),
                                    fontFamily = uiFont,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Surface(
                                    onClick = onOpenProgress,
                                    shape = RoundedCornerShape(999.dp),
                                    color = Color.Black.copy(alpha = 0.25f),
                                    border = BorderStroke(1.dp, Color(0xFFFBE498)),
                                    modifier = Modifier.testTag("home_progress_pill")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.EmojiEvents,
                                            contentDescription = strings.viewProgressBtn,
                                            tint = Color(0xFFFBE498),
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Text(
                                            text = "$pct%",
                                            color = Color(0xFFFBE498),
                                            fontFamily = RomanFontFamily,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Visual 17-Lesson DataStore Progress Tracker Dashboard Card
            item(span = { GridItemSpan(columns) }) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = extended.cardSurface),
                    border = BorderStroke(1.5.dp, extended.gold),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_progress_tracker_card")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = strings.dashboardProgressTitle,
                                fontFamily = uiFont,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = extended.arabicAccent,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                shape = RoundedCornerShape(999.dp),
                                color = extended.goldLight,
                                border = BorderStroke(1.dp, extended.gold),
                                modifier = Modifier.testTag("dashboard_progress_fraction")
                            ) {
                                Text(
                                    text = "$doneCount / ${lessons.size} ($pct%)",
                                    fontFamily = RomanFontFamily,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = extended.goldText,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        // Segmented milestone strip showing completion across all lessons (1..17+)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("dashboard_lesson_segments"),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            lessons.forEach { lesson ->
                                val lessonDone = progress.completedLessons.contains(lesson.id)
                                val segmentColor = if (lessonDone) {
                                    MaterialTheme.colorScheme.primary
                                } else {
                                    extended.greenSurface
                                }
                                val segmentBorder = if (lessonDone) {
                                    extended.gold
                                } else {
                                    extended.cardBorder
                                }
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = segmentColor,
                                    border = BorderStroke(1.dp, segmentBorder),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(14.dp)
                                        .testTag("dashboard_segment_${lesson.id}")
                                ) {}
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.CheckCircle,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Text(
                                        text = strings.completedLessonsSummary(doneCount, lessons.size),
                                        fontFamily = uiFont,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = extended.arabicAccent
                                    )
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Schedule,
                                        contentDescription = null,
                                        tint = extended.mutedText,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Text(
                                        text = "${strings.dashboardRemainingSummary(remainingCount)} • ${strings.dashboardQuizzesSummary(quizzesDoneCount, lessons.size)}",
                                        fontFamily = uiFont,
                                        fontSize = 12.sp,
                                        color = extended.mutedText
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            OutlinedButton(
                                onClick = onOpenProgress,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, extended.gold),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = extended.greenSurface,
                                    contentColor = extended.arabicAccent
                                ),
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .testTag("dashboard_view_progress_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.EmojiEvents,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = strings.viewProgressBtn,
                                    fontFamily = uiFont,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // Daily Study Reminder Card
            item(span = { GridItemSpan(columns) }) {
                val formattedReminderTime = remember(progress.reminderHour, progress.reminderMinute, language) {
                    com.example.util.StudyReminderHelper.formatTimeDisplay(
                        progress.reminderHour,
                        progress.reminderMinute,
                        language
                    )
                }
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (progress.reminderEnabled) extended.greenSurface else extended.cardSurface
                    ),
                    border = BorderStroke(
                        if (progress.reminderEnabled) 1.5.dp else 1.dp,
                        if (progress.reminderEnabled) extended.gold else extended.cardBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_study_reminder_card")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = if (progress.reminderEnabled) {
                                    Icons.Filled.NotificationsActive
                                } else {
                                    Icons.Filled.NotificationsOff
                                },
                                contentDescription = null,
                                tint = if (progress.reminderEnabled) extended.arabicAccent else extended.mutedText,
                                modifier = Modifier.size(22.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = strings.reminderCardTitle,
                                    fontFamily = uiFont,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = extended.arabicAccent
                                )
                                Text(
                                    text = if (progress.reminderEnabled) {
                                        strings.reminderActiveSummary(formattedReminderTime)
                                    } else {
                                        strings.reminderOffSummary
                                    },
                                    fontFamily = uiFont,
                                    fontSize = 12.sp,
                                    color = extended.mutedText
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = onOpenReminderSettings,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, extended.gold),
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .testTag("reminder_configure_button")
                            ) {
                                Text(
                                    text = strings.reminderConfigureBtn,
                                    fontFamily = uiFont,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = extended.arabicAccent
                                )
                            }
                            Switch(
                                checked = progress.reminderEnabled,
                                onCheckedChange = onToggleReminder,
                                modifier = Modifier.testTag("reminder_enable_switch")
                            )
                        }
                    }
                }
            }

            // Global Search Panel (Lessons, Duas & Ahadees)
            item(span = { GridItemSpan(columns) }) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = extended.cardSurface),
                    border = BorderStroke(1.dp, extended.cardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = strings.globalSearchTitle,
                                fontFamily = uiFont,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = extended.arabicAccent
                            )
                            Surface(
                                onClick = {
                                    dismissTextControls()
                                    onOpenFullSearch()
                                },
                                shape = RoundedCornerShape(999.dp),
                                color = extended.greenSurface,
                                border = BorderStroke(1.dp, extended.gold),
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .testTag("home_open_full_search_button")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Search,
                                        contentDescription = null,
                                        tint = extended.arabicAccent,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = strings.openGlobalSearchBtn,
                                        fontFamily = uiFont,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = extended.arabicAccent
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = onSearchQueryChange,
                            placeholder = {
                                Text(
                                    text = strings.searchPlaceholder,
                                    fontFamily = uiFont,
                                    fontSize = 13.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Filled.Search,
                                    contentDescription = "Search",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(
                                        onClick = {
                                            dismissTextControls()
                                            onClearSearch()
                                        },
                                        modifier = Modifier.testTag("clear_search_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Clear,
                                            contentDescription = strings.clearSearch
                                        )
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = extended.gold,
                                unfocusedBorderColor = extended.cardBorder
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("search_input")
                        )

                        AnimatedVisibility(visible = searchQuery.trim().isNotEmpty()) {
                            Column(
                                modifier = Modifier.padding(top = 4.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val searchCategories = listOf(
                                    GlobalSearchCategory.ALL to strings.globalSearchCatAll,
                                    GlobalSearchCategory.LESSON to strings.globalSearchCatLessons,
                                    GlobalSearchCategory.DUA to strings.globalSearchCatDuas,
                                    GlobalSearchCategory.HADITH to strings.globalSearchCatHadith
                                )
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    searchCategories.forEach { (cat, label) ->
                                        val selected = homeSearchCategory == cat
                                        FilterChip(
                                            selected = selected,
                                            onClick = { onHomeSearchCategoryChange(cat) },
                                            label = {
                                                Text(
                                                    text = label,
                                                    fontFamily = uiFont,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp
                                                )
                                            },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                                selectedLabelColor = Color.White
                                            ),
                                            modifier = Modifier
                                                .heightIn(min = 48.dp)
                                                .testTag("home_search_cat_${cat.name.lowercase()}")
                                        )
                                    }
                                }

                                if (homeGlobalSearchResults.isNotEmpty()) {
                                    LazyColumn(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .heightIn(max = 300.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        items(homeGlobalSearchResults, key = { it.id }) { match ->
                                            GlobalSearchResultCard(
                                                language = language,
                                                strings = strings,
                                                match = match,
                                                onClick = {
                                                    dismissTextControls()
                                                    onOpenGlobalSearchResult(match)
                                                }
                                            )
                                        }
                                    }
                                } else if (searchResults.isNotEmpty()) {
                                    LazyColumn(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .heightIn(max = 260.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        items(searchResults) { match ->
                                            Surface(
                                                onClick = {
                                                    dismissTextControls()
                                                    onOpenLesson(match.lessonId)
                                                },
                                                shape = RoundedCornerShape(12.dp),
                                                color = extended.greenSurface,
                                                border = BorderStroke(1.dp, extended.cardBorder),
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .testTag("search_result_${match.lessonId}")
                                            ) {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Row(
                                                            verticalAlignment = Alignment.CenterVertically,
                                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                        ) {
                                                            Text(
                                                                text = match.ar,
                                                                fontFamily = AmiriFontFamily,
                                                                fontSize = 20.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = extended.arabicAccent
                                                            )
                                                            Text(
                                                                text = match.displayMeaning(language),
                                                                fontFamily = uiFont,
                                                                fontSize = 14.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = extended.redMeaning
                                                            )
                                                        }
                                                        if (match.pron.isNotEmpty()) {
                                                            Text(
                                                                text = match.pron,
                                                                fontFamily = UrduFontFamily,
                                                                fontSize = 12.sp,
                                                                color = extended.mutedText
                                                            )
                                                        }
                                                    }
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Surface(
                                                        shape = RoundedCornerShape(999.dp),
                                                        color = MaterialTheme.colorScheme.primary
                                                    ) {
                                                        Text(
                                                            text = "${strings.lessonTag(match.lessonId)}: ${match.displayLessonTitle(language)}",
                                                            color = Color.White,
                                                            fontFamily = uiFont,
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis,
                                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    Text(
                                        text = strings.noSearchResults,
                                        color = extended.mutedText,
                                        fontFamily = uiFont,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(8.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Islamic Azkar, Hadith, Janaza & Tasbeeh Quick-Launch Card
            item(span = { GridItemSpan(columns) }) {
                val isEn = language == AppLanguage.ENGLISH
                Card(
                    onClick = { onOpenAzkar(AzkarSection.SALAH_AZKAR) },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = extended.greenSurface),
                    border = BorderStroke(1.5.dp, extended.gold),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_azkar_feature_card")
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isEn) "🕌 Islamic Azkar, Hadith, Janaza & Tasbeeh"
                                else "🕌 مسنون اذکار، احادیث، جنازہ و تسبیح",
                                fontFamily = uiFont,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = extended.arabicAccent,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                shape = RoundedCornerShape(999.dp),
                                color = extended.goldLight,
                                border = BorderStroke(1.dp, extended.gold)
                            ) {
                                Text(
                                    text = if (isEn) "Tasbeeh: ${progress.tasbeehCount}/100"
                                    else "تسبیح: ${progress.tasbeehCount}/100",
                                    fontFamily = uiFont,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = extended.goldText,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Text(
                            text = if (isEn) "Asma-ul-Husna • Ahadees • After Salah (in order) • Morning/Evening • Namaz-e-Janaza • Counter"
                            else "اسماء الحسنیٰ • احادیث • نماز کے بعد مسنون اذکار • صبح و شام • نمازِ جنازہ کی دعائیں • تسبیح کاؤنٹر",
                            fontFamily = uiFont,
                            fontSize = 12.sp,
                            color = extended.mutedText
                        )

                        val quickSections = listOf(
                            AzkarSection.ASMA_UL_HUSNA to (if (isEn) "Asma-ul-Husna" else "اسماء الحسنیٰ"),
                            AzkarSection.AHADEES to (if (isEn) "Ahadees" else "احادیث"),
                            AzkarSection.SALAH_AZKAR to (if (isEn) "After Salah" else "بعد نماز اذکار"),
                            AzkarSection.MORNING_EVENING to (if (isEn) "Morning/Evening" else "صبح و شام"),
                            AzkarSection.JANAZA_DUAS to (if (isEn) "Namaz-e-Janaza" else "نمازِ جنازہ"),
                            AzkarSection.TASBEEH_COUNTER to (if (isEn) "Tasbeeh Counter" else "تسبیح کاؤنٹر")
                        )

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            quickSections.forEach { (section, label) ->
                                Surface(
                                    onClick = { onOpenAzkar(section) },
                                    shape = RoundedCornerShape(10.dp),
                                    color = extended.cardSurface,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
                                    modifier = Modifier
                                        .heightIn(min = 48.dp)
                                        .testTag("home_azkar_chip_${section.name.lowercase()}")
                                ) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                    ) {
                                        Text(
                                            text = label,
                                            fontFamily = uiFont,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = extended.arabicAccent
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Section Heading + Progress Tracker Filter Chips
            item(span = { GridItemSpan(columns) }) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = strings.allLessonsTitle,
                            fontFamily = uiFont,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = extended.arabicAccent
                        )
                        Text(
                            text = strings.totalLessonsBadge(lessons.size),
                            fontFamily = uiFont,
                            fontSize = 13.sp,
                            color = extended.mutedText
                        )
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        FilterChip(
                            selected = statusFilter == LessonStatusFilter.ALL,
                            onClick = { statusFilter = LessonStatusFilter.ALL },
                            label = {
                                Text(
                                    text = strings.filterAll(lessons.size),
                                    fontFamily = uiFont,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = extended.greenSurface,
                                selectedLabelColor = extended.arabicAccent
                            ),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("home_filter_all")
                        )
                        FilterChip(
                            selected = statusFilter == LessonStatusFilter.COMPLETED,
                            onClick = { statusFilter = LessonStatusFilter.COMPLETED },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Filled.CheckCircle,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = strings.filterCompleted(doneCount),
                                    fontFamily = uiFont,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = extended.goldLight,
                                selectedLabelColor = extended.goldText,
                                selectedLeadingIconColor = extended.goldText
                            ),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("home_filter_completed")
                        )
                        FilterChip(
                            selected = statusFilter == LessonStatusFilter.REMAINING,
                            onClick = { statusFilter = LessonStatusFilter.REMAINING },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Filled.Schedule,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = strings.filterRemaining(remainingCount),
                                    fontFamily = uiFont,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = extended.greenSurface,
                                selectedLabelColor = extended.arabicAccent
                            ),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("home_filter_remaining")
                        )
                    }
                }
            }

            if (filteredLessons.isEmpty()) {
                item(span = { GridItemSpan(columns) }) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = extended.greenSurface),
                        border = BorderStroke(1.dp, extended.cardBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("home_filter_empty_state")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = if (statusFilter == LessonStatusFilter.REMAINING) {
                                    Icons.Filled.EmojiEvents
                                } else {
                                    Icons.Filled.CheckCircle
                                },
                                contentDescription = null,
                                tint = extended.gold,
                                modifier = Modifier.size(34.dp)
                            )
                            Text(
                                text = if (statusFilter == LessonStatusFilter.REMAINING) {
                                    strings.allLessonsCompletedMsg
                                } else {
                                    strings.noCompletedLessonsYet
                                },
                                fontFamily = uiFont,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = extended.arabicAccent,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                // Lesson Cards
                items(filteredLessons, key = { it.id }) { lesson ->
                    val isDone = progress.completedLessons.contains(lesson.id)
                    val bestScore = progress.quizScores[lesson.id]
                    val previewAr = lesson.lines.firstOrNull()?.words?.joinToString(" ") { it.ar }.orEmpty()

                    LessonGridCard(
                        language = language,
                        strings = strings,
                        showSecondaryTitle = appConfig.showSecondaryTitle,
                        lesson = lesson,
                        isDone = isDone,
                        bestScore = bestScore,
                        previewAr = previewAr,
                        onOpenLesson = { onOpenLesson(lesson.id) },
                        onStartQuiz = { onStartQuiz(lesson.id) },
                        onToggleComplete = { onToggleLessonComplete(lesson.id) }
                    )
                }
            }

            // About & Share Card ("نورِ کاشف — ایپ کا تعارف")
            item(span = { GridItemSpan(columns) }) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = extended.greenSurface),
                    border = BorderStroke(1.5.dp, extended.gold),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_about_card")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Info,
                                contentDescription = null,
                                tint = extended.arabicAccent,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = strings.aboutTitle,
                                fontFamily = uiFont,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = extended.arabicAccent
                            )
                        }

                        Text(
                            text = strings.aboutSubtitle,
                            fontFamily = uiFont,
                            fontSize = 12.sp,
                            color = extended.mutedText
                        )

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = onOpenAbout,
                                shape = RoundedCornerShape(11.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary
                                ),
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .testTag("open_about_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Info,
                                    contentDescription = null,
                                    modifier = Modifier.size(17.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = strings.aboutOpenBtn,
                                    fontFamily = uiFont,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }

                            OutlinedButton(
                                onClick = onShareApp,
                                shape = RoundedCornerShape(11.dp),
                                border = BorderStroke(1.5.dp, extended.gold),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = extended.goldLight,
                                    contentColor = extended.goldText
                                ),
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .testTag("home_share_app_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Share,
                                    contentDescription = null,
                                    modifier = Modifier.size(17.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = strings.aboutShareBtn,
                                    fontFamily = uiFont,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LessonGridCard(
    language: AppLanguage,
    strings: UiStrings,
    showSecondaryTitle: Boolean,
    lesson: Lesson,
    isDone: Boolean,
    bestScore: Int?,
    previewAr: String,
    onOpenLesson: () -> Unit,
    onStartQuiz: () -> Unit,
    onToggleComplete: () -> Unit
) {
    val extended = LocalNamazColors.current
    val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily
    val topAccent = if (isDone) extended.gold else MaterialTheme.colorScheme.primary

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = extended.cardSurface),
        border = BorderStroke(if (isDone) 1.5.dp else 1.dp, if (isDone) extended.gold else extended.cardBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpenLesson)
            .testTag("lesson_card_${lesson.id}")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .background(topAccent)
            )
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(999.dp),
                            color = MaterialTheme.colorScheme.primary
                        ) {
                            Text(
                                text = strings.lessonTag(lesson.id),
                                color = Color.White,
                                fontFamily = uiFont,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(999.dp),
                            color = if (isDone) extended.goldLight else extended.greenSurface,
                            border = BorderStroke(1.dp, if (isDone) extended.gold else extended.cardBorder)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Icon(
                                    imageVector = if (isDone) Icons.Filled.CheckCircle else Icons.Filled.Schedule,
                                    contentDescription = null,
                                    tint = if (isDone) extended.goldText else extended.mutedText,
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = if (isDone) strings.completedBadge else strings.inProgressBadge,
                                    color = if (isDone) extended.goldText else extended.mutedText,
                                    fontFamily = uiFont,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        if (bestScore != null) {
                            Surface(
                                shape = RoundedCornerShape(999.dp),
                                color = extended.goldLight,
                                border = BorderStroke(1.dp, extended.gold)
                            ) {
                                Text(
                                    text = strings.quizBadge(bestScore),
                                    color = extended.goldText,
                                    fontFamily = uiFont,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    IconButton(
                        onClick = onToggleComplete,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("toggle_complete_btn_${lesson.id}")
                    ) {
                        Icon(
                            imageVector = if (isDone) Icons.Filled.CheckCircle else Icons.Outlined.CheckCircle,
                            contentDescription = if (isDone) strings.unmarkCompleteDesc else strings.markCompleteDesc,
                            tint = if (isDone) MaterialTheme.colorScheme.primary else extended.mutedText,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = lesson.displayTitle(language),
                    fontFamily = uiFont,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (showSecondaryTitle) {
                    Text(
                        text = if (language == AppLanguage.ENGLISH) lesson.titleUr else lesson.titleEn,
                        fontFamily = if (language == AppLanguage.ENGLISH) UrduFontFamily else RomanFontFamily,
                        fontSize = 12.sp,
                        color = extended.mutedText
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(extended.greenSurface)
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = previewAr,
                        fontFamily = AmiriFontFamily,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = extended.arabicAccent,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onOpenLesson,
                        shape = RoundedCornerShape(11.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("open_lesson_btn_${lesson.id}")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.MenuBook,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = strings.learnAction,
                            fontFamily = uiFont,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    OutlinedButton(
                        onClick = onStartQuiz,
                        shape = RoundedCornerShape(11.dp),
                        border = BorderStroke(1.5.dp, extended.gold),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = extended.goldLight,
                            contentColor = extended.goldText
                        ),
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .testTag("start_quiz_btn_${lesson.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Quiz,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = strings.quizAction,
                            fontFamily = uiFont,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}
