package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.AppLanguage
import com.example.ui.QuickQuizUiState
import com.example.ui.UiStrings
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.theme.CorrectBgLight
import com.example.ui.theme.CorrectBorder
import com.example.ui.theme.CorrectTextLight
import com.example.ui.theme.LocalNamazColors
import com.example.ui.theme.RomanFontFamily
import com.example.ui.theme.UrduFontFamily
import com.example.ui.theme.WrongBgLight
import com.example.ui.theme.WrongBorder
import com.example.ui.theme.WrongTextLight

@Composable
fun QuickQuizModal(
    language: AppLanguage,
    strings: UiStrings,
    state: QuickQuizUiState,
    totalBankSize: Int,
    onSelectAnswer: (Int) -> Unit,
    onNextQuestion: () -> Unit,
    onRestart: () -> Unit,
    onDismiss: () -> Unit
) {
    if (!state.isVisible) return

    val extended = LocalNamazColors.current
    val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily
    val layoutDirection = if (language == AppLanguage.ENGLISH) LayoutDirection.Ltr else LayoutDirection.Rtl

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .safeDrawingPadding()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = extended.cardSurface,
                    border = BorderStroke(2.dp, extended.gold),
                    tonalElevation = 6.dp,
                    shadowElevation = 12.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 560.dp)
                        .testTag("quick_quiz_dialog")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                    ) {
                        // Top gradient header bar
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(extended.greenHeader, extended.greenHeaderDark)
                                    )
                                )
                                .padding(horizontal = 14.dp, vertical = 12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = extended.gold,
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Filled.Bolt,
                                            contentDescription = null,
                                            tint = Color(0xFF1A1A1A),
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = strings.quickQuizTitle,
                                        color = Color(0xFFFBE498),
                                        fontFamily = uiFont,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    )
                                    Text(
                                        text = strings.quickQuizSubtitle(totalBankSize),
                                        color = Color.White.copy(alpha = 0.9f),
                                        fontFamily = uiFont,
                                        fontSize = 12.sp,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                IconButton(
                                    onClick = onDismiss,
                                    modifier = Modifier
                                        .size(48.dp)
                                        .testTag("quick_quiz_close_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Close,
                                        contentDescription = strings.quickQuizCloseDesc,
                                        tint = Color.White
                                    )
                                }
                            }
                        }

                        if (state.isFinished || state.questions.isEmpty()) {
                            val total = state.questions.size.coerceAtLeast(1)
                            val stars = when {
                                state.score == total -> "⭐⭐⭐"
                                state.score >= 3 -> "⭐⭐"
                                else -> "⭐"
                            }
                            val resultMsg = if (state.score >= 3) strings.quickQuizPassMsg else strings.quickQuizRetryMsg

                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(text = stars, fontSize = 42.sp)
                                Text(
                                    text = strings.quickQuizCompletedTitle,
                                    fontFamily = uiFont,
                                    fontSize = 21.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = extended.arabicAccent,
                                    textAlign = TextAlign.Center
                                )
                                Surface(
                                    shape = RoundedCornerShape(999.dp),
                                    color = extended.greenSurface,
                                    border = BorderStroke(1.5.dp, extended.gold)
                                ) {
                                    Text(
                                        text = strings.quizScoreText(state.score, total),
                                        fontFamily = uiFont,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = extended.arabicAccent,
                                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)
                                    )
                                }
                                Text(
                                    text = resultMsg,
                                    fontFamily = uiFont,
                                    fontSize = 14.sp,
                                    color = extended.mutedText,
                                    textAlign = TextAlign.Center
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = onDismiss,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .heightIn(min = 48.dp)
                                            .testTag("quick_quiz_done_button")
                                    ) {
                                        Text(
                                            text = strings.quickQuizDoneBtn,
                                            fontFamily = uiFont,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }

                                    Button(
                                        onClick = onRestart,
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = extended.gold,
                                            contentColor = Color(0xFF1A1A1A)
                                        ),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .weight(1.3f)
                                            .heightIn(min = 48.dp)
                                            .testTag("quick_quiz_retry_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Refresh,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = strings.quickQuizNewSetBtn,
                                            fontFamily = uiFont,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        } else {
                            val item = state.questions.getOrNull(state.currentIndex)
                            val total = state.questions.size.coerceAtLeast(1)
                            if (item != null) {
                                val q = item.question
                                val selectedIdx = state.selectedOptionIndex
                                val answered = selectedIdx != null
                                val targetProgress = (state.currentIndex + if (answered) 1 else 0).toFloat() / total.toFloat()
                                val animatedProgress by animateFloatAsState(
                                    targetValue = targetProgress,
                                    animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                                    label = "quick_quiz_progress"
                                )

                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Surface(
                                            shape = RoundedCornerShape(999.dp),
                                            color = extended.greenSurface,
                                            border = BorderStroke(1.dp, extended.cardBorder),
                                            modifier = Modifier.weight(1f, fill = false)
                                        ) {
                                            Text(
                                                text = "${strings.lessonTag(item.lessonId)}: ${item.displayLessonTitle(language)}",
                                                fontFamily = uiFont,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = extended.arabicAccent,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = strings.quickQuizCounter(state.currentIndex + 1, total, state.score),
                                            fontFamily = uiFont,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = extended.arabicAccent
                                        )
                                    }

                                    LinearProgressIndicator(
                                        progress = { animatedProgress },
                                        color = MaterialTheme.colorScheme.primary,
                                        trackColor = extended.cardBorder,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(8.dp)
                                            .clip(RoundedCornerShape(999.dp))
                                    )

                                    Surface(
                                        shape = RoundedCornerShape(14.dp),
                                        color = extended.greenSurface,
                                        border = BorderStroke(1.dp, extended.cardBorder),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(14.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            if (q.ar.isNotBlank()) {
                                                Text(
                                                    text = q.ar,
                                                    fontFamily = AmiriFontFamily,
                                                    fontSize = 26.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = extended.arabicAccent,
                                                    textAlign = TextAlign.Center
                                                )
                                                Spacer(modifier = Modifier.height(6.dp))
                                            }
                                            Text(
                                                text = q.q,
                                                fontFamily = uiFont,
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold,
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    }

                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        q.opts.forEachIndexed { idx, opt ->
                                            val isCorrectOption = idx == q.ans
                                            val isChosenWrong = answered && idx == selectedIdx && !isCorrectOption

                                            val bgColor = when {
                                                answered && isCorrectOption -> CorrectBgLight
                                                isChosenWrong -> WrongBgLight
                                                else -> MaterialTheme.colorScheme.background
                                            }
                                            val borderColor = when {
                                                answered && isCorrectOption -> CorrectBorder
                                                isChosenWrong -> WrongBorder
                                                else -> extended.cardBorder
                                            }
                                            val textColor = when {
                                                answered && isCorrectOption -> CorrectTextLight
                                                isChosenWrong -> WrongTextLight
                                                else -> MaterialTheme.colorScheme.onSurface
                                            }

                                            Surface(
                                                onClick = { if (!answered) onSelectAnswer(idx) },
                                                shape = RoundedCornerShape(12.dp),
                                                color = bgColor,
                                                border = BorderStroke(1.5.dp, borderColor),
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .heightIn(min = 50.dp)
                                                    .testTag("quick_quiz_option_$idx")
                                            ) {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                ) {
                                                    Surface(
                                                        shape = CircleShape,
                                                        color = when {
                                                            answered && isCorrectOption -> CorrectBorder
                                                            isChosenWrong -> WrongBorder
                                                            else -> MaterialTheme.colorScheme.primary
                                                        }
                                                    ) {
                                                        Text(
                                                            text = strings.quizOptionLabels.getOrElse(idx) { "${idx + 1}" },
                                                            color = Color.White,
                                                            fontFamily = uiFont,
                                                            fontSize = 12.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp)
                                                        )
                                                    }
                                                    Text(
                                                        text = opt,
                                                        fontFamily = uiFont,
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = textColor,
                                                        modifier = Modifier.weight(1f)
                                                    )
                                                    if (answered && isCorrectOption) {
                                                        Icon(
                                                            imageVector = Icons.Filled.Check,
                                                            contentDescription = null,
                                                            tint = CorrectTextLight,
                                                            modifier = Modifier.size(18.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    AnimatedVisibility(
                                        visible = answered,
                                        enter = fadeIn(),
                                        exit = fadeOut()
                                    ) {
                                        if (selectedIdx != null) {
                                            val isRight = selectedIdx == q.ans
                                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clip(RoundedCornerShape(11.dp))
                                                        .background(if (isRight) CorrectBgLight else WrongBgLight)
                                                        .padding(10.dp)
                                                ) {
                                                    Text(
                                                        text = if (isRight) strings.correctFeedback else strings.wrongFeedback(q.opts[q.ans]),
                                                        fontFamily = uiFont,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 13.sp,
                                                        color = if (isRight) CorrectTextLight else WrongTextLight
                                                    )
                                                }

                                                Button(
                                                    onClick = onNextQuestion,
                                                    shape = RoundedCornerShape(11.dp),
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .heightIn(min = 48.dp)
                                                        .testTag("quick_quiz_next_button")
                                                ) {
                                                    Text(
                                                        text = if (state.currentIndex + 1 >= total) strings.viewResultBtn else strings.nextQuestionBtn,
                                                        fontFamily = uiFont,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 15.sp
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
