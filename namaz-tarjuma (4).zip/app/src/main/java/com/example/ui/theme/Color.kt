package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Islamic Textbook Palette
val EmeraldGreen = Color(0xFF0F5D4A)
val EmeraldDark = Color(0xFF093E31)
val EmeraldLightSurface = Color(0xFFE8F5F1)
val WarmGold = Color(0xFFC9A227)
val WarmGoldLight = Color(0xFFFDF6E2)
val WarmGoldText = Color(0xFF9A7209)
val LightBg = Color(0xFFF6F8F7)
val LightCard = Color(0xFFFFFFFF)
val LightText = Color(0xFF1A2421)
val LightMuted = Color(0xFF52635D)
val LightBorder = Color(0xFFDCE5E1)
val LightRedMeaning = Color(0xFFB91C1C)
val LightBlueBg = Color(0xFFEBF4FF)
val LightBlueBorder = Color(0xFF2563EB)
val LightBlueText = Color(0xFF1E3A8A)

// Dark Theme Islamic Textbook Palette
val DarkBg = Color(0xFF0D1714)
val DarkCard = Color(0xFF152420)
val DarkText = Color(0xFFEEF5F2)
val DarkMuted = Color(0xFFA3B8B0)
val DarkGreenLight = Color(0xFF19382F)
val DarkGoldLight = Color(0xFF2B2412)
val DarkGoldText = Color(0xFFFBE498)
val DarkBorder = Color(0xFF264038)
val DarkRedMeaning = Color(0xFFFCA5A5)
val DarkBlueBg = Color(0xFF16243D)
val DarkBlueBorder = Color(0xFF60A5FA)
val DarkBlueText = Color(0xFFDBEAFE)

// Semantic Quiz Feedback Colors
val CorrectBgLight = Color(0xFFDCFCE7)
val CorrectBorder = Color(0xFF16A34A)
val CorrectTextLight = Color(0xFF14532D)
val WrongBgLight = Color(0xFFFEE2E2)
val WrongBorder = Color(0xFFDC2626)
val WrongTextLight = Color(0xFF7F1D1D)
