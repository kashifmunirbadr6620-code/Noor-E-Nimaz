# Project-specific R8 / ProGuard rules for Namaz Tarjuma (Offline Educational App)
# Applied when release minification (isMinifyEnabled = true) is enabled in app/build.gradle.kts.

# Preserve stack trace metadata, annotations, generics, and Kotlin metadata
-keepattributes SourceFile,LineNumberTable
-keepattributes Signature,InnerClasses,EnclosingMethod,*Annotation*
-keepattributes RuntimeVisibleAnnotations,RuntimeVisibleParameterAnnotations
-renamesourcefileattribute SourceFile

# Keep main entry point & BuildConfig
-keep public class com.example.MainActivity { *; }
-keep class com.example.BuildConfig { *; }

# Keep Jetpack ViewModels & UI state classes (including Quick Quiz & Quiz states)
-keep class com.example.ui.NamazViewModel { *; }
-keep class com.example.ui.QuizUiState { *; }
-keep class com.example.ui.QuickQuizUiState { *; }
-keep class com.example.ui.LearnUiState { *; }
-keep class com.example.ui.EditorUiState { *; }
-keepclassmembers class * extends androidx.lifecycle.ViewModel {
    public <init>(...);
}
-keepclassmembers class * extends androidx.lifecycle.AndroidViewModel {
    public <init>(android.app.Application);
}

# Keep all educational lesson models, Azkar models, customization configs, and enums
-keep class com.example.model.** { *; }
-keepclassmembers enum com.example.model.** {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# Keep offline lesson datasets, Azkar datasets, DataStore repository, and JSON serializers
-keep class com.example.data.** { *; }
-keep class com.example.ui.UiStrings { *; }
-keep class com.example.ui.AppStringsKt { *; }
-keep class com.example.ui.theme.** { *; }
-keep class com.example.R$* { *; }

# Keep Android TTS audio helper, print/share helper, study reminders, and lifecycle-safe text toolbar
-keep class com.example.util.AudioHelper { *; }
-keep class com.example.util.PrintShareHelper { *; }
-keep class com.example.util.StudyReminderHelper { *; }
-keep class com.example.util.StudyReminderReceiver { *; }
-keep class com.example.util.StudyReminderBootReceiver { *; }
-keep class com.example.ui.SafeTextToolbar { *; }
-keepclassmembers class * extends android.speech.tts.UtteranceProgressListener {
    public *;
    protected *;
}
-keepclassmembers class * extends android.webkit.WebViewClient {
    public *;
}

# Keep org.json classes used for custom lessons and backup JSON import/export
-keep class org.json.** { *; }

# Keep AndroidX DataStore Preferences & Protobuf-lite generated classes
-keep class androidx.datastore.** { *; }
-keepclassmembers class * extends androidx.datastore.preferences.protobuf.GeneratedMessageLite { *; }
-dontwarn androidx.datastore.**

# Keep AndroidX Lifecycle & SavedState reflection targets
-keep class androidx.lifecycle.** { *; }
-keepclassmembers class * extends androidx.lifecycle.LifecycleObserver { *; }

# Keep Jetpack Compose runtime & UI essentials
-keep class androidx.compose.runtime.** { *; }
-dontwarn androidx.compose.**

# Keep Kotlin Coroutines internal service loaders & volatile field updaters
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembers class kotlinx.coroutines.** {
    volatile <fields>;
}
-dontwarn kotlinx.coroutines.**
