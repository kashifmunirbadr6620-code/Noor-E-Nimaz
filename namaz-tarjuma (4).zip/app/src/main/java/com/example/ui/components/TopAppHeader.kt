package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Mosque
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppCustomization
import com.example.model.AppLanguage
import com.example.ui.UiStrings
import com.example.ui.theme.LocalNamazColors
import com.example.ui.theme.RomanFontFamily
import com.example.ui.theme.UrduFontFamily

@Composable
fun TopAppHeader(
    language: AppLanguage,
    strings: UiStrings,
    appConfig: AppCustomization,
    darkMode: Boolean,
    bigFont: Boolean,
    onToggleLanguage: () -> Unit,
    onToggleBigFont: () -> Unit,
    onToggleDarkMode: () -> Unit,
    onOpenGlobalSearch: () -> Unit = {},
    onHeaderTitleTap: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val extended = LocalNamazColors.current
    val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(
                Brush.linearGradient(
                    colors = listOf(extended.greenHeader, extended.greenHeaderDark)
                )
            )
            .statusBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val titleInteraction = remember { MutableInteractionSource() }
            Row(
                modifier = Modifier
                    .weight(1f)
                    .clickable(
                        interactionSource = titleInteraction,
                        indication = null,
                        onClick = onHeaderTitleTap
                    )
                    .testTag("app_header_title_area"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(11.dp))
                        .background(extended.gold.copy(alpha = 0.2f))
                        .border(1.5.dp, extended.gold, RoundedCornerShape(11.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Mosque,
                        contentDescription = strings.appName,
                        tint = Color(0xFFFBE498),
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = appConfig.displaySchoolHeader(language),
                        color = Color(0xFFF8DF8B),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = uiFont,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = appConfig.displayAppTitle(language),
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = uiFont,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    onClick = onOpenGlobalSearch,
                    shape = RoundedCornerShape(10.dp),
                    color = Color.White.copy(alpha = 0.14f),
                    contentColor = Color(0xFFFBE498),
                    border = BorderStroke(1.dp, extended.gold.copy(alpha = 0.7f)),
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("global_search_header_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Filled.Search,
                            contentDescription = strings.globalSearchHeaderDesc,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                HeaderToggleButton(
                    active = language == AppLanguage.ENGLISH,
                    label = strings.langToggleLabel,
                    fontFamily = RomanFontFamily,
                    testTag = "language_toggle_button",
                    onClick = onToggleLanguage,
                    icon = {
                        Icon(
                            imageVector = Icons.Filled.Translate,
                            contentDescription = "Language",
                            modifier = Modifier.size(14.dp)
                        )
                    }
                )
                HeaderToggleButton(
                    active = bigFont,
                    label = strings.bigFontShort,
                    fontFamily = uiFont,
                    testTag = "big_font_toggle_button",
                    onClick = onToggleBigFont,
                    icon = {
                        Icon(
                            imageVector = Icons.Filled.FormatSize,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                )
                HeaderToggleButton(
                    active = darkMode,
                    label = if (darkMode) strings.dayLabel else strings.nightLabel,
                    fontFamily = uiFont,
                    testTag = "night_mode_toggle_button",
                    onClick = onToggleDarkMode,
                    icon = {
                        Icon(
                            imageVector = if (darkMode) Icons.Filled.LightMode else Icons.Filled.DarkMode,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(3.5.dp)
                .background(extended.gold)
        )
    }
}

@Composable
private fun HeaderToggleButton(
    active: Boolean,
    label: String,
    fontFamily: androidx.compose.ui.text.font.FontFamily,
    testTag: String,
    onClick: () -> Unit,
    icon: @Composable () -> Unit
) {
    val extended = LocalNamazColors.current
    val bgColor = if (active) extended.gold else Color.White.copy(alpha = 0.14f)
    val contentColor = if (active) Color(0xFF1A1A1A) else Color.White
    val borderColor = if (active) Color.White else extended.gold.copy(alpha = 0.6f)

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        color = bgColor,
        contentColor = contentColor,
        border = BorderStroke(1.dp, borderColor),
        modifier = Modifier
            .height(48.dp)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            icon()
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = fontFamily
            )
        }
    }
}
