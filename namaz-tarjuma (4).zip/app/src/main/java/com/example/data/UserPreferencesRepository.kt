package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.UserProgressState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONObject

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(
    name = "grs_namaz_tarjuma_prefs"
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val COMPLETED_LESSONS = stringSetPreferencesKey("completed_lessons")
        val QUIZ_SCORES_JSON = stringPreferencesKey("quiz_scores_json")
        val DARK_MODE = booleanPreferencesKey("dark_mode")
        val BIG_FONT = booleanPreferencesKey("big_font")
        val LAST_LESSON_ID = intPreferencesKey("last_lesson_id")
        val CUSTOM_LESSONS_JSON = stringPreferencesKey("custom_lessons_json")
        val APP_LANGUAGE = stringPreferencesKey("app_language")
        val APP_CUSTOMIZATION_JSON = stringPreferencesKey("app_customization_json")
        val TASBEEH_COUNT = intPreferencesKey("tasbeeh_count")
        val REMINDER_ENABLED = booleanPreferencesKey("reminder_enabled")
        val REMINDER_HOUR = intPreferencesKey("reminder_hour")
        val REMINDER_MINUTE = intPreferencesKey("reminder_minute")
    }

    val progressFlow: Flow<UserProgressState> = context.dataStore.data.map { prefs ->
        val completed = prefs[Keys.COMPLETED_LESSONS]
            ?.mapNotNull { it.toIntOrNull() }
            ?.toSet()
            ?: emptySet()

        val scores = parseScoresJson(prefs[Keys.QUIZ_SCORES_JSON])
        val darkMode = prefs[Keys.DARK_MODE] ?: false
        val bigFont = prefs[Keys.BIG_FONT] ?: false
        val lastLessonId = prefs[Keys.LAST_LESSON_ID] ?: 1
        val language = com.example.model.AppLanguage.fromCode(prefs[Keys.APP_LANGUAGE])
        val tasbeehCount = prefs[Keys.TASBEEH_COUNT] ?: 0
        val reminderEnabled = prefs[Keys.REMINDER_ENABLED] ?: false
        val reminderHour = (prefs[Keys.REMINDER_HOUR] ?: 18).coerceIn(0, 23)
        val reminderMinute = (prefs[Keys.REMINDER_MINUTE] ?: 0).coerceIn(0, 59)

        UserProgressState(
            completedLessons = completed,
            quizScores = scores,
            darkMode = darkMode,
            bigFont = bigFont,
            lastLessonId = lastLessonId.coerceAtLeast(1),
            language = language,
            tasbeehCount = tasbeehCount.coerceIn(0, 100),
            reminderEnabled = reminderEnabled,
            reminderHour = reminderHour,
            reminderMinute = reminderMinute
        )
    }

    val customLessonsFlow: Flow<Map<Int, com.example.model.Lesson>> = context.dataStore.data.map { prefs ->
        LessonJsonSerializer.decodeLessonsMap(prefs[Keys.CUSTOM_LESSONS_JSON])
    }

    val appCustomizationFlow: Flow<com.example.model.AppCustomization> = context.dataStore.data.map { prefs ->
        AppCustomizationSerializer.decode(prefs[Keys.APP_CUSTOMIZATION_JSON])
    }

    suspend fun saveAppCustomization(config: com.example.model.AppCustomization) {
        context.dataStore.edit { prefs ->
            prefs[Keys.APP_CUSTOMIZATION_JSON] = AppCustomizationSerializer.encode(config)
        }
    }

    suspend fun resetAppCustomization() {
        context.dataStore.edit { prefs ->
            prefs.remove(Keys.APP_CUSTOMIZATION_JSON)
        }
    }

    suspend fun incrementTasbeehCount(): Int {
        var next = 0
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.TASBEEH_COUNT] ?: 0
            next = if (current >= 100) 1 else current + 1
            prefs[Keys.TASBEEH_COUNT] = next
        }
        return next
    }

    suspend fun resetTasbeehCount() {
        context.dataStore.edit { prefs ->
            prefs[Keys.TASBEEH_COUNT] = 0
        }
    }

    suspend fun setDailyReminder(enabled: Boolean, hour: Int, minute: Int) {
        context.dataStore.edit { prefs ->
            prefs[Keys.REMINDER_ENABLED] = enabled
            prefs[Keys.REMINDER_HOUR] = hour.coerceIn(0, 23)
            prefs[Keys.REMINDER_MINUTE] = minute.coerceIn(0, 59)
        }
    }

    suspend fun importBackup(
        config: com.example.model.AppCustomization?,
        lessons: Map<Int, com.example.model.Lesson>
    ) {
        context.dataStore.edit { prefs ->
            if (config != null) {
                prefs[Keys.APP_CUSTOMIZATION_JSON] = AppCustomizationSerializer.encode(config)
            }
            if (lessons.isNotEmpty()) {
                val merged = LessonJsonSerializer.decodeLessonsMap(prefs[Keys.CUSTOM_LESSONS_JSON]).toMutableMap()
                merged.putAll(lessons)
                prefs[Keys.CUSTOM_LESSONS_JSON] = LessonJsonSerializer.encodeLessonsMap(merged)
            }
        }
    }

    suspend fun toggleLanguage(): com.example.model.AppLanguage {
        var nextLang = com.example.model.AppLanguage.URDU
        context.dataStore.edit { prefs ->
            val current = com.example.model.AppLanguage.fromCode(prefs[Keys.APP_LANGUAGE])
            nextLang = if (current == com.example.model.AppLanguage.URDU) {
                com.example.model.AppLanguage.ENGLISH
            } else {
                com.example.model.AppLanguage.URDU
            }
            prefs[Keys.APP_LANGUAGE] = nextLang.code
        }
        return nextLang
    }

    suspend fun saveCustomLesson(lesson: com.example.model.Lesson) {
        context.dataStore.edit { prefs ->
            val current = LessonJsonSerializer.decodeLessonsMap(prefs[Keys.CUSTOM_LESSONS_JSON]).toMutableMap()
            current[lesson.id] = lesson
            prefs[Keys.CUSTOM_LESSONS_JSON] = LessonJsonSerializer.encodeLessonsMap(current)
        }
    }

    suspend fun removeCustomLesson(lessonId: Int) {
        context.dataStore.edit { prefs ->
            val current = LessonJsonSerializer.decodeLessonsMap(prefs[Keys.CUSTOM_LESSONS_JSON]).toMutableMap()
            current.remove(lessonId)
            prefs[Keys.CUSTOM_LESSONS_JSON] = LessonJsonSerializer.encodeLessonsMap(current)

            val completed = prefs[Keys.COMPLETED_LESSONS]?.toMutableSet()
            if (completed != null && completed.remove(lessonId.toString())) {
                prefs[Keys.COMPLETED_LESSONS] = completed
            }
            val scores = parseScoresJson(prefs[Keys.QUIZ_SCORES_JSON]).toMutableMap()
            if (scores.remove(lessonId) != null) {
                prefs[Keys.QUIZ_SCORES_JSON] = encodeScoresJson(scores)
            }
        }
    }

    suspend fun setLastLessonId(lessonId: Int) {
        context.dataStore.edit { prefs ->
            prefs[Keys.LAST_LESSON_ID] = lessonId
        }
    }

    suspend fun toggleDarkMode() {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.DARK_MODE] ?: false
            prefs[Keys.DARK_MODE] = !current
        }
    }

    suspend fun toggleBigFont() {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.BIG_FONT] ?: false
            prefs[Keys.BIG_FONT] = !current
        }
    }

    suspend fun toggleLessonComplete(lessonId: Int): Boolean {
        var nowCompleted = false
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.COMPLETED_LESSONS]?.toMutableSet() ?: mutableSetOf()
            val idStr = lessonId.toString()
            if (current.contains(idStr)) {
                current.remove(idStr)
                nowCompleted = false
            } else {
                current.add(idStr)
                nowCompleted = true
            }
            prefs[Keys.COMPLETED_LESSONS] = current
        }
        return nowCompleted
    }

    suspend fun setLessonCompleted(lessonId: Int, completed: Boolean) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.COMPLETED_LESSONS]?.toMutableSet() ?: mutableSetOf()
            val idStr = lessonId.toString()
            if (completed) {
                current.add(idStr)
            } else {
                current.remove(idStr)
            }
            prefs[Keys.COMPLETED_LESSONS] = current
        }
    }

    suspend fun saveQuizResult(lessonId: Int, score: Int) {
        context.dataStore.edit { prefs ->
            val scores = parseScoresJson(prefs[Keys.QUIZ_SCORES_JSON]).toMutableMap()
            val prevBest = scores[lessonId] ?: 0
            if (score >= prevBest) {
                scores[lessonId] = score
            }
            prefs[Keys.QUIZ_SCORES_JSON] = encodeScoresJson(scores)

            if (score >= 7) {
                val current = prefs[Keys.COMPLETED_LESSONS]?.toMutableSet() ?: mutableSetOf()
                current.add(lessonId.toString())
                prefs[Keys.COMPLETED_LESSONS] = current
            }
        }
    }

    suspend fun resetAllProgress() {
        context.dataStore.edit { prefs ->
            prefs.remove(Keys.COMPLETED_LESSONS)
            prefs.remove(Keys.QUIZ_SCORES_JSON)
        }
    }

    private fun parseScoresJson(json: String?): Map<Int, Int> {
        if (json.isNullOrBlank()) return emptyMap()
        return try {
            val obj = JSONObject(json)
            val map = mutableMapOf<Int, Int>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val id = k.toIntOrNull()
                if (id != null) {
                    map[id] = obj.optInt(k, 0)
                }
            }
            map
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private fun encodeScoresJson(scores: Map<Int, Int>): String {
        val obj = JSONObject()
        scores.forEach { (id, score) ->
            obj.put(id.toString(), score)
        }
        return obj.toString()
    }
}
