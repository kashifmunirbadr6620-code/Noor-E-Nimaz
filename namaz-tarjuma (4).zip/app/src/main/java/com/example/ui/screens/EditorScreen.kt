package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppCustomization
import com.example.model.AppLanguage
import com.example.model.AppThemePreset
import com.example.model.EditorMode
import com.example.model.Lesson
import com.example.ui.EditorUiState
import com.example.ui.UiStrings
import com.example.ui.rememberDismissTextControls
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.theme.LocalNamazColors
import com.example.ui.theme.RomanFontFamily
import com.example.ui.theme.UrduFontFamily

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EditorScreen(
    language: AppLanguage,
    strings: UiStrings,
    editorMode: EditorMode,
    onSwitchEditorMode: (EditorMode) -> Unit,
    appDraftConfig: AppCustomization,
    darkMode: Boolean,
    bigFont: Boolean,
    onUpdateAppBrandingDraft: (String, String, String, String, String, String) -> Unit,
    onSaveAppBranding: () -> Unit,
    onSelectThemePreset: (AppThemePreset) -> Unit,
    onUpdateFontScale: (Float) -> Unit,
    onToggleDarkMode: () -> Unit,
    onToggleBigFont: () -> Unit,
    onToggleLanguage: () -> Unit,
    onToggleShowPronunciationInBoxes: () -> Unit,
    onToggleShowSecondaryTitle: () -> Unit,
    onUpdateTtsSpeed: (Float) -> Unit,
    onBuildBackupJson: () -> String,
    onShareBackupJson: (String) -> Unit,
    onImportBackupJson: (String) -> Unit,
    onResetAppDefaults: () -> Unit,
    onEmitToast: (String) -> Unit,
    allLessons: List<Lesson>,
    editorState: EditorUiState,
    onSelectLessonToEdit: (Int) -> Unit,
    onCreateNewLesson: () -> Unit,
    onTitleUrChange: (String) -> Unit,
    onTitleEnChange: (String) -> Unit,
    onRomanKeysChange: (String) -> Unit,
    onLineLabelChange: (Int, String) -> Unit,
    onLineFullUrChange: (Int, String) -> Unit,
    onLineFullEnChange: (Int, String) -> Unit,
    onAddLine: () -> Unit,
    onRemoveLine: (Int) -> Unit,
    onWordChange: (Int, Int, String, String, String, String) -> Unit,
    onAddWord: (Int) -> Unit,
    onRemoveWord: (Int, Int) -> Unit,
    onLughatChange: (Int, String, String, String) -> Unit,
    onAddLughat: () -> Unit,
    onRemoveLughat: (Int) -> Unit,
    onSave: (Boolean) -> Unit,
    onResetToDefault: () -> Unit,
    onDeleteCustomLesson: () -> Unit,
    modifier: Modifier = Modifier
) {
    val extended = LocalNamazColors.current
    val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily
    val dismissTextControls = rememberDismissTextControls()
    var dropdownExpanded by remember { mutableStateOf(false) }
    var showConfirmResetDialog by remember { mutableStateOf(false) }

    if (showConfirmResetDialog) {
        val isBuiltIn = editorState.isBuiltIn
        AlertDialog(
            onDismissRequest = { showConfirmResetDialog = false },
            title = {
                Text(
                    text = if (isBuiltIn) strings.editorRestoreDialogTitle else strings.editorDeleteDialogTitle,
                    fontFamily = uiFont,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = if (isBuiltIn) strings.editorRestoreDialogBody else strings.editorDeleteDialogBody,
                    fontFamily = uiFont
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmResetDialog = false
                        if (isBuiltIn) onResetToDefault() else onDeleteCustomLesson()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text(
                        text = if (isBuiltIn) strings.confirmRestoreYes else strings.confirmDeleteYes,
                        fontFamily = uiFont,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmResetDialog = false }) {
                    Text(strings.cancelNo, fontFamily = uiFont, fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    LazyColumn(
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = modifier.fillMaxSize()
    ) {
        // Editor Mode Switcher: App Editor vs Lesson Editor
        item(key = "editor_mode_switcher") {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = extended.cardSurface,
                border = BorderStroke(1.dp, extended.cardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val isAppMode = editorMode == EditorMode.APP_EDITOR
                    Surface(
                        onClick = {
                            dismissTextControls()
                            onSwitchEditorMode(EditorMode.APP_EDITOR)
                        },
                        shape = RoundedCornerShape(10.dp),
                        color = if (isAppMode) MaterialTheme.colorScheme.primary else Color.Transparent,
                        contentColor = if (isAppMode) Color.White else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("editor_mode_app_button")
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                        ) {
                            Icon(Icons.Filled.Tune, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = strings.editorModeApp,
                                fontFamily = uiFont,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }

                    val isLessonMode = editorMode == EditorMode.LESSON_EDITOR
                    Surface(
                        onClick = {
                            dismissTextControls()
                            onSwitchEditorMode(EditorMode.LESSON_EDITOR)
                        },
                        shape = RoundedCornerShape(10.dp),
                        color = if (isLessonMode) MaterialTheme.colorScheme.primary else Color.Transparent,
                        contentColor = if (isLessonMode) Color.White else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("editor_mode_lesson_button")
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                        ) {
                            Icon(Icons.Filled.EditNote, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = strings.editorModeLesson,
                                fontFamily = uiFont,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }

        if (editorMode == EditorMode.APP_EDITOR) {
            appEditorItems(
                language = language,
                strings = strings,
                draftConfig = appDraftConfig,
                darkMode = darkMode,
                bigFont = bigFont,
                onUpdateBrandingDraft = onUpdateAppBrandingDraft,
                onSaveBranding = onSaveAppBranding,
                onSelectThemePreset = onSelectThemePreset,
                onUpdateFontScale = onUpdateFontScale,
                onToggleDarkMode = onToggleDarkMode,
                onToggleBigFont = onToggleBigFont,
                onToggleLanguage = onToggleLanguage,
                onToggleShowPronunciationInBoxes = onToggleShowPronunciationInBoxes,
                onToggleShowSecondaryTitle = onToggleShowSecondaryTitle,
                onUpdateTtsSpeed = onUpdateTtsSpeed,
                onBuildBackupJson = onBuildBackupJson,
                onShareBackupJson = onShareBackupJson,
                onImportBackupJson = onImportBackupJson,
                onResetAppDefaults = onResetAppDefaults,
                onEmitToast = onEmitToast
            )
        } else {
        // Editor Header & Lesson Selector
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = extended.cardSurface),
                border = BorderStroke(1.5.dp, extended.gold),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = strings.editorHeaderTitle,
                                fontFamily = uiFont,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = extended.arabicAccent
                            )
                            Text(
                                text = if (editorState.isNewLesson) {
                                    strings.editorNewSubtitle(editorState.lessonId)
                                } else {
                                    strings.editorEditSubtitle
                                },
                                fontFamily = uiFont,
                                fontSize = 12.sp,
                                color = extended.mutedText
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = {
                                dismissTextControls()
                                onCreateNewLesson()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = extended.gold,
                                contentColor = Color(0xFF1A1A1A)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("editor_new_lesson_button")
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = strings.newLessonBtn,
                                fontFamily = uiFont,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }

                    Box(modifier = Modifier.fillMaxWidth()) {
                        Surface(
                            onClick = {
                                dismissTextControls()
                                dropdownExpanded = true
                            },
                            shape = RoundedCornerShape(11.dp),
                            color = MaterialTheme.colorScheme.background,
                            border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .testTag("editor_lesson_dropdown")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val activeTitle = if (language == AppLanguage.ENGLISH) {
                                    editorState.titleEn.ifBlank { editorState.titleUr }
                                } else {
                                    editorState.titleUr.ifBlank { editorState.titleEn }
                                }
                                Text(
                                    text = if (editorState.isNewLesson) {
                                        strings.editorNewTag(editorState.lessonId)
                                    } else {
                                        strings.editorEditingTag(editorState.lessonId, activeTitle)
                                    },
                                    fontFamily = uiFont,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
                            }
                        }

                        DropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false }
                        ) {
                            allLessons.forEach { item ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = "${strings.lessonTag(item.id)}: ${item.displayTitle(language)}",
                                            fontFamily = uiFont
                                        )
                                    },
                                    onClick = {
                                        dismissTextControls()
                                        dropdownExpanded = false
                                        onSelectLessonToEdit(item.id)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Metadata Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = extended.cardSurface),
                border = BorderStroke(1.dp, extended.cardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = strings.editorBasicInfo,
                        fontFamily = uiFont,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = extended.arabicAccent
                    )

                    OutlinedTextField(
                        value = editorState.titleUr,
                        onValueChange = onTitleUrChange,
                        label = { Text(strings.editorTitleUrLabel, fontFamily = uiFont) },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("editor_title_ur_input")
                    )

                    OutlinedTextField(
                        value = editorState.titleEn,
                        onValueChange = onTitleEnChange,
                        label = { Text(strings.editorTitleEnLabel, fontFamily = uiFont) },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("editor_title_en_input")
                    )

                    OutlinedTextField(
                        value = editorState.romanKeys,
                        onValueChange = onRomanKeysChange,
                        label = { Text(strings.editorKeywordsLabel, fontFamily = uiFont) },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("editor_keywords_input")
                    )
                }
            }
        }

        // Section Heading for Lines
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = strings.editorLinesHeading(editorState.lines.size),
                    fontFamily = uiFont,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = extended.arabicAccent
                )
                Button(
                    onClick = onAddLine,
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier
                        .heightIn(min = 48.dp)
                        .testTag("editor_add_line_button")
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(strings.addLineBtn, fontFamily = uiFont, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        // Lines Editor Cards
        itemsIndexed(editorState.lines) { lineIdx, line ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = extended.cardSurface),
                border = BorderStroke(1.dp, extended.cardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = extended.greenSurface
                        ) {
                            Text(
                                text = strings.lineNumberTag(lineIdx + 1),
                                fontFamily = uiFont,
                                fontWeight = FontWeight.Bold,
                                color = extended.arabicAccent,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }

                        if (editorState.lines.size > 1) {
                            IconButton(
                                onClick = { onRemoveLine(lineIdx) },
                                modifier = Modifier.testTag("editor_remove_line_$lineIdx")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Delete,
                                    contentDescription = "Delete Line",
                                    tint = Color(0xFFDC2626)
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = line.label,
                        onValueChange = { onLineLabelChange(lineIdx, it) },
                        label = { Text(strings.editorLineLabel, fontFamily = uiFont) },
                        singleLine = true,
                        shape = RoundedCornerShape(11.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = line.fullUr,
                        onValueChange = { onLineFullUrChange(lineIdx, it) },
                        label = { Text(strings.editorLineFullUr, fontFamily = uiFont) },
                        shape = RoundedCornerShape(11.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("editor_line_full_ur_$lineIdx")
                    )

                    OutlinedTextField(
                        value = line.fullEn,
                        onValueChange = { onLineFullEnChange(lineIdx, it) },
                        label = { Text(strings.editorLineFullEn, fontFamily = uiFont) },
                        shape = RoundedCornerShape(11.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("editor_line_full_en_$lineIdx")
                    )

                    HorizontalDivider(color = extended.cardBorder)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = strings.wordsSectionLabel,
                            fontFamily = uiFont,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedButton(
                            onClick = { onAddWord(lineIdx) },
                            shape = RoundedCornerShape(9.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("editor_add_word_$lineIdx")
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(strings.addWordBtn, fontFamily = uiFont, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    line.words.forEachIndexed { wordIdx, word ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.background,
                            border = BorderStroke(1.dp, extended.cardBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = strings.wordNumberTag(wordIdx + 1),
                                        fontFamily = uiFont,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = extended.mutedText
                                    )
                                    if (line.words.size > 1) {
                                        IconButton(
                                            onClick = { onRemoveWord(lineIdx, wordIdx) },
                                            modifier = Modifier.size(48.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.Delete,
                                                contentDescription = "Delete Word",
                                                tint = Color(0xFFDC2626),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }

                                OutlinedTextField(
                                    value = word.ar,
                                    onValueChange = { onWordChange(lineIdx, wordIdx, it, word.ur, word.en, word.pron) },
                                    label = { Text(strings.editorWordAr, fontFamily = uiFont) },
                                    textStyle = MaterialTheme.typography.titleLarge.copy(fontFamily = AmiriFontFamily),
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("editor_word_ar_${lineIdx}_$wordIdx")
                                )

                                OutlinedTextField(
                                    value = word.ur,
                                    onValueChange = { onWordChange(lineIdx, wordIdx, word.ar, it, word.en, word.pron) },
                                    label = { Text(strings.editorWordUr, fontFamily = uiFont) },
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("editor_word_ur_${lineIdx}_$wordIdx")
                                )

                                OutlinedTextField(
                                    value = word.en,
                                    onValueChange = { onWordChange(lineIdx, wordIdx, word.ar, word.ur, it, word.pron) },
                                    label = { Text(strings.editorWordEn, fontFamily = uiFont) },
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                )

                                OutlinedTextField(
                                    value = word.pron,
                                    onValueChange = { onWordChange(lineIdx, wordIdx, word.ar, word.ur, word.en, it) },
                                    label = { Text(strings.editorWordPron, fontFamily = uiFont) },
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }

        // Lughat Section
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = extended.cardSurface),
                border = BorderStroke(1.dp, extended.cardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = strings.lughatSectionHeading(editorState.lughat.size),
                            fontFamily = uiFont,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = extended.arabicAccent
                        )
                        OutlinedButton(
                            onClick = onAddLughat,
                            shape = RoundedCornerShape(9.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("editor_add_lughat_button")
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(strings.addLughatBtn, fontFamily = uiFont, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    editorState.lughat.forEachIndexed { idx, lg ->
                        Column(
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = lg.ar,
                                    onValueChange = { onLughatChange(idx, it, lg.ur, lg.en) },
                                    label = { Text(strings.editorLughatAr, fontFamily = uiFont) },
                                    textStyle = MaterialTheme.typography.titleMedium.copy(fontFamily = AmiriFontFamily),
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = lg.ur,
                                    onValueChange = { onLughatChange(idx, lg.ar, it, lg.en) },
                                    label = { Text(strings.editorLughatUr, fontFamily = uiFont) },
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { onRemoveLughat(idx) },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Delete,
                                        contentDescription = "Delete",
                                        tint = Color(0xFFDC2626),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            OutlinedTextField(
                                value = lg.en,
                                onValueChange = { onLughatChange(idx, lg.ar, lg.ur, it) },
                                label = { Text(strings.editorLughatEn, fontFamily = uiFont) },
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }

        // Save / Preview / Reset Action Bar
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = extended.greenSurface),
                border = BorderStroke(1.5.dp, extended.gold),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = {
                                dismissTextControls()
                                onSave(false)
                            },
                            shape = RoundedCornerShape(11.dp),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("editor_save_button")
                        ) {
                            Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(strings.saveBtn, fontFamily = uiFont, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                dismissTextControls()
                                onSave(true)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = extended.gold,
                                contentColor = Color(0xFF1A1A1A)
                            ),
                            shape = RoundedCornerShape(11.dp),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("editor_save_and_view_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(strings.saveAndReadBtn, fontFamily = uiFont, fontWeight = FontWeight.Bold)
                        }

                        if ((editorState.isBuiltIn && editorState.isModified) || (!editorState.isBuiltIn && !editorState.isNewLesson)) {
                            OutlinedButton(
                                onClick = {
                                    dismissTextControls()
                                    showConfirmResetDialog = true
                                },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
                                border = BorderStroke(1.5.dp, Color(0xFFDC2626)),
                                shape = RoundedCornerShape(11.dp),
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .testTag("editor_reset_or_delete_button")
                            ) {
                                Icon(
                                    imageVector = if (editorState.isBuiltIn) Icons.Filled.Restore else Icons.Filled.Delete,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (editorState.isBuiltIn) strings.restoreOriginalBtn else strings.deleteLessonBtn,
                                    fontFamily = uiFont,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                }
            }
        }
        }
    }
}
