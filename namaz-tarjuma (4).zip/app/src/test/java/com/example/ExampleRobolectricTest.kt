package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertTextContains
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @get:Rule
  val composeTestRule = createComposeRule()

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Namaz Tarjuma", appName)
  }

  @Test
  fun `serialize and deserialize custom lesson`() {
    val original = com.example.data.LessonRepository.getLesson(2).copy(
      id = 15,
      titleUr = "خصوصی دعا",
      titleEn = "Special Supplication",
      isCustom = true
    )
    val encoded = com.example.data.LessonJsonSerializer.encodeLessonsMap(mapOf(15 to original))
    val decoded = com.example.data.LessonJsonSerializer.decodeLessonsMap(encoded)
    assertEquals(1, decoded.size)
    assertEquals("خصوصی دعا", decoded[15]?.titleUr)
    assertEquals("Special Supplication", decoded[15]?.titleEn)
    assertEquals(true, decoded[15]?.isCustom)
    assertEquals(original.lines.size, decoded[15]?.lines?.size)
    assertEquals(original.lines.first().fullEn, decoded[15]?.lines?.first()?.fullEn)
    assertEquals(original.lines.first().words.first().en, decoded[15]?.lines?.first()?.words?.first()?.en)
  }

  @Test
  fun `serialize and deserialize app customization and full backup`() {
    val config = com.example.model.AppCustomization(
      schoolNameUr = "مدارس اسلامیہ",
      schoolNameEn = "Madarsa Islamiya",
      appTitleUr = "میری نماز کتاب",
      appTitleEn = "My Namaz Book",
      themePreset = com.example.model.AppThemePreset.SAPPHIRE_INK,
      fontScale = 1.2f,
      ttsSpeed = 0.65f,
      showPronunciationInBoxes = true,
      showSecondaryTitle = false
    )
    val customLesson = com.example.data.LessonRepository.getLesson(1).copy(
      id = 16,
      titleUr = "اضافی دعا",
      titleEn = "Extra Dua",
      isCustom = true
    )

    val backupJson = com.example.data.AppCustomizationSerializer.encodeFullBackup(
      config = config,
      customLessons = mapOf(16 to customLesson)
    )
    val restored = com.example.data.AppCustomizationSerializer.decodeFullBackup(backupJson)

    assertEquals(config.schoolNameEn, restored?.appCustomization?.schoolNameEn)
    assertEquals(config.themePreset, restored?.appCustomization?.themePreset)
    assertEquals(true, restored?.appCustomization?.showPronunciationInBoxes)
    assertEquals(false, restored?.appCustomization?.showSecondaryTitle)
    assertEquals("Extra Dua", restored?.customLessons?.get(16)?.titleEn)
  }

  @Test
  fun `safe text toolbar finishes floating action mode at most once`() {
    var finishCount = 0
    var activeCallback: android.view.ActionMode.Callback? = null
    val context = ApplicationProvider.getApplicationContext<Context>()
    val fakeView = object : android.view.View(context) {
      override fun isAttachedToWindow(): Boolean = true

      override fun startActionMode(callback: android.view.ActionMode.Callback?, type: Int): android.view.ActionMode {
        activeCallback = callback
        return object : android.view.ActionMode() {
          override fun setTitle(title: CharSequence?) = Unit
          override fun setTitle(resId: Int) = Unit
          override fun setSubtitle(subtitle: CharSequence?) = Unit
          override fun setSubtitle(resId: Int) = Unit
          override fun setCustomView(view: android.view.View?) = Unit
          override fun invalidate() = Unit
          override fun finish() {
            finishCount += 1
            activeCallback?.onDestroyActionMode(this)
          }
          override fun getMenu(): android.view.Menu? = null
          override fun getTitle(): CharSequence? = null
          override fun getSubtitle(): CharSequence? = null
          override fun getCustomView(): android.view.View? = null
          override fun getMenuInflater(): android.view.MenuInflater? = null
        }
      }
    }

    val toolbar = com.example.ui.SafeTextToolbar(fakeView)
    toolbar.showMenu(
      rect = androidx.compose.ui.geometry.Rect(0f, 0f, 100f, 50f),
      onCopyRequested = {},
      onPasteRequested = null,
      onCutRequested = null,
      onSelectAllRequested = null
    )
    assertEquals(androidx.compose.ui.platform.TextToolbarStatus.Shown, toolbar.status)

    toolbar.hide()
    toolbar.hide()

    assertEquals(androidx.compose.ui.platform.TextToolbarStatus.Hidden, toolbar.status)
    assertEquals(1, finishCount)
  }

  @Test
  fun `progress tracker persists completed lessons to datastore`() = runTest {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = com.example.data.UserPreferencesRepository(context)
    repo.resetAllProgress()

    val marked = repo.toggleLessonComplete(3)
    assertEquals(true, marked)
    repo.setLessonCompleted(5, true)
    repo.saveQuizResult(lessonId = 7, score = 8)

    val snapshot = repo.progressFlow.first()
    assertEquals(setOf(3, 5, 7), snapshot.completedLessons)
    assertEquals(8, snapshot.quizScores[7])

    val unmarked = repo.toggleLessonComplete(3)
    assertEquals(false, unmarked)
    val updated = repo.progressFlow.first()
    assertEquals(setOf(5, 7), updated.completedLessons)
  }

  @Test
  fun `main dashboard visually shows completed lessons out of 17 from datastore`() = runTest {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = com.example.data.UserPreferencesRepository(context)
    repo.resetAllProgress()
    repo.setLessonCompleted(1, true)
    repo.setLessonCompleted(4, true)
    repo.setLessonCompleted(9, true)

    val savedProgress = repo.progressFlow.first().copy(language = com.example.model.AppLanguage.ENGLISH)
    val strings = com.example.ui.appStrings(com.example.model.AppLanguage.ENGLISH)

    composeTestRule.setContent {
      com.example.ui.theme.NamazTarjumaTheme {
        com.example.ui.screens.HomeScreen(
          language = com.example.model.AppLanguage.ENGLISH,
          strings = strings,
          appConfig = com.example.model.AppCustomization(),
          lessons = com.example.data.LessonRepository.allLessons,
          progress = savedProgress,
          searchQuery = "",
          searchResults = emptyList(),
          onSearchQueryChange = {},
          onClearSearch = {},
          onOpenLesson = {},
          onStartQuiz = {},
          onStartQuickQuiz = {},
          onToggleLessonComplete = {},
          onOpenProgress = {},
          onOpenAzkar = {}
        )
      }
    }

    composeTestRule.onNodeWithTag("home_progress_tracker_card").assertIsDisplayed()
    composeTestRule.onNodeWithTag("dashboard_progress_fraction").assertTextContains("3 / 17", substring = true)
    composeTestRule.onNodeWithTag("dashboard_lesson_segments").assertIsDisplayed()
  }
}
