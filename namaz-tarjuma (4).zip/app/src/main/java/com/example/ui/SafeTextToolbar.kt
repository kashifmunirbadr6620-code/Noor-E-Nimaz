package com.example.ui

import android.graphics.Rect as AndroidRect
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalTextToolbar
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.TextToolbar
import androidx.compose.ui.platform.TextToolbarStatus

private const val MENU_ITEM_COPY = 0
private const val MENU_ITEM_PASTE = 1
private const val MENU_ITEM_CUT = 2
private const val MENU_ITEM_SELECT_ALL = 3

/**
 * A lifecycle-guarded [TextToolbar] wrapper that avoids duplicate or detached
 * [ActionMode.finish] calls on Android's DecorView floating action mode.
 */
class SafeTextToolbar(private val view: View) : TextToolbar {

    private var actionMode: ActionMode? = null
    private var contentRect: Rect = Rect.Zero
    private var onCopyRequested: (() -> Unit)? = null
    private var onPasteRequested: (() -> Unit)? = null
    private var onCutRequested: (() -> Unit)? = null
    private var onSelectAllRequested: (() -> Unit)? = null

    override var status: TextToolbarStatus = TextToolbarStatus.Hidden
        private set

    override fun showMenu(
        rect: Rect,
        onCopyRequested: (() -> Unit)?,
        onPasteRequested: (() -> Unit)?,
        onCutRequested: (() -> Unit)?,
        onSelectAllRequested: (() -> Unit)?
    ) {
        if (!view.isAttachedToWindow) {
            hide()
            return
        }
        this.contentRect = rect
        this.onCopyRequested = onCopyRequested
        this.onPasteRequested = onPasteRequested
        this.onCutRequested = onCutRequested
        this.onSelectAllRequested = onSelectAllRequested

        val currentMode = actionMode
        if (currentMode == null) {
            status = TextToolbarStatus.Shown
            val started = view.startActionMode(callback, ActionMode.TYPE_FLOATING)
            actionMode = started
            if (started == null) {
                status = TextToolbarStatus.Hidden
            }
        } else {
            status = TextToolbarStatus.Shown
            currentMode.invalidate()
            currentMode.invalidateContentRect()
        }
    }

    override fun hide() {
        status = TextToolbarStatus.Hidden
        val currentMode = actionMode ?: return
        actionMode = null
        if (view.isAttachedToWindow) {
            currentMode.finish()
        }
    }

    internal fun clearOnDetach() {
        actionMode = null
        status = TextToolbarStatus.Hidden
    }

    private val callback = object : ActionMode.Callback2() {
        override fun onCreateActionMode(mode: ActionMode?, menu: Menu?): Boolean {
            if (mode == null || menu == null) return false
            populateMenu(menu)
            return true
        }

        override fun onPrepareActionMode(mode: ActionMode?, menu: Menu?): Boolean {
            if (mode == null || menu == null) return false
            menu.clear()
            populateMenu(menu)
            return true
        }

        override fun onActionItemClicked(mode: ActionMode?, item: MenuItem?): Boolean {
            val handled = when (item?.itemId) {
                MENU_ITEM_COPY -> {
                    onCopyRequested?.invoke()
                    true
                }
                MENU_ITEM_PASTE -> {
                    onPasteRequested?.invoke()
                    true
                }
                MENU_ITEM_CUT -> {
                    onCutRequested?.invoke()
                    true
                }
                MENU_ITEM_SELECT_ALL -> {
                    onSelectAllRequested?.invoke()
                    true
                }
                else -> false
            }
            if (handled) {
                hide()
            }
            return handled
        }

        override fun onDestroyActionMode(mode: ActionMode?) {
            if (actionMode === mode) {
                actionMode = null
                status = TextToolbarStatus.Hidden
            }
        }

        override fun onGetContentRect(mode: ActionMode?, view: View?, outRect: AndroidRect?) {
            outRect?.set(
                contentRect.left.toInt(),
                contentRect.top.toInt(),
                contentRect.right.toInt(),
                contentRect.bottom.toInt()
            )
        }
    }

    private fun populateMenu(menu: Menu) {
        onCopyRequested?.let {
            menu.add(0, MENU_ITEM_COPY, 0, android.R.string.copy)
                .setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM)
        }
        onPasteRequested?.let {
            menu.add(0, MENU_ITEM_PASTE, 1, android.R.string.paste)
                .setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM)
        }
        onCutRequested?.let {
            menu.add(0, MENU_ITEM_CUT, 2, android.R.string.cut)
                .setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM)
        }
        onSelectAllRequested?.let {
            menu.add(0, MENU_ITEM_SELECT_ALL, 3, android.R.string.selectAll)
                .setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM)
        }
    }
}

@Composable
fun ProvideSafeTextToolbar(content: @Composable () -> Unit) {
    val view = LocalView.current
    val toolbar = remember(view) { SafeTextToolbar(view) }
    DisposableEffect(view, toolbar) {
        val attachListener = object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) = Unit

            override fun onViewDetachedFromWindow(v: View) {
                toolbar.clearOnDetach()
            }
        }
        view.addOnAttachStateChangeListener(attachListener)
        onDispose {
            view.removeOnAttachStateChangeListener(attachListener)
            toolbar.hide()
        }
    }
    CompositionLocalProvider(LocalTextToolbar provides toolbar) {
        content()
    }
}

@Composable
fun rememberDismissTextControls(): () -> Unit {
    val focusManager: FocusManager = LocalFocusManager.current
    val textToolbar: TextToolbar = LocalTextToolbar.current
    return remember(focusManager, textToolbar) {
        {
            if (textToolbar.status == TextToolbarStatus.Shown) {
                textToolbar.hide()
            }
            focusManager.clearFocus(force = true)
        }
    }
}
