package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.AppLanguage
import com.example.ui.UiStrings
import com.example.ui.theme.LocalNamazColors
import com.example.ui.theme.RomanFontFamily
import com.example.ui.theme.UrduFontFamily
import com.example.util.PrintShareHelper

private const val ABOUT_PARAGRAPH_1 =
    "نورِ کاشف کو حافظ کاشف منیر بدر نے اس نیت سے ترتیب دیا ہے کہ عام فہم انداز میں نماز کے کلمات اور ان کا ترجمہ ہر خاص و عام کے لیے آسان بنایا جا سکے۔ بچوں اور بڑوں کو ابتدائی عمر ہی سے نماز کے معانی سکھانا ہماری اولین ذمہ داری ہے، اسی لیے اس ایپ کو خاص طور پر اس طرح ڈیزائن کیا گیا ہے کہ ہر لفظ کا الگ رنگ اور واضح ترجمہ دیکھ کر طالب علم باآسانی نماز کا مفہوم ذہن نشین کر سکیں۔"

private const val ABOUT_PARAGRAPH_2 =
    "یہ ایپ گھر اور مدرسے دونوں جگہ نماز کی درست ادائیگی اور فہم کے لیے ایک بہترین ساتھی ہے۔ آپ سے گزارش ہے کہ اس کاوش کو دوسروں تک پہنچائیں اور ہمیں اپنی خصوصی دعاؤں میں یاد رکھیں۔"

private const val FEEDBACK_TEXT =
    "اگر آپ کو ترجمے یا ٹائپنگ میں کہیں کوئی غلطی نظر آئے تو براہِ کرم ضرور مطلع فرمائیں، اور ثواب کی نیت سے اس ایپ کو اپنے دوستوں اور گھر والوں کے ساتھ شیئر کریں۔"

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AboutModal(
    isVisible: Boolean,
    language: AppLanguage,
    strings: UiStrings,
    onDismiss: () -> Unit
) {
    if (!isVisible) return

    val extended = LocalNamazColors.current
    val context = LocalContext.current
    val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily
    var statusNotice by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .safeDrawingPadding()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = extended.cardSurface,
                    border = BorderStroke(2.dp, extended.gold),
                    tonalElevation = 6.dp,
                    shadowElevation = 12.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 580.dp)
                        .testTag("about_dialog")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                    ) {
                        // Top gradient header bar
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(extended.greenHeader, extended.greenHeaderDark)
                                    )
                                )
                                .padding(horizontal = 14.dp, vertical = 12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = extended.gold,
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Filled.Info,
                                            contentDescription = null,
                                            tint = Color(0xFF1A1A1A),
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "ایپ کا تعارف",
                                        color = Color(0xFFFBE498),
                                        fontFamily = UrduFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    )
                                    Text(
                                        text = "نورِ کاشف • ترجمانِ نماز",
                                        color = Color.White.copy(alpha = 0.92f),
                                        fontFamily = UrduFontFamily,
                                        fontSize = 12.sp
                                    )
                                }

                                IconButton(
                                    onClick = onDismiss,
                                    modifier = Modifier
                                        .size(48.dp)
                                        .testTag("about_modal_close_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Close,
                                        contentDescription = strings.aboutCloseDesc,
                                        tint = Color.White
                                    )
                                }
                            }
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            // Main "ایپ کا تعارف" Card
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = extended.cardSurface,
                                border = BorderStroke(1.dp, extended.cardBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Text(
                                        text = "ایپ کا تعارف",
                                        fontFamily = UrduFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp,
                                        color = extended.arabicAccent
                                    )
                                    HorizontalDivider(color = extended.cardBorder)
                                    Text(
                                        text = ABOUT_PARAGRAPH_1,
                                        fontFamily = UrduFontFamily,
                                        fontSize = 15.sp,
                                        lineHeight = 31.sp
                                    )
                                    Text(
                                        text = ABOUT_PARAGRAPH_2,
                                        fontFamily = UrduFontFamily,
                                        fontSize = 15.sp,
                                        lineHeight = 31.sp
                                    )
                                }
                            }

                            // Feedback, Contact & Share Info Box
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = extended.greenSurface,
                                border = BorderStroke(1.5.dp, extended.gold),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("about_feedback_box")
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(15.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text(
                                        text = "تصحیح، مشورہ اور رابطہ",
                                        fontFamily = UrduFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = extended.arabicAccent
                                    )

                                    Text(
                                        text = FEEDBACK_TEXT,
                                        fontFamily = UrduFontFamily,
                                        fontSize = 14.sp,
                                        lineHeight = 29.sp
                                    )

                                    // Clean LTR contact box inside RTL card
                                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                        Surface(
                                            shape = RoundedCornerShape(12.dp),
                                            color = extended.cardSurface,
                                            border = BorderStroke(1.dp, extended.gold),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Text(
                                                    text = "WhatsApp: +923036620170 | Email: kashifmunirbadr6620@gmail.com",
                                                    fontFamily = RomanFontFamily,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    textAlign = TextAlign.Center,
                                                    color = extended.arabicAccent
                                                )

                                                FlowRow(
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    OutlinedButton(
                                                        onClick = {
                                                            val opened = PrintShareHelper.openExternalUri(
                                                                context,
                                                                "https://wa.me/923036620170"
                                                            )
                                                            if (!opened) {
                                                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                                                clipboard?.setPrimaryClip(ClipData.newPlainText("WhatsApp", "+923036620170"))
                                                                statusNotice = "واٹس ایپ نمبر (+923036620170) کاپی ہو گیا"
                                                            }
                                                        },
                                                        shape = RoundedCornerShape(10.dp),
                                                        border = BorderStroke(1.dp, extended.cardBorder),
                                                        modifier = Modifier.heightIn(min = 48.dp)
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Filled.Sms,
                                                            contentDescription = null,
                                                            modifier = Modifier.size(16.dp)
                                                        )
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Text("WhatsApp", fontFamily = RomanFontFamily, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                                    }

                                                    OutlinedButton(
                                                        onClick = {
                                                            val opened = PrintShareHelper.openExternalUri(
                                                                context,
                                                                "mailto:kashifmunirbadr6620@gmail.com"
                                                            )
                                                            if (!opened) {
                                                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                                                clipboard?.setPrimaryClip(ClipData.newPlainText("Email", "kashifmunirbadr6620@gmail.com"))
                                                                statusNotice = "ای میل (kashifmunirbadr6620@gmail.com) کاپی ہو گئی"
                                                            }
                                                        },
                                                        shape = RoundedCornerShape(10.dp),
                                                        border = BorderStroke(1.dp, extended.cardBorder),
                                                        modifier = Modifier.heightIn(min = 48.dp)
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Filled.Email,
                                                            contentDescription = null,
                                                            modifier = Modifier.size(16.dp)
                                                        )
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Text("Email", fontFamily = RomanFontFamily, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    Button(
                                        onClick = {
                                            val shared = PrintShareHelper.shareApp(context, language)
                                            if (!shared) {
                                                statusNotice = "ایپ کی تفصیل کلپ بورڈ پر کاپی ہو گئی ہے"
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = extended.gold,
                                            contentColor = Color(0xFF1A1A1A)
                                        ),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .heightIn(min = 48.dp)
                                            .testTag("about_share_app_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Share,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "ایپ شیئر کریں",
                                            fontFamily = UrduFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp
                                        )
                                    }

                                    if (statusNotice != null) {
                                        Text(
                                            text = statusNotice.orEmpty(),
                                            fontFamily = UrduFontFamily,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = extended.arabicAccent,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }
                            }

                            OutlinedButton(
                                onClick = onDismiss,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 48.dp)
                            ) {
                                Text(
                                    text = strings.quickQuizDoneBtn,
                                    fontFamily = uiFont,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
