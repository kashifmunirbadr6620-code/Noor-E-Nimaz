/* ==========================================================================
   نور کاشف (Noor Kashif) — 100% Offline-First PWA & Android Capacitor App
   Package ID: com.noorkashif.app | Default Language: Urdu (RTL)
   ========================================================================== */

const STORE_KEY = "noor_kashif_offline_v1";
const MEMORY_FALLBACK = {};

function safeStorageGet(key) {
  try {
    return window.localStorage.getItem(key);
  } catch (_) {
    return Object.prototype.hasOwnProperty.call(MEMORY_FALLBACK, key) ? MEMORY_FALLBACK[key] : null;
  }
}

function safeStorageSet(key, value) {
  MEMORY_FALLBACK[key] = value;
  try {
    window.localStorage.setItem(key, value);
  } catch (_) {
    /* Safe fallback when WebView storage quota or privacy restricts localStorage */
  }
}

function safeStorageRemove(key) {
  delete MEMORY_FALLBACK[key];
  try {
    window.localStorage.removeItem(key);
  } catch (_) {}
}

/* ==========================================================================
   Complete 17-Lesson Educational Dataset
   ========================================================================== */
const LESSONS = [
  {
    id: 1, titleUr: "تکبیرِ تحریمہ", titleEn: "Takbeer-e-Tahreema", keys: "takbeer allahu akbar",
    lines: [{
      labelUr: "تکبیر", labelEn: "Takbeer",
      fullUr: "اللہ سب سے بڑا ہے۔", fullEn: "Allah is the Greatest.",
      words: [
        { ar: "اَللّٰهُ", ur: "اللہ", en: "Allah", pron: "Allahu" },
        { ar: "أَكْبَرُ", ur: "سب سے بڑا ہے", en: "is the Greatest", pron: "Akbar" }
      ]
    }],
    lughat: [
      { ar: "اَللّٰهُ", ur: "اللہ (خدا کا ذاتی نام)", en: "Allah (Personal Name of God)" },
      { ar: "أَكْبَرُ", ur: "سب سے بڑا", en: "The Greatest" }
    ]
  },
  {
    id: 2, titleUr: "ثناء", titleEn: "Sana (Subhanaka)", keys: "sana subhanaka allahumma",
    lines: [
      {
        labelUr: "سطر ۱", labelEn: "Line 1",
        fullUr: "اے اللہ! تیری ذات پاک ہے اور تیری ہی تعریف کے ساتھ۔",
        fullEn: "Glory be to You, O Allah, and praise be to You.",
        words: [
          { ar: "سُبْحَانَكَ", ur: "تیری ذات پاک ہے", en: "Glory be to You", pron: "Subhanaka" },
          { ar: "اللّٰهُمَّ", ur: "اے اللہ", en: "O Allah", pron: "Allahumma" },
          { ar: "وَبِحَمْدِكَ", ur: "اور تیری تعریف کے ساتھ", en: "and with Your praise", pron: "Wa Bihamdika" }
        ]
      },
      {
        labelUr: "سطر ۲", labelEn: "Line 2",
        fullUr: "اور تیرا نام برکت والا اور تیری شان بلند ہے۔",
        fullEn: "Blessed is Your name and exalted is Your majesty.",
        words: [
          { ar: "وَتَبَارَكَ", ur: "اور برکت والا ہے", en: "blessed is", pron: "Wa Tabaraka" },
          { ar: "اسْمُكَ", ur: "تیرا نام", en: "Your name", pron: "Ismuka" },
          { ar: "وَتَعَالٰى", ur: "اور بلند ہے", en: "exalted is", pron: "Wa Ta'ala" },
          { ar: "جَدُّكَ", ur: "تیری شان", en: "Your majesty", pron: "Jadduka" }
        ]
      },
      {
        labelUr: "سطر ۳", labelEn: "Line 3",
        fullUr: "اور تیرے سوا کوئی معبود نہیں۔",
        fullEn: "And there is no deity besides You.",
        words: [
          { ar: "وَلَا", ur: "اور نہیں", en: "and there is no", pron: "Wa La" },
          { ar: "إِلٰهَ", ur: "کوئی معبود", en: "deity", pron: "Ilaha" },
          { ar: "غَيْرُكَ", ur: "تیرے سوا", en: "besides You", pron: "Ghairuka" }
        ]
      }
    ],
    lughat: [
      { ar: "سُبْحَانَكَ", ur: "تیری ذات پاک ہے", en: "Glory be to You" },
      { ar: "تَبَارَكَ", ur: "برکت والا ہے", en: "Blessed is" },
      { ar: "جَدُّكَ", ur: "تیری شان", en: "Your majesty" },
      { ar: "غَيْرُكَ", ur: "تیرے سوا", en: "Besides You" }
    ]
  },
  {
    id: 3, titleUr: "تعوذ", titleEn: "Ta'awwuz", keys: "taawuz auzu shaitan",
    lines: [{
      labelUr: "تعوذ", labelEn: "Ta'awwuz",
      fullUr: "میں اللہ کی پناہ مانگتا ہوں شیطان مردود سے۔",
      fullEn: "I seek refuge with Allah from the accursed Satan.",
      words: [
        { ar: "أَعُوْذُ", ur: "میں پناہ مانگتا ہوں", en: "I seek refuge", pron: "A'uzu" },
        { ar: "بِاللّٰهِ", ur: "اللہ کی", en: "with Allah", pron: "Billahi" },
        { ar: "مِنَ", ur: "سے", en: "from", pron: "Mina" },
        { ar: "الشَّيْطَانِ", ur: "شیطان", en: "Satan", pron: "Ash-Shaitani" },
        { ar: "الرَّجِيْمِ", ur: "مردود", en: "the accursed", pron: "Ar-Rajeem" }
      ]
    }],
    lughat: [
      { ar: "أَعُوْذُ", ur: "میں پناہ مانگتا ہوں", en: "I seek refuge" },
      { ar: "الشَّيْطَانِ", ur: "شیطان", en: "Satan" },
      { ar: "الرَّجِيْمِ", ur: "مردود / دھتکارا ہوا", en: "The accursed" }
    ]
  },
  {
    id: 4, titleUr: "تسمیہ", titleEn: "Tasmia (Bismillah)", keys: "tasmia bismillah rahman raheem",
    lines: [{
      labelUr: "تسمیہ", labelEn: "Tasmia",
      fullUr: "شروع اللہ کے نام سے جو نہایت مہربان، بہت رحم کرنے والا ہے۔",
      fullEn: "In the name of Allah, the Entirely Merciful, the Especially Merciful.",
      words: [
        { ar: "بِسْمِ", ur: "نام سے", en: "In the name of", pron: "Bismi" },
        { ar: "اللّٰهِ", ur: "اللہ کے", en: "Allah", pron: "Allahi" },
        { ar: "الرَّحْمٰنِ", ur: "نہایت مہربان", en: "Most Gracious", pron: "Ar-Rahmani" },
        { ar: "الرَّحِيْمِ", ur: "بہت رحم والا", en: "Most Merciful", pron: "Ar-Raheem" }
      ]
    }],
    lughat: [
      { ar: "بِسْمِ", ur: "نام سے", en: "In the name of" },
      { ar: "الرَّحْمٰنِ", ur: "بڑا مہربان", en: "Most Gracious" },
      { ar: "الرَّحِيْمِ", ur: "نہایت رحم والا", en: "Most Merciful" }
    ]
  },
  {
    id: 5, titleUr: "سورۃ الفاتحہ (مکمل)", titleEn: "Surah Al-Fatiha (Full)", keys: "fatiha alhamdu rabbil alameen mustaqeem",
    lines: [
      {
        labelUr: "آیت ۱", labelEn: "Verse 1",
        fullUr: "تمام تعریفیں اللہ کے لیے ہیں جو تمام جہانوں کا رب ہے۔",
        fullEn: "All praise is due to Allah, Lord of the worlds.",
        words: [
          { ar: "اَلْحَمْدُ", ur: "تمام تعریفیں", en: "All praise", pron: "Alhamdu" },
          { ar: "لِلّٰهِ", ur: "اللہ کے لیے ہیں", en: "is for Allah", pron: "Lillahi" },
          { ar: "رَبِّ", ur: "پروردگار", en: "Lord", pron: "Rabbi" },
          { ar: "الْعَالَمِيْنَ", ur: "تمام جہانوں کا", en: "of the worlds", pron: "Al-Alameen" }
        ]
      },
      {
        labelUr: "آیت ۲-۳", labelEn: "Verse 2-3",
        fullUr: "نہایت مہربان رحم والا، بدلے کے دن کا مالک۔",
        fullEn: "The Entirely Merciful, Sovereign of the Day of Recompense.",
        words: [
          { ar: "الرَّحْمٰنِ الرَّحِيْمِ", ur: "نہایت مہربان رحم والا", en: "Most Gracious, Most Merciful", pron: "Ar-Rahmanir Raheem" },
          { ar: "مٰلِكِ", ur: "مالک", en: "Sovereign", pron: "Maliki" },
          { ar: "يَوْمِ الدِّيْنِ", ur: "روزِ جزا کا", en: "of Day of Judgment", pron: "Yaumid-Deen" }
        ]
      },
      {
        labelUr: "آیت ۴", labelEn: "Verse 4",
        fullUr: "ہم صرف تیری ہی عبادت کرتے ہیں اور صرف تجھی سے مدد مانگتے ہیں۔",
        fullEn: "It is You we worship and You we ask for help.",
        words: [
          { ar: "إِيَّاكَ", ur: "صرف تیری ہی", en: "You alone", pron: "Iyyaka" },
          { ar: "نَعْبُدُ", ur: "ہم عبادت کرتے ہیں", en: "we worship", pron: "Na'budu" },
          { ar: "وَإِيَّاكَ", ur: "اور تجھی سے", en: "and You alone", pron: "Wa Iyyaka" },
          { ar: "نَسْتَعِيْنُ", ur: "ہم مدد مانگتے ہیں", en: "we seek help", pron: "Nasta'een" }
        ]
      },
      {
        labelUr: "آیت ۵", labelEn: "Verse 5",
        fullUr: "ہمیں سیدھا راستہ دکھا۔",
        fullEn: "Guide us to the straight path.",
        words: [
          { ar: "اِهْدِنَا", ur: "ہمیں چلا", en: "Guide us", pron: "Ihdina" },
          { ar: "الصِّرَاطَ", ur: "راستہ", en: "to the path", pron: "As-Sirata" },
          { ar: "الْمُسْتَقِيْمَ", ur: "سیدھا", en: "the straight", pron: "Al-Mustaqeem" }
        ]
      },
      {
        labelUr: "آیت ۶-۷", labelEn: "Verse 6-7",
        fullUr: "ان لوگوں کا راستہ جن پر تو نے انعام فرمایا، نہ کہ ان کا جن پر غضب ہوا اور نہ گمراہوں کا۔",
        fullEn: "Path of those blessed, not those who earned anger nor those astray.",
        words: [
          { ar: "صِرَاطَ الَّذِيْنَ أَنْعَمْتَ عَلَيْهِمْ", ur: "انعام یافتہ لوگوں کا راستہ", en: "Path of those You blessed", pron: "Siratal Lazeena An'amta" },
          { ar: "غَيْرِ الْمَغْضُوْبِ عَلَيْهِمْ", ur: "نہ کہ غضب شدگان کا", en: "Not those who earned anger", pron: "Ghairil Maghdoobi" },
          { ar: "وَلَا الضَّالِّيْنَ", ur: "اور نہ گمراہوں کا", en: "Nor those astray", pron: "Walad-Daalleen" }
        ]
      }
    ],
    lughat: [
      { ar: "اَلْحَمْدُ", ur: "تمام تعریف", en: "All praise" },
      { ar: "الْعَالَمِيْنَ", ur: "تمام جہان", en: "All worlds" },
      { ar: "نَعْبُدُ", ur: "ہم عبادت کرتے ہیں", en: "We worship" },
      { ar: "نَسْتَعِيْنُ", ur: "ہم مدد مانگتے ہیں", en: "We seek help" },
      { ar: "اِهْدِنَا", ur: "ہمیں ہدایت دے", en: "Guide us" },
      { ar: "الْمُسْتَقِيْمَ", ur: "سیدھا", en: "The straight" }
    ]
  },
  {
    id: 6, titleUr: "رکوع کی تسبیح", titleEn: "Ruku Tasbeeh", keys: "ruku subhana rabbiyal azeem",
    lines: [{
      labelUr: "رکوع", labelEn: "Ruku",
      fullUr: "پاک ہے میرا رب جو بڑی عظمت والا ہے۔",
      fullEn: "Glory be to my Lord, the Most Great.",
      words: [
        { ar: "سُبْحَانَ", ur: "پاک ہے", en: "Glory be to", pron: "Subhana" },
        { ar: "رَبِّيَ", ur: "میرا رب", en: "my Lord", pron: "Rabbiya" },
        { ar: "الْعَظِيْمِ", ur: "بڑی عظمت والا", en: "the Most Great", pron: "Al-Azeem" }
      ]
    }],
    lughat: [
      { ar: "سُبْحَانَ", ur: "پاک ہے", en: "Glory be to" },
      { ar: "الْعَظِيْمِ", ur: "بڑی عظمت والا", en: "The Most Great" }
    ]
  },
  {
    id: 7, titleUr: "رکوع سے اٹھنے کی دعا", titleEn: "Tasmee & Tahmeed", keys: "sami allahu liman hamidah rabbana lakal hamd",
    lines: [
      {
        labelUr: "تسمیع", labelEn: "Tasmee",
        fullUr: "اللہ نے اس کی بات سن لی جس نے اس کی تعریف کی۔",
        fullEn: "Allah hears those who praise Him.",
        words: [
          { ar: "سَمِعَ اللّٰهُ", ur: "اللہ نے سن لیا", en: "Allah hears", pron: "Sami'allahu" },
          { ar: "لِمَنْ حَمِدَهُ", ur: "جس نے اس کی تعریف کی", en: "who praises Him", pron: "Liman Hamidah" }
        ]
      },
      {
        labelUr: "تحمید", labelEn: "Tahmeed",
        fullUr: "اے ہمارے رب! اور تمام تعریفیں تیرے ہی لیے ہیں۔",
        fullEn: "Our Lord, and to You is all praise.",
        words: [
          { ar: "رَبَّنَا", ur: "اے ہمارے رب", en: "Our Lord", pron: "Rabbana" },
          { ar: "وَلَكَ الْحَمْدُ", ur: "اور تیرے لیے تمام تعریف ہے", en: "to You is all praise", pron: "Wa Lakal Hamd" }
        ]
      }
    ],
    lughat: [
      { ar: "سَمِعَ", ur: "سن لیا", en: "Heard" },
      { ar: "حَمِدَهُ", ur: "اس کی تعریف کی", en: "Praised Him" }
    ]
  },
  {
    id: 8, titleUr: "سجدہ کی تسبیح", titleEn: "Sajda Tasbeeh", keys: "sajda subhana rabbiyal ala",
    lines: [{
      labelUr: "سجدہ", labelEn: "Sajda",
      fullUr: "پاک ہے میرا رب جو سب سے بلند و بالا ہے۔",
      fullEn: "Glory be to my Lord, the Most High.",
      words: [
        { ar: "سُبْحَانَ", ur: "پاک ہے", en: "Glory be to", pron: "Subhana" },
        { ar: "رَبِّيَ", ur: "میرا رب", en: "my Lord", pron: "Rabbiya" },
        { ar: "الْأَعْلٰى", ur: "سب سے بلند", en: "the Most High", pron: "Al-A'la" }
      ]
    }],
    lughat: [{ ar: "الْأَعْلٰى", ur: "سب سے بلند و بالا", en: "The Most High" }]
  },
  {
    id: 9, titleUr: "تشہد / التحیات", titleEn: "Tashahhud / Attahiyyat", keys: "attahiyyat tashahhud ash-hadu",
    lines: [
      {
        labelUr: "سطر ۱", labelEn: "Line 1",
        fullUr: "تمام قولی، بدنی اور مالی عبادتیں اللہ ہی کے لیے ہیں۔",
        fullEn: "All greetings, prayers and pure words are for Allah.",
        words: [
          { ar: "اَلتَّحِيَّاتُ", ur: "تمام قولی عبادتیں", en: "All compliments", pron: "Attahiyyatu" },
          { ar: "لِلّٰهِ", ur: "اللہ کے لیے ہیں", en: "for Allah", pron: "Lillahi" },
          { ar: "وَالصَّلَوَاتُ وَالطَّيِّبَاتُ", ur: "اور بدنی و مالی عبادتیں", en: "prayers & good deeds", pron: "Wassalawatu Wat-Tayyibat" }
        ]
      },
      {
        labelUr: "سطر ۲", labelEn: "Line 2",
        fullUr: "اے نبی (ﷺ) آپ پر سلامتی، رحمت اور برکتیں ہوں۔ ہم پر اور نیک بندوں پر سلام ہو۔",
        fullEn: "Peace be upon you O Prophet, and upon us and all righteous servants.",
        words: [
          { ar: "اَلسَّلَامُ عَلَيْكَ أَيُّهَا النَّبِيُّ", ur: "اے نبی ﷺ آپ پر سلام", en: "Peace upon you O Prophet", pron: "Assalamu Alaika Ayyuhan-Nabiyyu" },
          { ar: "وَرَحْمَةُ اللّٰهِ وَبَرَكَاتُهُ", ur: "اور اللہ کی رحمت و برکتیں", en: "mercy & blessings of Allah", pron: "Wa Rahmatullahi Wa Barakatuh" },
          { ar: "اَلسَّلَامُ عَلَيْنَا وَعَلٰى عِبَادِ اللّٰهِ الصَّالِحِيْنَ", ur: "ہم پر اور نیک بندوں پر سلام", en: "Peace on us & righteous servants", pron: "Alaina Wa Ala Ibadillahis-Saliheen" }
        ]
      },
      {
        labelUr: "سطر ۳", labelEn: "Line 3",
        fullUr: "میں گواہی دیتا ہوں کہ اللہ کے سوا کوئی معبود نہیں اور محمد ﷺ اس کے بندے اور رسول ہیں۔",
        fullEn: "I bear witness none has right to be worshipped except Allah, and Muhammad is His servant and Messenger.",
        words: [
          { ar: "أَشْهَدُ أَنْ لَّا إِلٰهَ إِلَّا اللّٰهُ", ur: "گواہی دیتا ہوں اللہ کے سوا کوئی معبود نہیں", en: "I witness none worthy except Allah", pron: "Ash-hadu An La Ilaha Illallah" },
          { ar: "وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُوْلُهُ", ur: "اور محمد ﷺ اس کے بندے و رسول ہیں", en: "and Muhammad is His servant & Messenger", pron: "Anna Muhammadan Abduhu Wa Rasuluh" }
        ]
      }
    ],
    lughat: [
      { ar: "اَلتَّحِيَّاتُ", ur: "قولی عبادتیں", en: "Greetings / Verbal worship" },
      { ar: "الصَّالِحِيْنَ", ur: "نیک بندے", en: "The righteous" },
      { ar: "أَشْهَدُ", ur: "میں گواہی دیتا ہوں", en: "I bear witness" }
    ]
  },
  {
    id: 10, titleUr: "درودِ ابراہیم", titleEn: "Durood-e-Ibrahim", keys: "durood ibrahim salli barik",
    lines: [
      {
        labelUr: "رحمت کی دعا", labelEn: "Blessing Prayer",
        fullUr: "اے اللہ! محمد ﷺ اور آپ کی آل پر رحمت نازل فرما جیسا کہ ابراہیمؑ اور آپ کی آل پر فرمائی۔",
        fullEn: "O Allah, send mercy upon Muhammad and his family as You sent upon Ibrahim and his family.",
        words: [
          { ar: "اَللّٰهُمَّ صَلِّ عَلٰى مُحَمَّدٍ وَّعَلٰى آلِ مُحَمَّدٍ", ur: "اے اللہ محمد ﷺ و آلِ محمد پر رحمت بھیج", en: "Send mercy upon Muhammad & family", pron: "Allahumma Salli Ala Muhammad" },
          { ar: "كَمَا صَلَّيْتَ عَلٰى إِبْرَاهِيْمَ وَعَلٰى آلِ إِبْرَاهِيْمَ", ur: "جیسا ابراہیمؑ و آلِ ابراہیم پر بھیجی", en: "As upon Ibrahim & family", pron: "Kama Sallaita Ala Ibrahim" },
          { ar: "إِنَّكَ حَمِيْدٌ مَّجِيْدٌ", ur: "بے شک تو قابلِ تعریف و بزرگ ہے", en: "You are Praiseworthy, Glorious", pron: "Innaka Hameedum Majeed" }
        ]
      },
      {
        labelUr: "برکت کی دعا", labelEn: "Barakah Prayer",
        fullUr: "اے اللہ! محمد ﷺ اور آپ کی آل پر برکت نازل فرما جیسا کہ ابراہیمؑ پر فرمائی۔",
        fullEn: "O Allah, bless Muhammad and his family as You blessed Ibrahim and his family.",
        words: [
          { ar: "اَللّٰهُمَّ بَارِكْ عَلٰى مُحَمَّدٍ وَّعَلٰى آلِ مُحَمَّدٍ", ur: "اے اللہ محمد ﷺ و آل پر برکت نازل فرما", en: "Bless Muhammad & his family", pron: "Allahumma Barik Ala Muhammad" },
          { ar: "كَمَا بَارَكْتَ عَلٰى إِبْرَاهِيْمَ وَعَلٰى آلِ إِبْرَاهِيْمَ", ur: "جیسا ابراہیمؑ و آلِ ابراہیم پر فرمائی", en: "As You blessed Ibrahim & family", pron: "Kama Barakta Ala Ibrahim" }
        ]
      }
    ],
    lughat: [
      { ar: "صَلِّ", ur: "رحمت نازل فرما", en: "Send mercy" },
      { ar: "بَارِكْ", ur: "برکت نازل فرما", en: "Send blessings" },
      { ar: "حَمِيْدٌ مَّجِيْدٌ", ur: "تعریف والا، بزرگی والا", en: "Praiseworthy, Glorious" }
    ]
  },
  {
    id: 11, titleUr: "درود کے بعد کی دعا", titleEn: "Dua-e-Masura", keys: "dua masura zalamtu nafsi",
    lines: [{
      labelUr: "دعائے ماثورہ", labelEn: "Dua-e-Masura",
      fullUr: "اے اللہ! میں نے اپنی جان پر بہت ظلم کیا، تیرے سوا کوئی گناہ بخشنے والا نہیں، پس مجھے بخش دے اور رحم فرما۔",
      fullEn: "O Allah, I have wronged myself greatly and none forgives sins except You; so forgive me and have mercy on me.",
      words: [
        { ar: "اَللّٰهُمَّ إِنِّيْ ظَلَمْتُ نَفْسِيْ ظُلْمًا كَثِيْرًا", ur: "میں نے اپنی جان پر بہت ظلم کیا", en: "I wronged myself greatly", pron: "Zalamtu Nafsi Zulman Kaseera" },
        { ar: "وَلَا يَغْفِرُ الذُّنُوْبَ إِلَّا أَنْتَ", ur: "تیرے سوا گناہ کوئی نہیں بخشتا", en: "none forgives sins except You", pron: "La Yaghfiruz Zunooba Illa Anta" },
        { ar: "فَاغْفِرْ لِيْ مَغْفِرَةً مِّنْ عِنْدِكَ وَارْحَمْنِيْ", ur: "پس مجھے اپنے پاس سے بخشش و رحمت دے", en: "forgive me & have mercy", pron: "Faghfir Li Warhamni" },
        { ar: "إِنَّكَ أَنْتَ الْغَفُوْرُ الرَّحِيْمُ", ur: "تو بڑا بخشنے والا مہربان ہے", en: "You are Most Forgiving, Merciful", pron: "Al-Ghafoorur Raheem" }
      ]
    }],
    lughat: [
      { ar: "ظَلَمْتُ", ur: "میں نے ظلم کیا", en: "I wronged" },
      { ar: "الذُّنُوْبَ", ur: "گناہ", en: "Sins" },
      { ar: "الْغَفُوْرُ", ur: "بہت بخشنے والا", en: "All-Forgiving" }
    ]
  },
  {
    id: 12, titleUr: "دعائے قنوت", titleEn: "Dua Qunoot", keys: "qunoot nastaeenuka witr",
    lines: [
      {
        labelUr: "سطر ۱", labelEn: "Line 1",
        fullUr: "اے اللہ! ہم تجھ سے مدد و بخشش مانگتے ہیں، تجھ پر ایمان اور بھروسہ کرتے ہیں۔",
        fullEn: "O Allah, we seek Your help and forgiveness, believe in You and rely on You.",
        words: [
          { ar: "اَللّٰهُمَّ إِنَّا نَسْتَعِيْنُكَ وَنَسْتَغْفِرُكَ", ur: "ہم تجھ سے مدد و مغفرت مانگتے ہیں", en: "We seek Your help & forgiveness", pron: "Nasta'eenuka Wa Nastaghfiruka" },
          { ar: "وَنُؤْمِنُ بِكَ وَنَتَوَكَّلُ عَلَيْكَ", ur: "تجھ پر ایمان و بھروسہ کرتے ہیں", en: "We believe & rely on You", pron: "Nu'minu Bika Wa Natawakkalu" },
          { ar: "وَنُثْنِيْ عَلَيْكَ الْخَيْرَ", ur: "اور تیری بہترین تعریف کرتے ہیں", en: "and praise You with all good", pron: "Nusni Alaikal Khair" }
        ]
      },
      {
        labelUr: "سطر ۲", labelEn: "Line 2",
        fullUr: "ہم تیرا شکر کرتے ہیں، تیری ہی عبادت، نماز و سجدہ کرتے اور تیری رحمت کے امیدوار ہیں۔",
        fullEn: "We thank You, worship You alone, pray and prostrate to You, and hope for Your mercy.",
        words: [
          { ar: "وَنَشْكُرُكَ وَلَا نَكْفُرُكَ", ur: "شکر کرتے ہیں، ناشکری نہیں کرتے", en: "We thank You, never ungrateful", pron: "Nashkuruka Wa La Nakfuruk" },
          { ar: "إِيَّاكَ نَعْبُدُ وَلَكَ نُصَلِّيْ وَنَسْجُدُ", ur: "تیری عبادت، نماز اور سجدہ کرتے ہیں", en: "You we worship, pray & prostrate", pron: "Iyyaka Na'budu Wa Nasjud" },
          { ar: "وَنَرْجُوْ رَحْمَتَكَ وَنَخْشٰى عَذَابَكَ", ur: "رحمت کے امیدوار اور عذاب سے ڈرتے ہیں", en: "hope for mercy & fear punishment", pron: "Narju Rahmataka Wa Nakhsha" }
        ]
      }
    ],
    lughat: [
      { ar: "نَسْتَعِيْنُكَ", ur: "تجھ سے مدد مانگتے ہیں", en: "We seek Your help" },
      { ar: "نَتَوَكَّلُ", ur: "بھروسہ کرتے ہیں", en: "We trust/rely" },
      { ar: "نَخْشٰى", ur: "ہم ڈرتے ہیں", en: "We fear" }
    ]
  },
  {
    id: 13, titleUr: "تین قل (اخلاص، فلق، ناس)", titleEn: "Three Quls (Ikhlas, Falaq, Naas)", keys: "qul ikhlas falaq naas ahad samad",
    lines: [
      {
        labelUr: "سورۃ الاخلاص", labelEn: "Surah Al-Ikhlas",
        fullUr: "کہہ دیجیے وہ اللہ ایک ہے، بے نیاز ہے، نہ اس کی کوئی اولاد اور نہ وہ کسی سے پیدا ہوا، اور اس کے برابر کوئی نہیں۔",
        fullEn: "Say, He is Allah, One, Eternal Refuge; He neither begets nor is born, nor is there to Him any equivalent.",
        words: [
          { ar: "قُلْ هُوَ اللّٰهُ أَحَدٌ", ur: "کہو وہ اللہ ایک ہے", en: "Say He is Allah, One", pron: "Qul Huwallahu Ahad" },
          { ar: "اللّٰهُ الصَّمَدُ", ur: "اللہ بے نیاز ہے", en: "Allah Eternal Refuge", pron: "Allahus-Samad" },
          { ar: "لَمْ يَلِدْ وَلَمْ يُوْلَدْ", ur: "نہ جنا اور نہ جنا گیا", en: "Neither begets nor is born", pron: "Lam Yalid Wa Lam Yoolad" },
          { ar: "وَلَمْ يَكُنْ لَّهُ كُفُوًا أَحَدٌ", ur: "اور اس کے برابر کوئی نہیں", en: "None equal to Him", pron: "Kufuwan Ahad" }
        ]
      },
      {
        labelUr: "سورۃ الفلق", labelEn: "Surah Al-Falaq",
        fullUr: "کہو میں صبح کے رب کی پناہ مانگتا ہوں ہر مخلوق، اندھیری رات، جادو اور حاسد کے شر سے۔",
        fullEn: "Say, I seek refuge in the Lord of daybreak from the evil of creation, darkness, sorcery, and the envier.",
        words: [
          { ar: "قُلْ أَعُوْذُ بِرَبِّ الْفَلَقِ", ur: "صبح کے رب کی پناہ مانگتا ہوں", en: "Refuge in Lord of daybreak", pron: "Bi-Rabbil Falaq" },
          { ar: "مِنْ شَرِّ مَا خَلَقَ", ur: "مخلوق کے شر سے", en: "from evil of creation", pron: "Min Sharri Ma Khalaq" },
          { ar: "وَمِنْ شَرِّ حَاسِدٍ إِذَا حَسَدَ", ur: "اور حاسد کے شر سے", en: "and evil of envier", pron: "Hasidin Iza Hasad" }
        ]
      },
      {
        labelUr: "سورۃ الناس", labelEn: "Surah An-Naas",
        fullUr: "کہو میں لوگوں کے رب، بادشاہ اور معبود کی پناہ مانگتا ہوں وسوسہ ڈالنے والے کے شر سے۔",
        fullEn: "Say, I seek refuge in the Lord, Sovereign, and God of mankind from the evil of the retreating whisperer.",
        words: [
          { ar: "قُلْ أَعُوْذُ بِرَبِّ النَّاسِ مَلِكِ النَّاسِ إِلٰهِ النَّاسِ", ur: "لوگوں کے رب، بادشاہ و معبود کی پناہ", en: "Lord, King & God of mankind", pron: "Rabbin Naas Malikin Naas" },
          { ar: "مِنْ شَرِّ الْوَسْوَاسِ الْخَنَّاسِ", ur: "وسوسہ ڈالنے والے کے شر سے", en: "from retreating whisperer", pron: "Al-Waswasil Khannas" },
          { ar: "مِنَ الْجِنَّةِ وَالنَّاسِ", ur: "جنوں اور انسانوں میں سے", en: "among jinn & mankind", pron: "Minal Jinnati Wan-Naas" }
        ]
      }
    ],
    lughat: [
      { ar: "الصَّمَدُ", ur: "بے نیاز", en: "Eternal Refuge" },
      { ar: "الْفَلَقِ", ur: "صبح", en: "Daybreak" },
      { ar: "الْخَنَّاسِ", ur: "پیچھے ہٹنے والا", en: "Retreating" }
    ]
  },
  {
    id: 14, titleUr: "والدین اور مغفرت کی دعا", titleEn: "Dua for Parents & Forgiveness", keys: "parents rabbir hamhuma maghfirat",
    lines: [
      {
        labelUr: "والدین کی دعا", labelEn: "Parents Dua",
        fullUr: "اے میرے رب! میرے والدین پر رحم فرما جیسا کہ انہوں نے بچپن میں مجھے پالا۔",
        fullEn: "My Lord, have mercy upon them as they brought me up when I was small.",
        words: [
          { ar: "رَبِّ ارْحَمْهُمَا", ur: "اے رب ان دونوں پر رحم فرما", en: "Lord have mercy on them", pron: "Rabbir Hamhuma" },
          { ar: "كَمَا رَبَّيَانِيْ صَغِيْرًا", ur: "جیسا بچپن میں مجھے پالا", en: "as they raised me small", pron: "Kama Rabbayani Sagheera" }
        ]
      },
      {
        labelUr: "مغفرت کی دعا", labelEn: "Forgiveness Dua",
        fullUr: "اے ہمارے رب! مجھے، میرے والدین اور تمام مومنوں کو قیامت کے دن بخش دے۔",
        fullEn: "Our Lord, forgive me, my parents, and the believers on the Day of Account.",
        words: [
          { ar: "رَبَّنَا اغْفِرْ لِيْ وَلِوَالِدَيَّ", ur: "مجھے اور میرے والدین کو بخش دے", en: "Forgive me & my parents", pron: "Rabbana Ghfir Li Wa Liwalidayya" },
          { ar: "وَلِلْمُؤْمِنِيْنَ يَوْمَ يَقُوْمُ الْحِسَابُ", ur: "اور تمام مومنوں کو حساب کے دن", en: "and believers on Judgment Day", pron: "Yauma Yaqoomul Hisab" }
        ]
      }
    ],
    lughat: [
      { ar: "ارْحَمْهُمَا", ur: "ان دونوں پر رحم فرما", en: "Have mercy on both" },
      { ar: "الْحِسَابُ", ur: "حساب (قیامت)", en: "Reckoning" }
    ]
  },
  {
    id: 15, titleUr: "نماز کے بعد مسنون اذکار (ترتیب وار)", titleEn: "Masnoon Azkar After Salah (In Order)", keys: "after namaz astaghfirullah antas salam tasbeeh fatimi",
    lines: [
      {
        labelUr: "ترتیب ۱: استغفار (۳ بار)", labelEn: "Step 1: Istighfar (3x)",
        fullUr: "میں اللہ سے بخشش مانگتا ہوں۔ (سلام پھیرتے ہی ۳ بار — صحیح مسلم: 591)",
        fullEn: "I seek forgiveness from Allah. (3 times right after Salam — Sahih Muslim: 591)",
        words: [
          { ar: "أَسْتَغْفِرُ", ur: "میں بخشش مانگتا ہوں", en: "I seek forgiveness", pron: "Astaghfiru" },
          { ar: "اللّٰهَ", ur: "اللہ سے", en: "from Allah", pron: "Allaha" }
        ]
      },
      {
        labelUr: "ترتیب ۲: سلامتی کی دعا", labelEn: "Step 2: Dua of Peace",
        fullUr: "اے اللہ! تو ہی سلامتی والا ہے اور تجھی سے سلامتی ہے، تو بابرکت ہے اے جلال و بزرگی والے! (صحیح مسلم: 591)",
        fullEn: "O Allah, You are Peace and from You comes peace; Blessed are You, O Possessor of Majesty & Honor. (Muslim: 591)",
        words: [
          { ar: "اَللّٰهُمَّ أَنْتَ السَّلَامُ", ur: "اے اللہ تو سلامتی والا ہے", en: "O Allah You are Peace", pron: "Allahumma Antas-Salam" },
          { ar: "وَمِنْكَ السَّلَامُ", ur: "اور تجھی سے سلامتی ہے", en: "and from You is peace", pron: "Wa Minkas-Salam" },
          { ar: "تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ", ur: "تو بابرکت ہے اے جلال و بزرگی والے", en: "Blessed, Majestic & Honorable", pron: "Ya Zal-Jalali Wal-Ikram" }
        ]
      },
      {
        labelUr: "ترتیب ۳: کلمۂ توحید", labelEn: "Step 3: Declaration of Tawheed",
        fullUr: "اللہ کے سوا کوئی معبود نہیں، وہ اکیلا ہے کوئی شریک نہیں، اسی کی بادشاہی و تعریف ہے اور وہ ہر چیز پر قادر ہے۔ (صحیح مسلم: 593)",
        fullEn: "None has right to be worshipped except Allah alone without partner; His is dominion & praise, Powerful over all things. (Muslim: 593)",
        words: [
          { ar: "لَا إِلٰهَ إِلَّا اللّٰهُ وَحْدَهُ لَا شَرِيْكَ لَهُ", ur: "اللہ کے سوا کوئی معبود نہیں، وہ اکیلا ہے", en: "No deity except Allah alone", pron: "La Ilaha Illallahu Wahdahu" },
          { ar: "لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ", ur: "اسی کی بادشاہی و تعریف ہے", en: "His is dominion & praise", pron: "Lahul Mulku Wa Lahul Hamd" },
          { ar: "وَهُوَ عَلٰى كُلِّ شَيْءٍ قَدِيْرٌ", ur: "اور وہ ہر چیز پر قادر ہے", en: "Powerful over all things", pron: "Ala Kulli Shai'in Qadeer" }
        ]
      },
      {
        labelUr: "ترتیب ۴: ذکر و شکر کی دعا", labelEn: "Step 4: Zikr & Gratitude Dua",
        fullUr: "اے میرے رب! اپنے ذکر، شکر اور بہترین عبادت پر میری مدد فرما۔ (ابو داود: 1522)",
        fullEn: "My Lord, help me to remember You, thank You, and worship You in the best manner. (Abu Dawud: 1522)",
        words: [
          { ar: "رَبِّ أَعِنِّيْ", ur: "اے رب میری مدد فرما", en: "My Lord help me", pron: "Rabbi A'inni" },
          { ar: "عَلٰى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ", ur: "اپنے ذکر، شکر و بہترین عبادت پر", en: "to remember, thank & worship You", pron: "Ala Zikrika Wa Shukrika" }
        ]
      },
      {
        labelUr: "ترتیب ۵: تسبیحِ فاطمی", labelEn: "Step 5: Tasbeeh-e-Fatimi",
        fullUr: "۳۳ بار سبحان اللہ، ۳۳ بار الحمد للہ، ۳۴ بار اللہ اکبر (صحیح مسلم: 597)",
        fullEn: "SubhanAllah 33x, Alhamdulillah 33x, Allahu Akbar 34x (Muslim: 597)",
        words: [
          { ar: "سُبْحَانَ اللّٰهِ", ur: "اللہ پاک ہے (۳۳)", en: "Glory to Allah (33)", pron: "SubhanAllah" },
          { ar: "اَلْحَمْدُ لِلّٰهِ", ur: "تمام تعریف اللہ کے لیے (۳۳)", en: "Praise to Allah (33)", pron: "Alhamdulillah" },
          { ar: "اَللّٰهُ أَكْبَرُ", ur: "اللہ سب سے بڑا ہے (۳۴)", en: "Allah is Greatest (34)", pron: "Allahu Akbar" }
        ]
      }
    ],
    lughat: [
      { ar: "أَسْتَغْفِرُ اللّٰهَ", ur: "میں اللہ سے بخشش مانگتا ہوں", en: "I seek forgiveness from Allah" },
      { ar: "السَّلَامُ", ur: "سلامتی والا", en: "Source of Peace" },
      { ar: "أَعِنِّيْ", ur: "میری مدد فرما", en: "Help me" },
      { ar: "قَدِيْرٌ", ur: "قدرت والا", en: "All-Powerful" }
    ]
  },
  {
    id: 16, titleUr: "صبح و شام کے مسنون اذکار", titleEn: "Morning & Evening Masnoon Azkar", keys: "morning evening asbahna amsaina la yadurru",
    lines: [
      {
        labelUr: "صبح کا ذکر (۱)", labelEn: "Morning Zikr (1)",
        fullUr: "ہم نے اور تمام کائنات نے اللہ کے لیے صبح کی، اور تمام تعریفیں اللہ کے لیے ہیں۔ (صحیح مسلم: 2723)",
        fullEn: "We reached morning and the dominion belongs to Allah; all praise to Allah. (Muslim: 2723)",
        words: [
          { ar: "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلّٰهِ", ur: "ہم نے و بادشاہی نے اللہ کے لیے صبح کی", en: "We & kingdom entered morning for Allah", pron: "Asbahna Wa Asbahal Mulku Lillah" },
          { ar: "وَالْحَمْدُ لِلّٰهِ", ur: "اور تمام تعریف اللہ کے لیے ہے", en: "all praise to Allah", pron: "Wal-Hamdu Lillah" }
        ]
      },
      {
        labelUr: "صبح و شام کی دعا (۲)", labelEn: "Morning & Evening (2)",
        fullUr: "اے اللہ! تیرے حکم سے صبح کی، تیرے حکم سے شام کی، تیرے حکم سے زندہ ہیں و مرتے ہیں اور تیری طرف لوٹنا ہے۔ (ترمذی: 3391)",
        fullEn: "O Allah, by You we enter morning & evening, live & die, and to You is the final return. (Tirmidhi: 3391)",
        words: [
          { ar: "اَللّٰهُمَّ بِكَ أَصْبَحْنَا وَبِكَ أَمْسَيْنَا", ur: "اے اللہ تیرے حکم سے صبح و شام کی", en: "By You we reach morning & evening", pron: "Bika Asbahna Wa Bika Amsaina" },
          { ar: "وَبِكَ نَحْيَا وَبِكَ نَمُوْتُ وَإِلَيْكَ النُّشُوْرُ", ur: "تیرے حکم سے زندہ و مرتے اور تیری طرف لوٹنا ہے", en: "by You we live, die & return", pron: "Wa Ilaikan-Nushoor" }
        ]
      },
      {
        labelUr: "تسبیح و حفاظت (۳)", labelEn: "Tasbeeh & Protection",
        fullUr: "بِسْمِ اللّٰهِ الَّذِيْ لَا يَضُرُّ... (۳ بار — ابو داود: 5088) اور سُبْحَانَ اللّٰهِ وَبِحَمْدِهِ (۱۰۰ بار — مسلم: 2692)",
        fullEn: "In Allah's name with which nothing can harm (3x — Abu Dawud: 5088) & SubhanAllahi Wa Bihamdihi (100x — Muslim: 2692)",
        words: [
          { ar: "سُبْحَانَ اللّٰهِ وَبِحَمْدِهِ", ur: "اللہ پاک ہے اپنی تعریف کے ساتھ", en: "Glory & praise to Allah", pron: "SubhanAllahi Wa Bihamdihi" },
          { ar: "بِسْمِ اللّٰهِ الَّذِيْ لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ", ur: "اللہ کے نام سے جس کے ساتھ کوئی چیز نقصان نہیں دیتی", en: "Nothing harms with His name", pron: "Allazi La Yadurru Ma'asmihi Shai" }
        ]
      }
    ],
    lughat: [
      { ar: "أَصْبَحْنَا", ur: "ہم نے صبح کی", en: "We reached morning" },
      { ar: "أَمْسَيْنَا", ur: "ہم نے شام کی", en: "We reached evening" },
      { ar: "النُّشُوْرُ", ur: "لوٹ کر اٹھنا", en: "Final return" },
      { ar: "لَا يَضُرُّ", ur: "نقصان نہیں پہنچاتا", en: "Cannot harm" }
    ]
  },
  {
    id: 17, titleUr: "نمازِ جنازہ کی مسنون دعائیں", titleEn: "Namaz-e-Janaza Masnoon Duas", keys: "janaza dua hayyina warhamhu afihi zimmatika faratan",
    lines: [
      {
        labelUr: "دعا ۱ (بالغ میت): زندوں و مردوں کی مغفرت", labelEn: "Dua 1 (Adult): Forgiveness for Living & Dead",
        fullUr: "اے اللہ! ہمارے زندوں اور فوت شدگان، حاضر و غائب، چھوٹوں و بڑوں اور مردوں و عورتوں کی مغفرت فرما۔ (ترمذی: 1024 / ابوداود: 3201)",
        fullEn: "O Allah, forgive our living & dead, present & absent, young & old, males & females.",
        words: [
          { ar: "اَللّٰهُمَّ اغْفِرْ لِحَيِّنَا وَمَيِّتِنَا", ur: "ہمارے زندوں و مردوں کو بخش دے", en: "Forgive our living & dead", pron: "Allahummaghfir Li-Hayyina" },
          { ar: "وَشَاهِدِنَا وَغَائِبِنَا وَصَغِيْرِنَا وَكَبِيْرِنَا", ur: "حاضر، غائب، چھوٹوں و بڑوں کو", en: "present, absent, young & old", pron: "Shahidina Wa Gha'ibina" },
          { ar: "وَذَكَرِنَا وَأُنْثَانَا", ur: "مردوں اور عورتوں کو", en: "males & females", pron: "Zakarina Wa Unsana" },
          { ar: "مَنْ أَحْيَيْتَهُ مِنَّا فَأَحْيِهِ عَلَى الْإِسْلَامِ وَمَنْ تَوَفَّيْتَهُ مِنَّا فَتَوَفَّهُ عَلَى الْإِيْمَانِ", ur: "زندوں کو اسلام اور فوت ہونے والوں کو ایمان پر", en: "Keep living on Islam, dying on Iman", pron: "Alal Islam Wal Iman" }
        ]
      },
      {
        labelUr: "دعا ۲ (بالغ میت): بخشش، رحمت و جنت (حصہ ۱)", labelEn: "Dua 2 (Adult): Mercy & Forgiveness (Part 1)",
        fullUr: "اے اللہ! اسے بخش دے، اس پر رحم فرما، اسے عافیت دے اور درگزر فرما، اس کی مہمانی عزت والی کر اور اس کی قبر کشادہ فرما۔ (صحیح مسلم: 963)",
        fullEn: "O Allah, forgive him, have mercy, grant peace & pardon him, honor his reception & widen his grave. (Muslim: 963)",
        words: [
          { ar: "اَللّٰهُمَّ اغْفِرْ لَهُ وَارْحَمْهُ", ur: "اسے بخش دے اور رحم فرما", en: "Forgive & have mercy on him", pron: "Allahummaghfir Lahu Warhamhu" },
          { ar: "وَعَافِهِ وَاعْفُ عَنْهُ", ur: "عافیت دے اور درگزر فرما", en: "grant peace & pardon", pron: "Wa Afihi Wa'fu Anhu" },
          { ar: "وَأَكْرِمْ نُزُلَهُ وَوَسِّعْ مُدْخَلَهُ", ur: "مہمانی عزت والی کر و قبر کشادہ کر", en: "honor reception & widen grave", pron: "Akrim Nuzulahu Wassi Mudkhalahu" }
        ]
      },
      {
        labelUr: "دعا ۲ (بالغ میت): پاکیزگی و جنت (حصہ ۲)", labelEn: "Dua 2 (Adult): Cleansing & Paradise (Part 2)",
        fullUr: "اسے پانی، برف و اولوں سے دھو کر گناہوں سے سفید کپڑے کی طرح صاف فرما، بہتر گھر و ساتھی عطا فرما، جنت میں داخل کر اور عذابِ قبر و جہنم سے بچا۔",
        fullEn: "Cleanse him of sins like white cloth, grant better home & family, admit to Paradise & protect from grave & Fire.",
        words: [
          { ar: "وَاغْسِلْهُ بِالْمَاءِ وَالثَّلْجِ وَالْبَرَدِ وَنَقِّهِ مِنَ الْخَطَايَا", ur: "پانی، برف و اولوں سے دھو کر گناہوں سے پاک کر", en: "Wash with water, snow & cleanse sins", pron: "Bis-Salji Wal-Barad Wa Naqqihi" },
          { ar: "كَمَا نَقَّيْتَ الثَّوْبَ الْأَبْيَضَ مِنَ الدَّنَسِ", ur: "جیسے سفید کپڑا میل سے صاف ہوتا ہے", en: "like white garment from stain", pron: "As-Saubal Abyad Minad-Danas" },
          { ar: "وَأَبْدِلْهُ دَارًا خَيْرًا مِّنْ دَارِهِ وَأَهْلًا وَزَوْجًا خَيْرًا", ur: "بہتر گھر، گھر والے اور ساتھی عطا فرما", en: "grant better home, family & spouse", pron: "Daran Khairan Min Darihi" },
          { ar: "وَأَدْخِلْهُ الْجَنَّةَ وَأَعِذْهُ مِنْ عَذَابِ الْقَبْرِ وَالنَّارِ", ur: "جنت میں داخل کر اور قبر و آگ سے بچا", en: "admit to Paradise & protect from grave/Fire", pron: "Adkhilhul Jannah Wa A'izhu" }
        ]
      },
      {
        labelUr: "دعا ۳ (بالغ میت): اللہ کی امان و حفاظت", labelEn: "Dua 3 (Adult): Allah's Protection & Refuge",
        fullUr: "اے اللہ! فلاں بن فلاں تیری پناہ و امان میں ہے، اسے قبر کے فتنے و آگ کے عذاب سے بچا اور بخش کر رحم فرما۔ (ابوداود: 3202)",
        fullEn: "O Allah, [name] is in Your protection; protect from trial of grave & Fire, forgive & have mercy. (Abu Dawud: 3202)",
        words: [
          { ar: "اَللّٰهُمَّ إِنَّ فُلَانًا فِيْ ذِمَّتِكَ وَحَبْلِ جِوَارِكَ", ur: "فلاں تیری پناہ و امان میں ہے", en: "Under Your protection & covenant", pron: "Fi Zimmatika Wa Habli Jiwarik" },
          { ar: "فَقِهِ مِنْ فِتْنَةِ الْقَبْرِ وَعَذَابِ النَّارِ", ur: "قبر کے فتنے و آگ سے بچا", en: "Protect from grave & fire", pron: "Min Fitnatil Qabr Wan-Nar" },
          { ar: "فَاغْفِرْ لَهُ وَارْحَمْهُ إِنَّكَ أَنْتَ الْغَفُوْرُ الرَّحِيْمُ", ur: "بخش کر رحم فرما تو بڑا بخشنے والا ہے", en: "Forgive & have mercy on him", pron: "Faghfir Lahu Warhamhu" }
        ]
      },
      {
        labelUr: "دعا ۴: نابالغ بچے کی مسنون دعا", labelEn: "Dua 4: Masnoon Dua for Young Child",
        fullUr: "اے اللہ! اس بچے کو ہمارے لیے پیش رو، اجر و ذخیرۂ آخرت، اور مقبول سفارشی بنا دے۔ (بچی کے لیے اجْعَلْهَا اور شَافِعَةً وَّمُشَفَّعَةً پڑھیں)",
        fullEn: "O Allah, make this child our forerunner, stored treasure, and accepted intercessor.",
        words: [
          { ar: "اَللّٰهُمَّ اجْعَلْهُ لَنَا فَرَطًا وَّسَلَفًا وَّأَجْرًا وَّذُخْرًا", ur: "اسے ہمارے لیے پیش رو، اجر اور ذخیرہ بنا", en: "Make him forerunner, reward & treasure", pron: "Allahummaj'alhu Lana Faratan" },
          { ar: "وَّاجْعَلْهُ لَنَا شَافِعًا وَّمُشَفَّعًا", ur: "اور مقبول سفارشی بنا (بچی کیلئے هَا/شَافِعَةً)", en: "and accepted intercessor", pron: "Shafi'an Wa Mushaffa'a" }
        ]
      }
    ],
    lughat: [
      { ar: "لِحَيِّنَا وَمَيِّتِنَا", ur: "ہمارے زندوں و مردوں کو", en: "For our living & dead" },
      { ar: "عَافِهِ وَاعْفُ عَنْهُ", ur: "عافیت دے اور درگزر فرما", en: "Grant peace & pardon him" },
      { ar: "نُزُلَهُ", ur: "اس کی مہمانی", en: "His reception" },
      { ar: "ذِمَّتِكَ", ur: "تیری پناہ و امان", en: "Your protection" },
      { ar: "فَرَطًا", ur: "پیش رو", en: "Forerunner" },
      { ar: "ذُخْرًا", ur: "ذخیرۂ آخرت", en: "Stored treasure" }
    ]
  }
];

/* ==========================================================================
   Azkar, Selected Ahadees, After-Salah, Morning/Evening & Janaza Data
   ========================================================================== */
const AZKAR = {
  asma: [
    { ar: "اَلرَّحْمٰنُ", ur: "الرحمن", en: "Ar-Rahman", mUr: "بے حد رحم کرنے والا", mEn: "The Exceedingly Compassionate" },
    { ar: "اَلرَّحِيْمُ", ur: "الرحیم", en: "Ar-Raheem", mUr: "نہایت مہربان", mEn: "The Most Merciful" },
    { ar: "اَلْمَلِكُ", ur: "الملک", en: "Al-Malik", mUr: "بادشاہ، حقیقی مالک", mEn: "The Sovereign King" },
    { ar: "اَلْقُدُّوْسُ", ur: "القدوس", en: "Al-Quddus", mUr: "انتہائی پاک اور بے عیب", mEn: "The Most Sacred & Pure" },
    { ar: "اَلسَّلَامُ", ur: "السلام", en: "As-Salam", mUr: "سلامتی دینے والا", mEn: "The Source of Peace" },
    { ar: "اَلْمُؤْمِنُ", ur: "المؤمن", en: "Al-Mu'min", mUr: "امن عطا کرنے والا", mEn: "Granter of Security" },
    { ar: "اَلْعَزِيْزُ", ur: "العزیز", en: "Al-Aziz", mUr: "سب پر غالب، عزت والا", mEn: "The Almighty" },
    { ar: "اَلْغَفَّارُ", ur: "الغفار", en: "Al-Ghaffar", mUr: "بار بار بخشنے والا", mEn: "Repeatedly Forgiving" },
    { ar: "اَلرَّزَّاقُ", ur: "الرزاق", en: "Ar-Razzaq", mUr: "رزق دینے والا", mEn: "Constant Provider" },
    { ar: "اَلْحَيُّ الْقَيُّوْمُ", ur: "الحی القیوم", en: "Al-Hayy Al-Qayyum", mUr: "ہمیشہ زندہ اور سب کو قائم رکھنے والا", mEn: "Ever-Living, Self-Subsisting" }
  ],
  hadith: [
    { ar: "إِنَّمَا الْأَعْمَالُ بِالنِّيَّاتِ", ur: "اعمال کا دارومدار نیتوں پر ہے۔", en: "Actions are judged according to intentions.", refUr: "(حوالہ: صحیح بخاری و مسلم)", refEn: "(Ref: Sahih al-Bukhari & Muslim)" },
    { ar: "خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ", ur: "تم میں سے بہترین وہ ہے جو قرآن سیکھے اور سکھائے۔", en: "The best among you is the one who learns the Quran and teaches it.", refUr: "(حوالہ: صحیح بخاری: 5027)", refEn: "(Ref: Sahih al-Bukhari: 5027)" },
    { ar: "اَلدِّيْنُ النَّصِيْحَةُ", ur: "دین خیر خواہی اور بھلائی کا نام ہے۔", en: "Religion is sincere good counsel.", refUr: "(حوالہ: صحیح مسلم: 55)", refEn: "(Ref: Sahih Muslim: 55)" },
    { ar: "اَلطُّهُوْرُ شَطْرُ الْإِيْمَانِ", ur: "پاکیزگی ایمان کا نصف حصہ ہے۔", en: "Cleanliness and purity is half of faith.", refUr: "(حوالہ: صحیح مسلم: 223)", refEn: "(Ref: Sahih Muslim: 223)" },
    { ar: "تَبَسُّمُكَ فِيْ وَجْهِ أَخِيْكَ لَكَ صَدَقَةٌ", ur: "اپنے بھائی کے سامنے مسکرانا بھی صدقہ ہے۔", en: "Smiling in the face of your brother is charity.", refUr: "(حوالہ: جامع ترمذی: 1956)", refEn: "(Ref: Jami at-Tirmidhi: 1956)" },
    { ar: "مَنْ لَّا يَرْحَمُ لَا يُرْحَمُ", ur: "جو مخلوق پر رحم نہیں کرتا، اس پر رحم نہیں کیا جاتا۔", en: "Whoever does not show mercy will not be shown mercy.", refUr: "(حوالہ: صحیح بخاری: 5997)", refEn: "(Ref: Sahih al-Bukhari: 5997)" }
  ],
  salah: [
    { step: 1, ar: "أَسْتَغْفِرُ اللّٰهَ", repUr: "۳ بار (سلام پھیرتے ہی)", repEn: "3 times (Immediately after Salam)", ur: "میں اللہ سے بخشش مانگتا ہوں۔", en: "I seek forgiveness from Allah.", ref: "صحیح مسلم: 591" },
    { step: 2, ar: "اَللّٰهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ، تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ", repUr: "۱ بار", repEn: "1 time", ur: "اے اللہ! تو ہی سلامتی والا ہے اور تجھی سے سلامتی ہے، تو بابرکت ہے اے جلال اور بزرگی والے!", en: "O Allah, You are Peace and from You is peace; Blessed are You, O Possessor of Majesty & Honor.", ref: "صحیح مسلم: 591" },
    { step: 3, ar: "لَا إِلٰهَ إِلَّا اللّٰهُ وَحْدَهُ لَا شَرِيْكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلٰى كُلِّ شَيْءٍ قَدِيْرٌ", repUr: "۱ بار", repEn: "1 time", ur: "اللہ کے سوا کوئی معبود نہیں، وہ اکیلا ہے کوئی شریک نہیں، اسی کی بادشاہی و تعریف ہے اور وہ ہر چیز پر قادر ہے۔", en: "None worthy except Allah alone; His is dominion & praise, Powerful over all things.", ref: "صحیح مسلم: 593" },
    { step: 4, ar: "رَبِّ أَعِنِّيْ عَلٰى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ", repUr: "۱ بار", repEn: "1 time", ur: "اے میرے رب! اپنے ذکر، شکر اور بہترین عبادت پر میری مدد فرما۔", en: "My Lord, help me remember You, thank You, and worship You well.", ref: "سنن ابو داود: 1522" },
    { step: 5, ar: "سُبْحَانَ اللّٰهِ (33) • اَلْحَمْدُ لِلّٰهِ (33) • اَللّٰهُ أَكْبَرُ (34)", repUr: "تسبیحِ فاطمی (کل ۱۰۰ بار)", repEn: "Tasbeeh-e-Fatimi (100 total)", ur: "۳۳ بار سبحان اللہ، ۳۳ بار الحمد للہ، ۳۴ بار اللہ اکبر پڑھنا مسنون ہے۔", en: "33x SubhanAllah, 33x Alhamdulillah, 34x Allahu Akbar.", ref: "صحیح مسلم: 597" },
    { step: 6, ar: "اَللّٰهُ لَا إِلٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّوْمُ...", repUr: "آیۃ الکرسی + تین قل (ہر فرض نماز کے بعد)", repEn: "Ayat-ul-Kursi & Quls (1x after Fard)", ur: "ہر فرض نماز کے بعد آیۃ الکرسی اور تین قل پڑھنا مسنون ہے۔", en: "Recite Ayat-ul-Kursi and the Three Quls after every Fard prayer.", ref: "نسائی الکبریٰ: 9928" }
  ],
  mornEve: [
    { step: 1, ar: "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلّٰهِ، وَالْحَمْدُ لِلّٰهِ، لَا إِلٰهَ إِلَّا اللّٰهُ وَحْدَهُ لَا شَرِيْكَ لَهُ", repUr: "صبح ۱ بار (شام کو أَمْسَيْنَا)", repEn: "1x morning (Amsaina evening)", ur: "ہم نے اور تمام کائنات نے اللہ کے لیے صبح کی، تمام تعریفیں اللہ کے لیے ہیں۔", en: "We entered morning and the dominion belongs to Allah; all praise to Allah.", ref: "صحیح مسلم: 2723" },
    { step: 2, ar: "اَللّٰهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوْتُ وَإِلَيْكَ النُّشُوْرُ", repUr: "صبح و شام ۱ بار", repEn: "1x morning & evening", ur: "اے اللہ! تیرے ہی حکم سے صبح و شام کی، زندہ ہیں و مرتے ہیں اور تیری طرف لوٹنا ہے۔", en: "O Allah, by You we enter morning & evening, live & die, and to You is the final return.", ref: "جامع ترمذی: 3391" },
    { step: 3, ar: "سُبْحَانَ اللّٰهِ وَبِحَمْدِهِ", repUr: "صبح و شام ۱۰۰ بار", repEn: "100x morning & evening", ur: "اللہ پاک ہے اور اپنی تعریف کے ساتھ۔", en: "Glory be to Allah and praise to Him.", ref: "صحیح مسلم: 2692" },
    { step: 4, ar: "بِسْمِ اللّٰهِ الَّذِيْ لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيْعُ الْعَلِيْمُ", repUr: "صبح و شام ۳ بار", repEn: "3x morning & evening", ur: "اس اللہ کے نام سے جس کے نام کے ساتھ زمین و آسمان کی کوئی چیز نقصان نہیں پہنچاتی۔", en: "In the name of Allah, with whose name nothing on earth or heaven can harm.", ref: "سنن ابو داود: 5088" },
    { step: 5, ar: "رَضِيْتُ بِاللّٰهِ رَبًّا، وَبِالْإِسْلَامِ دِيْنًا، وَبِمُحَمَّدٍ ﷺ نَبِيًّا", repUr: "صبح و شام ۳ بار", repEn: "3x morning & evening", ur: "میں اللہ کے رب، اسلام کے دین اور محمد ﷺ کے نبی ہونے پر راضی ہوں۔", en: "I am pleased with Allah as Lord, Islam as religion, and Muhammad (PBUH) as Prophet.", ref: "سنن ابو داود: 5072" }
  ],
  janaza: [
    { step: 1, ar: "اَللّٰهُمَّ اغْفِرْ لِحَيِّنَا وَمَيِّتِنَا وَشَاهِدِنَا وَغَائِبِنَا وَصَغِيْرِنَا وَكَبِيْرِنَا وَذَكَرِنَا وَأُنْثَانَا، اَللّٰهُمَّ مَنْ أَحْيَيْتَهُ مِنَّا فَأَحْيِهِ عَلَى الْإِسْلَامِ، وَمَنْ تَوَفَّيْتَهُ مِنَّا فَتَوَفَّهُ عَلَى الْإِيْمَانِ", repUr: "دعا ۱: بالغ میت کے لیے جامع مسنون دعا", repEn: "Dua 1: Comprehensive Adult Dua", ur: "اے اللہ! ہمارے زندوں، مردوں، حاضر، غائب، چھوٹوں، بڑوں، مردوں و عورتوں کو بخش دے۔ جسے زندہ رکھے اسلام پر رکھ اور جسے وفات دے ایمان پر دے۔", en: "Forgive our living & dead, present & absent, young & old, male & female; keep living on Islam & dying on Iman.", ref: "ترمذی: 1024 / ابوداود: 3201" },
    { step: 2, ar: "اَللّٰهُمَّ اغْفِرْ لَهُ وَارْحَمْهُ وَعَافِهِ وَاعْفُ عَنْهُ، وَأَكْرِمْ نُزُلَهُ، وَوَسِّعْ مُدْخَلَهُ، وَاغْسِلْهُ بِالْمَاءِ وَالثَّلْجِ وَالْبَرَدِ، وَنَقِّهِ مِنَ الْخَطَايَا كَمَا نَقَّيْتَ الثَّوْبَ الْأَبْيَضَ مِنَ الدَّنَسِ، وَأَبْدِلْهُ دَارًا خَيْرًا مِّنْ دَارِهِ، وَأَهْلًا خَيْرًا مِّنْ أَهْلِهِ، وَزَوْجًا خَيْرًا مِّنْ زَوْجِهِ، وَأَدْخِلْهُ الْجَنَّةَ وَأَعِذْهُ مِنْ عَذَابِ الْقَبْرِ وَمِنْ عَذَابِ النَّارِ", repUr: "دعا ۲: میت کے لیے بخشش و رحمت کی بڑی دعا", repEn: "Dua 2: Great Dua for Forgiveness & Mercy", ur: "اے اللہ! اسے بخش دے، اس پر رحم فرما، عافیت دے اور درگزر فرما، عزت والی مہمانی کر، قبر کشادہ کر، گناہوں سے سفید کپڑے کی طرح صاف کر، بہتر گھر و ساتھی عطا فرما اور جنت میں داخل فرما۔", en: "Forgive him, have mercy, grant peace & pardon him, honor his reception, widen his grave, cleanse him of sins, admit him to Paradise & protect from grave and Fire.", ref: "صحیح مسلم: 963" },
    { step: 3, ar: "اَللّٰهُمَّ إِنَّ فُلَانَ بْنَ فُلَانٍ فِيْ ذِمَّتِكَ، وَحَبْلِ جِوَارِكَ، فَقِهِ مِنْ فِتْنَةِ الْقَبْرِ وَعَذَابِ النَّارِ، وَأَنْتَ أَهْلُ الْوَفَاءِ وَالْحَقِّ، فَاغْفِرْ لَهُ وَارْحَمْهُ، إِنَّكَ أَنْتَ الْغَفُوْرُ الرَّحِيْمُ", repUr: "دعا ۳: میت کی امان و حفاظت کی دعا", repEn: "Dua 3: Dua in Allah's Protection", ur: "اے اللہ! فلاں بن فلاں تیری پناہ و امان میں ہے، اسے قبر کے فتنے اور آگ کے عذاب سے بچا، بخش دے اور رحم فرما۔", en: "[Name] is in Your protection; protect from trial of grave & Fire, forgive & have mercy.", ref: "سنن ابو داود: 3202" },
    { step: 4, ar: "اَللّٰهُمَّ اجْعَلْهُ لَنَا فَرَطًا، وَّاجْعَلْهُ لَنَا سَلَفًا وَّأَجْرًا وَّذُخْرًا، وَّاجْعَلْهُ لَنَا شَافِعًا وَّمُشَفَّعًا", repUr: "دعا ۴: نابالغ بچے کی مسنون دعا", repEn: "Dua 4: Young Child Dua", ur: "اے اللہ! اس بچے کو ہمارے لیے پیش رو، اجر و ذخیرۂ آخرت اور مقبول سفارشی بنا دے۔ (بچی کے لیے اجْعَلْهَا اور شَافِعَةً وَّمُشَفَّعَةً)", en: "Make him a forerunner, advance reward & stored treasure, and accepted intercessor.", ref: "صحیح بخاری / سنن البیہقی" }
  ]
};

/* ==========================================================================
   Persistent State & History Navigation Stack
   ========================================================================== */
const DEFAULT_STATE = {
  lang: "ur",
  dark: false,
  big: false,
  soundFx: true,
  tab: "home",
  lessonId: 1,
  done: [],
  bookmarks: [],
  scores: {},
  tasbeeh: 0,
  hideTr: false,
  memo: false,
  memoIdx: 0,
  homeFilter: "all",
  search: "",
  azkarIdx: { asma: 0, hadith: 0, salah: 0, mornEve: 0, janaza: 0 },
  appNameUr: "نور کاشف",
  appNameEn: "Noor Kashif",
  schoolUr: "ترجمانِ نماز • حافظ کاشف منیر بدر",
  schoolEn: "Tarjuman-e-Namaz • Noor Kashif",
  customLessons: {}
};

function loadState() {
  try {
    const raw = safeStorageGet(STORE_KEY);
    if (!raw) return JSON.parse(JSON.stringify(DEFAULT_STATE));
    const parsed = JSON.parse(raw);
    return {
      ...DEFAULT_STATE,
      ...parsed,
      azkarIdx: { ...DEFAULT_STATE.azkarIdx, ...(parsed.azkarIdx || {}) },
      done: Array.isArray(parsed.done) ? parsed.done : [],
      bookmarks: Array.isArray(parsed.bookmarks) ? parsed.bookmarks : [],
      scores: parsed.scores && typeof parsed.scores === "object" ? parsed.scores : {},
      customLessons: parsed.customLessons && typeof parsed.customLessons === "object" ? parsed.customLessons : {}
    };
  } catch (_) {
    return JSON.parse(JSON.stringify(DEFAULT_STATE));
  }
}

let state = loadState();
if (state.tab === "editor") state.tab = "home";

let activeModal = null; // null | "quickQuiz" | "globalSearch"
let globalSearchState = { query: "", category: "all" };
let quizState = { lessonId: 1, questions: [], idx: 0, score: 0, picked: null, finished: false };
let quickQuizState = { questions: [], idx: 0, score: 0, picked: null, finished: false };
let audioCtx = null;
let toastTimer = null;
let lastBackExitTap = 0;

function saveState() {
  try {
    safeStorageSet(STORE_KEY, JSON.stringify(state));
  } catch (_) {}
}

function isEn() {
  return state.lang === "en";
}

function allLessons() {
  const merged = LESSONS.map((l) => state.customLessons[l.id] || l);
  Object.values(state.customLessons).forEach((cl) => {
    if (!LESSONS.some((x) => x.id === cl.id)) merged.push(cl);
  });
  return merged.sort((a, b) => a.id - b.id);
}

function getLessonById(id) {
  const list = allLessons();
  return list.find((x) => x.id === id) || list[0];
}

/* ==========================================================================
   Offline Web Audio & Safe Speech Synthesis
   ========================================================================== */
function playTone(kind) {
  if (!state.soundFx) return;
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return;
    if (!audioCtx) audioCtx = new Ctx();
    if (audioCtx.state === "suspended") audioCtx.resume();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    const now = audioCtx.currentTime;

    if (kind === "correct") {
      osc.type = "sine";
      osc.frequency.setValueAtTime(523.25, now);
      osc.frequency.setValueAtTime(659.25, now + 0.08);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
      osc.start(now);
      osc.stop(now + 0.22);
    } else if (kind === "wrong") {
      osc.type = "triangle";
      osc.frequency.setValueAtTime(220, now);
      osc.frequency.setValueAtTime(180, now + 0.09);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
      osc.start(now);
      osc.stop(now + 0.22);
    } else {
      osc.type = "sine";
      osc.frequency.setValueAtTime(kind === "tasbeeh" ? 587.33 : 440, now);
      gain.gain.setValueAtTime(0.045, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
      osc.start(now);
      osc.stop(now + 0.09);
    }
  } catch (_) {}
}

function speakAr(text) {
  playTone("tap");
  try {
    if ("speechSynthesis" in window && typeof SpeechSynthesisUtterance !== "undefined") {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = "ar-SA";
      u.rate = 0.85;
      u.onerror = function () {
        showToast(isEn() ? "Follow pronunciation guide (offline voice unavailable)" : "تلفظ دیکھ کر پڑھیں (اس ڈیوائس پر عربی آواز دستیاب نہیں)");
      };
      window.speechSynthesis.speak(u);
      return;
    }
  } catch (_) {}
  showToast(isEn() ? "Follow pronunciation guide (offline WebView)" : "تلفظ دیکھ کر پڑھیں");
}

function showToast(msg) {
  const el = document.getElementById("toastBanner");
  if (!el) return;
  el.textContent = msg;
  el.classList.remove("hidden");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    el.classList.add("hidden");
  }, 2400);
}

/* ==========================================================================
   Splash Screen & Android Hardware Back Stack
   ========================================================================== */
function hideSplashScreen() {
  const splash = document.getElementById("splashScreen");
  if (splash) splash.classList.add("splash-hide");
  try {
    if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.SplashScreen) {
      window.Capacitor.Plugins.SplashScreen.hide();
    }
  } catch (_) {}
}

function pushNavHistory() {
  try {
    window.history.pushState({ tab: state.tab, lessonId: state.lessonId, modal: activeModal }, "");
  } catch (_) {}
}

function handleHardwareBack() {
  if (activeModal) {
    closeModal(true);
    return true;
  }
  if (state.tab !== "home") {
    state.tab = "home";
    saveState();
    render();
    window.scrollTo(0, 0);
    return true;
  }
  const now = Date.now();
  if (now - lastBackExitTap < 2000) {
    return false;
  }
  lastBackExitTap = now;
  showToast(isEn() ? "Press Back again to exit" : "باہر نکلنے کے لیے دوبارہ بیک دبائیں");
  pushNavHistory();
  return true;
}

window.addEventListener("popstate", () => {
  handleHardwareBack();
});

try {
  if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App) {
    window.Capacitor.Plugins.App.addListener("backButton", () => {
      const handled = handleHardwareBack();
      if (!handled) {
        window.Capacitor.Plugins.App.exitApp();
      }
    });
  }
} catch (_) {}

/* ==========================================================================
   Hidden Admin Unlock (5 Quick Taps + PIN 7860)
   ========================================================================== */
let adminTapCount = 0;
let adminTapTimer = null;

function setupHiddenAdminTrigger() {
  const el = document.getElementById("brandTapArea");
  if (!el) return;
  el.addEventListener("click", () => {
    adminTapCount++;
    clearTimeout(adminTapTimer);
    adminTapTimer = setTimeout(() => { adminTapCount = 0; }, 2000);
    if (adminTapCount >= 5) {
      adminTapCount = 0;
      const pass = prompt(isEn() ? "Enter Admin Password:" : "ایڈمن پاسورڈ درج کریں:");
      if (pass === "7860") {
        switchTab("editor");
      } else if (pass !== null) {
        alert(isEn() ? "Wrong password! Admin access only." : "غلط پاسورڈ! صرف ایڈمن کو اجازت ہے۔");
      }
    }
  });
}

/* ==========================================================================
   Global Search Engine (Lessons, Duas & Ahadees)
   ========================================================================== */
function normalizeArabic(str) {
  return String(str || "")
    .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g, "")
    .replace(/[أإآٱ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه")
    .toLowerCase()
    .trim();
}

function matchesQuery(candidate, qRaw, qNorm, qLower) {
  if (!candidate) return false;
  const s = String(candidate);
  if (s.includes(qRaw) || s.toLowerCase().includes(qLower)) return true;
  return qNorm.length > 0 && normalizeArabic(s).includes(qNorm);
}

function runGlobalSearch(query, category) {
  const qRaw = String(query || "").trim();
  if (!qRaw) return [];
  const qNorm = normalizeArabic(qRaw);
  const qLower = qRaw.toLowerCase();

  const lessonMatches = [];
  if (category === "all" || category === "lesson") {
    allLessons().forEach((l) => {
      const metaHit = matchesQuery(l.titleUr, qRaw, qNorm, qLower) ||
        matchesQuery(l.titleEn, qRaw, qNorm, qLower) ||
        matchesQuery(l.keys, qRaw, qNorm, qLower);
      if (metaHit) {
        lessonMatches.push({
          id: "lesson_" + l.id,
          cat: "lesson",
          titleUr: "سبق " + l.id + ": " + l.titleUr,
          titleEn: "Lesson " + l.id + ": " + l.titleEn,
          ar: l.lines[0].words.slice(0, 4).map((w) => w.ar).join(" "),
          trUr: l.lines[0].fullUr,
          trEn: l.lines[0].fullEn,
          subUr: "مکمل سبق",
          subEn: "Full Lesson",
          lessonId: l.id
        });
      }
      const seenWords = new Set();
      l.lines.forEach((ln) => {
        ln.words.forEach((w) => {
          const hit = matchesQuery(w.ar, qRaw, qNorm, qLower) ||
            matchesQuery(w.ur, qRaw, qNorm, qLower) ||
            matchesQuery(w.en, qRaw, qNorm, qLower) ||
            matchesQuery(w.pron, qRaw, qNorm, qLower);
          if (hit && !seenWords.has(w.ar)) {
            seenWords.add(w.ar);
            lessonMatches.push({
              id: "word_" + l.id + "_" + w.ar,
              cat: "lesson",
              titleUr: "سبق " + l.id + ": " + l.titleUr,
              titleEn: "Lesson " + l.id + ": " + l.titleEn,
              ar: w.ar,
              trUr: w.ur,
              trEn: w.en,
              subUr: w.pron || "",
              subEn: w.pron || "",
              lessonId: l.id
            });
          }
        });
      });
    });
  }

  const duaMatches = [];
  if (category === "all" || category === "dua") {
    const scanAzkar = (arr, key, titleUr, titleEn, kws) => {
      const secHit = matchesQuery(kws, qRaw, qNorm, qLower);
      arr.forEach((item, idx) => {
        const hit = secHit ||
          matchesQuery(item.ar, qRaw, qNorm, qLower) ||
          matchesQuery(item.ur, qRaw, qNorm, qLower) ||
          matchesQuery(item.en, qRaw, qNorm, qLower) ||
          matchesQuery(item.ref, qRaw, qNorm, qLower);
        if (hit) {
          duaMatches.push({
            id: "dua_" + key + "_" + idx,
            cat: "dua",
            titleUr: titleUr + " (#" + (idx + 1) + ")",
            titleEn: titleEn + " (#" + (idx + 1) + ")",
            ar: item.ar,
            trUr: item.ur,
            trEn: item.en,
            subUr: item.repUr + " • " + item.ref,
            subEn: item.repEn + " • " + item.ref,
            azkarKey: key,
            azkarIndex: idx
          });
        }
      });
    };
    scanAzkar(AZKAR.salah, "salah", "بعد نماز دعا", "After Salah Dua", "salah after namaz istighfar kursi tasbeeh بعد نماز استغفار دعا");
    scanAzkar(AZKAR.mornEve, "mornEve", "صبح و شام کی دعا", "Morning & Evening Dua", "morning evening subah shaam صبح شام دعا");
    scanAzkar(AZKAR.janaza, "janaza", "نمازِ جنازہ کی دعا", "Janaza Dua", "janaza funeral child میت جنازہ دعا");
    AZKAR.asma.forEach((a, idx) => {
      if (matchesQuery("asma allah names اسماء الحسنی", qRaw, qNorm, qLower) || matchesQuery(a.ar, qRaw, qNorm, qLower) || matchesQuery(a.ur, qRaw, qNorm, qLower) || matchesQuery(a.en, qRaw, qNorm, qLower) || matchesQuery(a.mUr, qRaw, qNorm, qLower) || matchesQuery(a.mEn, qRaw, qNorm, qLower)) {
        duaMatches.push({
          id: "asma_" + idx,
          cat: "dua",
          titleUr: "اسماء الحسنیٰ: " + a.ur,
          titleEn: "Asma-ul-Husna: " + a.en,
          ar: a.ar,
          trUr: a.mUr,
          trEn: a.mEn,
          subUr: "اللہ تعالیٰ کا صفاتی نام",
          subEn: "Name of Allah",
          azkarKey: "asma",
          azkarIndex: idx
        });
      }
    });
  }

  const hadithMatches = [];
  if (category === "all" || category === "hadith") {
    const hSecHit = matchesQuery("hadith hadees ahadees حدیث احادیث", qRaw, qNorm, qLower);
    AZKAR.hadith.forEach((h, idx) => {
      const hit = hSecHit ||
        matchesQuery(h.ar, qRaw, qNorm, qLower) ||
        matchesQuery(h.ur, qRaw, qNorm, qLower) ||
        matchesQuery(h.en, qRaw, qNorm, qLower) ||
        matchesQuery(h.refUr, qRaw, qNorm, qLower) ||
        matchesQuery(h.refEn, qRaw, qNorm, qLower);
      if (hit) {
        hadithMatches.push({
          id: "hadith_" + idx,
          cat: "hadith",
          titleUr: "حدیثِ نبوی ﷺ #" + (idx + 1),
          titleEn: "Hadith #" + (idx + 1),
          ar: h.ar,
          trUr: h.ur,
          trEn: h.en,
          subUr: h.refUr,
          subEn: h.refEn,
          azkarKey: "hadith",
          azkarIndex: idx
        });
      }
    });
  }

  if (category === "lesson") return lessonMatches.slice(0, 20);
  if (category === "dua") return duaMatches.slice(0, 20);
  if (category === "hadith") return hadithMatches.slice(0, 20);
  return [...lessonMatches.slice(0, 8), ...duaMatches.slice(0, 8), ...hadithMatches.slice(0, 6)];
}

/* ==========================================================================
   Quiz Builders (170-MCQ Bank + 5-Question Quick Quiz)
   ========================================================================== */
function build10Quiz(lesson) {
  const all = allLessons();
  const poolMeanings = [...new Set(all.flatMap((l) => [
    ...l.lughat.map((g) => (isEn() ? g.en : g.ur)),
    ...l.lines.flatMap((ln) => ln.words.map((w) => (isEn() ? w.en : w.ur)))
  ]).filter(Boolean))];
  const poolLines = [...new Set(all.flatMap((l) => l.lines.map((ln) => (isEn() ? ln.fullEn : ln.fullUr))).filter(Boolean))];
  const qs = [];
  const used = new Set();

  const cands = [
    ...lesson.lughat.map((g) => ({ ar: g.ar, m: isEn() ? g.en : g.ur })),
    ...lesson.lines.flatMap((ln) => ln.words.map((w) => ({ ar: w.ar, m: isEn() ? w.en : w.ur })))
  ];
  for (const c of cands) {
    if (qs.length >= 7) break;
    if (used.has(c.ar)) continue;
    used.add(c.ar);
    const dist = poolMeanings.filter((x) => x !== c.m).sort(() => Math.random() - 0.5).slice(0, 3);
    if (dist.length < 3) continue;
    const opts = [c.m, ...dist].sort(() => Math.random() - 0.5);
    qs.push({
      lessonId: lesson.id,
      lessonTitle: isEn() ? lesson.titleEn : lesson.titleUr,
      q: isEn() ? `Meaning of "${c.ar}"?` : `"${c.ar}" کا اردو مطلب کیا ہے؟`,
      ar: c.ar,
      opts,
      ans: opts.indexOf(c.m)
    });
  }
  for (const ln of lesson.lines) {
    if (qs.length >= 10) break;
    const target = isEn() ? ln.fullEn : ln.fullUr;
    const dist = poolLines.filter((x) => x !== target).sort(() => Math.random() - 0.5).slice(0, 3);
    if (dist.length < 3) continue;
    const opts = [target, ...dist].sort(() => Math.random() - 0.5);
    qs.push({
      lessonId: lesson.id,
      lessonTitle: isEn() ? lesson.titleEn : lesson.titleUr,
      q: isEn() ? "Choose correct translation:" : "اس عبارت کا درست ترجمہ منتخب کریں:",
      ar: ln.words.map((w) => w.ar).join(" "),
      opts,
      ans: opts.indexOf(target)
    });
  }
  while (qs.length < 10 && cands.length > 0) {
    const c = cands[qs.length % cands.length];
    const dist = poolMeanings.filter((x) => x !== c.m).sort(() => Math.random() - 0.5).slice(0, 3);
    const opts = [c.m, ...dist].sort(() => Math.random() - 0.5);
    qs.push({
      lessonId: lesson.id,
      lessonTitle: isEn() ? lesson.titleEn : lesson.titleUr,
      q: isEn() ? `Select meaning for "${c.ar}":` : `"${c.ar}" کا درست مفہوم:`,
      ar: c.ar,
      opts,
      ans: opts.indexOf(c.m)
    });
  }
  return qs.slice(0, 10);
}

function initQuiz(id) {
  const lesson = getLessonById(id);
  quizState = { lessonId: lesson.id, questions: build10Quiz(lesson), idx: 0, score: 0, picked: null, finished: false };
}

function startQuickQuiz() {
  const bank = allLessons().flatMap((l) => build10Quiz(l));
  const picked5 = bank.sort(() => Math.random() - 0.5).slice(0, 5);
  quickQuizState = { questions: picked5, idx: 0, score: 0, picked: null, finished: false };
  activeModal = "quickQuiz";
  pushNavHistory();
  renderModal();
}

function openGlobalSearch(initialQuery = "") {
  globalSearchState = { query: initialQuery || state.search || "", category: "all" };
  activeModal = "globalSearch";
  pushNavHistory();
  renderModal();
}

function closeModal(fromPopState = false) {
  activeModal = null;
  const root = document.getElementById("modalRoot");
  if (root) {
    root.classList.add("hidden");
    root.innerHTML = "";
  }
  if (!fromPopState && window.history.state && window.history.state.modal) {
    try { window.history.replaceState({ tab: state.tab, lessonId: state.lessonId, modal: null }, ""); } catch (_) {}
  }
}

/* ==========================================================================
   User Actions
   ========================================================================== */
function toggleLang() {
  state.lang = isEn() ? "ur" : "en";
  saveState();
  initQuiz(quizState.lessonId);
  render();
  if (activeModal) renderModal();
  showToast(isEn() ? "Switched to English" : "زبان اردو منتخب ہو گئی");
}

function toggleDark() {
  state.dark = !state.dark;
  saveState();
  render();
}

function toggleBigFont() {
  state.big = !state.big;
  saveState();
  render();
}

function toggleSoundFx() {
  state.soundFx = !state.soundFx;
  saveState();
  playTone("tap");
  render();
}

function switchTab(t) {
  playTone("tap");
  if (state.tab !== t) {
    state.tab = t;
    pushNavHistory();
  }
  if (t === "quiz" && quizState.questions.length === 0) initQuiz(state.lessonId);
  saveState();
  render();
  window.scrollTo(0, 0);
}

function openLesson(id) {
  playTone("tap");
  state.lessonId = id;
  state.memoIdx = 0;
  state.tab = "learn";
  pushNavHistory();
  saveState();
  render();
  window.scrollTo(0, 0);
}

function startQuiz(id) {
  playTone("tap");
  initQuiz(id);
  state.tab = "quiz";
  pushNavHistory();
  saveState();
  render();
  window.scrollTo(0, 0);
}

function toggleDone(id) {
  const i = state.done.indexOf(id);
  if (i >= 0) {
    state.done.splice(i, 1);
    playTone("tap");
  } else {
    state.done.push(id);
    playTone("correct");
  }
  saveState();
  render();
}

function toggleBookmark(id) {
  const i = state.bookmarks.indexOf(id);
  if (i >= 0) state.bookmarks.splice(i, 1);
  else state.bookmarks.push(id);
  playTone("tap");
  saveState();
  render();
}

function incTasbeeh() {
  state.tasbeeh = state.tasbeeh >= 100 ? 1 : state.tasbeeh + 1;
  playTone(state.tasbeeh === 100 ? "correct" : "tasbeeh");
  saveState();
  render();
}

function resetTasbeeh() {
  state.tasbeeh = 0;
  playTone("tap");
  saveState();
  render();
}

function stepAzkar(key, delta) {
  const arr = AZKAR[key];
  state.azkarIdx[key] = (state.azkarIdx[key] + delta + arr.length) % arr.length;
  playTone("tap");
  saveState();
  render();
}

function openSearchResult(itemJsonEnc) {
  const item = JSON.parse(decodeURIComponent(itemJsonEnc));
  closeModal();
  if (item.lessonId) {
    openLesson(item.lessonId);
  } else if (item.azkarKey) {
    state.azkarIdx[item.azkarKey] = item.azkarIndex || 0;
    switchTab("azkar");
  }
}

function pickQuizOption(idx) {
  if (quizState.picked !== null) return;
  quizState.picked = idx;
  if (idx === quizState.questions[quizState.idx].ans) {
    quizState.score++;
    playTone("correct");
  } else {
    playTone("wrong");
  }
  render();
}

function nextQuizQ() {
  quizState.idx++;
  quizState.picked = null;
  if (quizState.idx >= quizState.questions.length) {
    quizState.finished = true;
    state.scores[quizState.lessonId] = Math.max(state.scores[quizState.lessonId] || 0, quizState.score);
    if (quizState.score >= 7 && !state.done.includes(quizState.lessonId)) {
      state.done.push(quizState.lessonId);
    }
    saveState();
  }
  render();
}

function pickQuickQuizOption(idx) {
  if (quickQuizState.picked !== null) return;
  quickQuizState.picked = idx;
  if (idx === quickQuizState.questions[quickQuizState.idx].ans) {
    quickQuizState.score++;
    playTone("correct");
  } else {
    playTone("wrong");
  }
  renderModal();
}

function nextQuickQuizQ() {
  quickQuizState.idx++;
  quickQuizState.picked = null;
  if (quickQuizState.idx >= quickQuizState.questions.length) {
    quickQuizState.finished = true;
  }
  renderModal();
}

function speakLesson(id) {
  const l = getLessonById(id);
  speakAr(l.lines.map((x) => x.words.map((w) => w.ar).join(" ")).join(". "));
}

function speakLine(id, lineIdx) {
  const l = getLessonById(id);
  const ln = l.lines[lineIdx];
  if (ln) speakAr(ln.words.map((w) => w.ar).join(" "));
}

function speakWord(id, lineIdx, wordIdx) {
  const l = getLessonById(id);
  const w = l.lines[lineIdx] && l.lines[lineIdx].words[wordIdx];
  if (w) speakAr(w.ar);
}

function speakAzkarKey(key) {
  const item = AZKAR[key] && AZKAR[key][state.azkarIdx[key]];
  if (item) speakAr(item.ar);
}

function getTasbeehPhrase(tc) {
  return tc <= 33 ? "سُبْحَانَ اللّٰهِ" : tc <= 66 ? "اَلْحَمْدُ لِلّٰهِ" : tc < 100 ? "اَللّٰهُ أَكْبَرُ" : "تَسْبِيْحُ فَاطِمَةَ مُكَمَّلٌ";
}

function speakTasbeeh() {
  speakAr(getTasbeehPhrase(state.tasbeeh));
}

function stepMemo(delta, totalLines) {
  state.memoIdx = (state.memoIdx + delta + totalLines) % totalLines;
  playTone("tap");
  saveState();
  render();
}

function saveBranding() {
  state.appNameUr = document.getElementById("edAppUr").value.trim() || state.appNameUr;
  state.appNameEn = document.getElementById("edAppEn").value.trim() || state.appNameEn;
  state.schoolUr = document.getElementById("edSchUr").value.trim() || state.schoolUr;
  state.schoolEn = document.getElementById("edSchEn").value.trim() || state.schoolEn;
  saveState();
  render();
  showToast(isEn() ? "Saved!" : "محفوظ ہو گیا!");
}

function saveCustomLesson() {
  const ar = document.getElementById("nlAr").value.trim();
  const ur = document.getElementById("nlUr").value.trim();
  if (!ar || !ur) {
    alert(isEn() ? "Please enter Arabic & Urdu" : "عربی اور اردو درج کریں");
    return;
  }
  const en = document.getElementById("nlEn").value.trim() || ur;
  const nextId = Math.max(...allLessons().map((x) => x.id)) + 1;
  state.customLessons[nextId] = {
    id: nextId,
    titleUr: document.getElementById("nlTitUr").value.trim() || ("نیا سبق " + nextId),
    titleEn: document.getElementById("nlTitEn").value.trim() || ("Lesson " + nextId),
    keys: "",
    lines: [{
      labelUr: "سطر ۱",
      labelEn: "Line 1",
      fullUr: ur,
      fullEn: en,
      words: [{ ar, ur, en, pron: "" }]
    }],
    lughat: [{ ar, ur, en }]
  };
  saveState();
  openLesson(nextId);
}

function resetAllOfflineData() {
  if (confirm(isEn() ? "Reset all progress & custom edits?" : "تمام ریکارڈ اور تبدیلیاں صاف کریں؟")) {
    safeStorageRemove(STORE_KEY);
    state = loadState();
    render();
    showToast(isEn() ? "Data cleared" : "تمام ریکارڈ صاف کر دیا گیا");
  }
}

async function shareAppHtml() {
  const shareTitle = "نورِ کاشف — ترجمانِ نماز";
  const shareText = "نورِ کاشف (ترجمانِ نماز): بچوں، طلبہ، گھر اور مدرسے کے لیے لفظ بہ لفظ نماز ترجمہ، مسنون اذکار و نمازِ جنازہ کی آف لائن ایپ۔\nمرتب: حافظ کاشف منیر بدر\nWhatsApp: +923036620170 | Email: kashifmunirbadr6620@gmail.com";
  if (navigator.share) {
    try {
      await navigator.share({ title: shareTitle, text: shareText });
      showToast(isEn() ? "App shared!" : "جزاک اللہ خیر! پیغام شیئر ہو گیا۔");
      return;
    } catch (err) {
      if (err && err.name === "AbortError") return;
    }
  }
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(shareText);
      showToast(isEn() ? "Copied to clipboard!" : "تفصیل کلپ بورڈ پر کاپی ہو گئی!");
      return;
    }
  } catch (_) {}
  alert(shareText);
}

function escHtml(s) {
  return String(s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/* ==========================================================================
   Renderers (Modals, Bottom Nav & Screens)
   ========================================================================== */
function renderModal() {
  const root = document.getElementById("modalRoot");
  if (!root || !activeModal) return;
  root.classList.remove("hidden");

  if (activeModal === "quickQuiz") {
    const total = quickQuizState.questions.length || 5;
    const q = quickQuizState.questions[quickQuizState.idx];
    root.innerHTML = `
      <div class="modal-sheet" onclick="event.stopPropagation()">
        <div class="modal-head">
          <div>
            <b>⚡ ${isEn() ? "Quick Quiz (5 MCQs)" : "فوری کوئز (۵ سوالات)"}</b>
            <div style="font-size:0.75rem;opacity:0.9">${isEn() ? "Random selection from 170-question bank" : "۱۷۰ سوالات کے بینک میں سے ۵ منتخب سوالات"}</div>
          </div>
          <button class="icon-chip-btn" onclick="closeModal()" aria-label="Close">✕</button>
        </div>
        <div class="modal-body">
          ${quickQuizState.finished ? `
            <div style="text-align:center;padding:12px 0">
              <div style="font-size:2.4rem">${quickQuizState.score >= 3 ? "⭐⭐⭐" : "⭐"}</div>
              <h3 style="margin:6px 0">${isEn() ? "Quick Quiz Completed!" : "فوری کوئز مکمل ہو گیا!"}</h3>
              <div class="badge badge-gold" style="font-size:1.15rem;padding:6px 16px">${quickQuizState.score} / ${total}</div>
              <div class="btn-row" style="margin-top:16px">
                <button class="btn btn-outline" onclick="closeModal()">${isEn() ? "Close" : "بند کریں"}</button>
                <button class="btn btn-gold" onclick="startQuickQuiz()">🔁 ${isEn() ? "New 5 Questions" : "۵ نئے سوالات"}</button>
              </div>
            </div>
          ` : `
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
              <span class="badge">${escHtml(q.lessonTitle)}</span>
              <span class="badge badge-gold">${quickQuizState.idx + 1}/${total} • ${quickQuizState.score}</span>
            </div>
            <h4 style="margin:6px 0">${escHtml(q.q)}</h4>
            ${q.ar ? `<div class="azkar-box arabic azkar-ar" style="margin:8px 0">${escHtml(q.ar)}</div>` : ""}
            ${q.opts.map((opt, idx) => {
              let cls = "quiz-opt";
              if (quickQuizState.picked !== null) {
                if (idx === q.ans) cls += " correct";
                else if (idx === quickQuizState.picked) cls += " wrong";
              }
              return `<button class="${cls}" onclick="pickQuickQuizOption(${idx})">${escHtml(opt)}</button>`;
            }).join("")}
            ${quickQuizState.picked !== null ? `<button class="btn" style="width:100%" onclick="nextQuickQuizQ()">${quickQuizState.idx + 1 >= total ? (isEn() ? "View Result" : "نتیجہ دیکھیں") : (isEn() ? "Next Question ▶" : "اگلا سوال ▶")}</button>` : ""}
          `}
        </div>
      </div>`;
  } else if (activeModal === "globalSearch") {
    const existingInput = document.getElementById("gsModalInput");
    if (!existingInput || !root.querySelector("#gsResultsArea")) {
      root.innerHTML = `
        <div class="modal-sheet" onclick="event.stopPropagation()">
          <div class="modal-head">
            <div>
              <b>🔍 ${isEn() ? "Global Search" : "عالمی تلاش"}</b>
              <div style="font-size:0.75rem;opacity:0.9">${isEn() ? "Lessons, Masnoon Duas & Ahadees" : "اسباق، مسنون دعائیں اور احادیث"}</div>
            </div>
            <button class="icon-chip-btn" onclick="closeModal()" aria-label="Close">✕</button>
          </div>
          <div class="modal-body">
            <input type="text" id="gsModalInput" value="${escHtml(globalSearchState.query)}"
              oninput="globalSearchState.query=this.value;renderGlobalSearchResults();"
              placeholder="${isEn() ? "Search Fatiha, Janaza, Bukhari, Istighfar..." : "تلاش کریں: فاتحہ، جنازہ، بخاری، استغفار..."}" />
            <div id="gsResultsArea"></div>
          </div>
        </div>`;
      setTimeout(() => {
        const inp = document.getElementById("gsModalInput");
        if (inp) inp.focus();
      }, 40);
    }
    renderGlobalSearchResults();
  }
}

function renderGlobalSearchResults() {
  const area = document.getElementById("gsResultsArea");
  if (!area) return;
  const results = runGlobalSearch(globalSearchState.query, globalSearchState.category);
  const cats = [
    ["all", isEn() ? "All" : "سب"],
    ["lesson", isEn() ? "Lessons" : "اسباق"],
    ["dua", isEn() ? "Duas" : "دعائیں"],
    ["hadith", isEn() ? "Ahadees" : "احادیث"]
  ];
  area.innerHTML = `
    <div class="chip-scroll" style="margin:10px 0">
      ${cats.map(([cId, cLbl]) => `<button class="filter-chip ${globalSearchState.category === cId ? "active" : ""}" onclick="globalSearchState.category='${cId}';renderGlobalSearchResults()">${cLbl}</button>`).join("")}
    </div>
    ${!globalSearchState.query.trim() ? `
      <div style="font-size:0.84rem;color:var(--muted);margin-bottom:8px">${isEn() ? "Popular Keywords:" : "مقبول الفاظ (کلک کریں):"}</div>
      <div class="chip-scroll">
        ${(isEn() ? ["Fatiha", "Janaza", "Istighfar", "Bukhari", "Morning"] : ["فاتحہ", "جنازہ", "استغفار", "بخاری", "صبح"]).map((kw) =>
          `<button class="filter-chip" onclick="globalSearchState.query='${kw}';var inp=document.getElementById('gsModalInput');if(inp)inp.value='${kw}';renderGlobalSearchResults()">${kw}</button>`
        ).join("")}
      </div>
    ` : results.length ? `
      <div class="lesson-list">
        ${results.map((r) => {
          const badgeCls = r.cat === "lesson" ? "badge" : r.cat === "dua" ? "badge badge-gold" : "badge badge-blue";
          const catTxt = r.cat === "lesson" ? (isEn() ? "Lesson" : "سبق") : r.cat === "dua" ? (isEn() ? "Dua" : "دعا") : (isEn() ? "Hadith" : "حدیث");
          return `
            <button class="search-result-card" onclick="openSearchResult('${encodeURIComponent(JSON.stringify(r))}')">
              <div style="display:flex;justify-content:space-between;align-items:center;width:100%;gap:6px">
                <b style="font-size:0.86rem">${escHtml(isEn() ? r.titleEn : r.titleUr)}</b>
                <span class="${badgeCls}">${catTxt}</span>
              </div>
              ${r.ar ? `<div class="arabic" style="font-size:1.15rem;color:var(--green)">${escHtml(r.ar)}</div>` : ""}
              <div style="font-size:0.84rem;color:var(--red);font-weight:700">${escHtml(isEn() ? r.trEn : r.trUr)}</div>
              ${r.subUr || r.subEn ? `<small style="color:var(--muted)">${escHtml(isEn() ? r.subEn : r.subUr)}</small>` : ""}
            </button>`;
        }).join("")}
      </div>
    ` : `<div style="text-align:center;padding:16px;color:var(--muted)">${isEn() ? "No matching results found." : "کوئی نتیجہ نہیں ملا۔"}</div>`}`;
}

document.getElementById("modalRoot").addEventListener("click", () => closeModal());

function applyTheme() {
  document.documentElement.lang = isEn() ? "en" : "ur";
  document.documentElement.dir = isEn() ? "ltr" : "rtl";
  document.body.className = `${state.dark ? "dark" : ""} ${state.big ? "big" : ""} ${isEn() ? "en" : ""}`.trim();
  document.getElementById("hdrAppName").textContent = isEn() ? state.appNameEn : state.appNameUr;
  document.getElementById("hdrSchool").textContent = isEn() ? state.schoolEn : state.schoolUr;
  document.getElementById("btnQuickLang").textContent = isEn() ? "اردو" : "EN";
  document.getElementById("btnQuickDark").textContent = state.dark ? "☀️" : "🌙";
}

function renderNav() {
  const tabs = [
    ["home", "🏠", isEn() ? "Home" : "ہوم"],
    ["learn", "📖", isEn() ? "Learn" : "اسباق"],
    ["azkar", "🕌", isEn() ? "Azkar" : "اذکار"],
    ["quiz", "📝", isEn() ? "Quiz" : "کوئز"],
    ["settings", "⚙️", isEn() ? "Settings" : "سیٹنگز"]
  ];
  document.getElementById("bottomNav").innerHTML = `
    <div class="bottom-nav-inner">
      ${tabs.map(([id, ic, lb]) => `
        <button type="button" class="nav-btn ${state.tab === id ? "active" : ""}" onclick="switchTab('${id}')">
          <span style="font-size:1.15rem">${ic}</span>
          <span>${lb}</span>
        </button>`).join("")}
    </div>`;
}

function render() {
  applyTheme();
  renderNav();
  const root = document.getElementById("appRoot");
  const lessons = allLessons();

  if (state.tab === "home") {
    const doneCount = lessons.filter((l) => state.done.includes(l.id)).length;
    const pct = Math.round((doneCount / lessons.length) * 100);
    const filtered = lessons.filter((l) => {
      if (state.homeFilter === "done") return state.done.includes(l.id);
      if (state.homeFilter === "remaining") return !state.done.includes(l.id);
      if (state.homeFilter === "bookmarked") return state.bookmarks.includes(l.id);
      return true;
    });

    root.innerHTML = `<div class="screen-view">
      <div class="card hero-card">
        <div class="arabic bismillah">بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ</div>
        <div class="hero-sub">${isEn() ? "Word-by-word Namaz Tarjuma, Duas & Ahadees" : "بچوں، طلبہ، گھر اور مدرسے کے لیے لفظ بہ لفظ نماز ترجمہ"}</div>
        <div class="btn-row">
          <button class="btn btn-gold" onclick="openLesson(${state.lessonId})">📖 ${isEn() ? "Continue" : "سبق پڑھیں"}</button>
          <button class="btn btn-outline" style="background:rgba(0,0,0,0.22);color:#FBE498;border-color:#FBE498" onclick="startQuickQuiz()">⚡ ${isEn() ? "Quick Quiz" : "فوری کوئز"}</button>
        </div>
        <div class="progress-track"><div class="progress-fill" style="width:${pct}%"></div></div>
        <div style="display:flex;justify-content:space-between;font-size:0.84rem;color:#FBE498;font-weight:700">
          <span>${isEn() ? `Completed: ${doneCount}/${lessons.length}` : `مکمل اسباق: ${doneCount} از ${lessons.length}`}</span>
          <span>${pct}%</span>
        </div>
      </div>

      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
          <b>📊 ${isEn() ? "17-Lesson Progress Tracker" : "تعلیمی پیشرفت ٹریکر"}</b>
          <span class="badge badge-gold">${doneCount} / ${lessons.length}</span>
        </div>
        <div class="segment-strip">
          ${lessons.map((l) => `<div class="segment-bar ${state.done.includes(l.id) ? "done" : ""}" title="${l.id}"></div>`).join("")}
        </div>
        <div class="chip-scroll" style="margin-top:8px">
          <button class="filter-chip ${state.homeFilter === "all" ? "active" : ""}" onclick="state.homeFilter='all';saveState();render()">${isEn() ? `All (${lessons.length})` : `سب (${lessons.length})`}</button>
          <button class="filter-chip ${state.homeFilter === "done" ? "active" : ""}" onclick="state.homeFilter='done';saveState();render()">${isEn() ? `Done (${doneCount})` : `مکمل (${doneCount})`}</button>
          <button class="filter-chip ${state.homeFilter === "remaining" ? "active" : ""}" onclick="state.homeFilter='remaining';saveState();render()">${isEn() ? `Left (${lessons.length - doneCount})` : `باقی (${lessons.length - doneCount})`}</button>
          <button class="filter-chip ${state.homeFilter === "bookmarked" ? "active" : ""}" onclick="state.homeFilter='bookmarked';saveState();render()">⭐ ${isEn() ? `Saved (${state.bookmarks.length})` : `محفوظ (${state.bookmarks.length})`}</button>
        </div>
      </div>

      <div class="card" style="background:var(--green-light);border:1.5px solid var(--gold)">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
          <b>🕌 ${isEn() ? "Duas, Ahadees, Janaza & Tasbeeh" : "مسنون دعائیں، احادیث، جنازہ و تسبیح"}</b>
          <span class="badge badge-gold">${state.tasbeeh}/100</span>
        </div>
        <div class="btn-row">
          <button class="btn btn-outline" onclick="switchTab('azkar')">📿 ${isEn() ? "Open Azkar & Janaza" : "اذکار و جنازہ کھولیں"}</button>
          <button class="btn btn-gold" onclick="openGlobalSearch()">🔍 ${isEn() ? "Global Search" : "عالمی تلاش"}</button>
        </div>
      </div>

      <div class="lesson-list">
        ${filtered.length ? filtered.map((l) => {
          const isDone = state.done.includes(l.id);
          const isSaved = state.bookmarks.includes(l.id);
          const sc = state.scores[l.id];
          return `
            <div class="lesson-card ${isDone ? "done" : ""}">
              <div style="display:flex;justify-content:space-between;align-items:center;gap:6px">
                <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
                  <span class="badge">${isEn() ? `Lesson ${l.id}` : `سبق ${l.id}`}</span>
                  ${isDone ? `<span class="badge badge-gold">✓ ${isEn() ? "Done" : "مکمل"}</span>` : ""}
                  ${sc !== undefined ? `<span class="badge badge-gold">${sc}/10</span>` : ""}
                </div>
                <button class="filter-chip" style="min-height:48px;padding:4px 10px" onclick="toggleBookmark(${l.id})" aria-label="Bookmark">${isSaved ? "⭐" : "☆"}</button>
              </div>
              <b style="font-size:1.05rem">${escHtml(isEn() ? l.titleEn : l.titleUr)}</b>
              <div class="arabic lesson-preview-ar">${escHtml(l.lines[0].words.map((w) => w.ar).join(" "))}</div>
              <div class="btn-row">
                <button class="btn" onclick="openLesson(${l.id})">📖 ${isEn() ? "Learn" : "پڑھیں"}</button>
                <button class="btn btn-outline" onclick="startQuiz(${l.id})">📝 ${isEn() ? "Quiz" : "کوئز"}</button>
                <button class="btn ${isDone ? "btn-gold" : "btn-outline"}" onclick="toggleDone(${l.id})">${isDone ? "✓" : "○"}</button>
              </div>
            </div>`;
        }).join("") : `<div class="card" style="text-align:center;color:var(--muted)">${isEn() ? "No lessons in this filter." : "اس فہرست میں کوئی سبق موجود نہیں۔"}</div>`}
      </div>
    </div>`;
  } else if (state.tab === "learn") {
    const l = getLessonById(state.lessonId);
    const isDone = state.done.includes(l.id);
    const isSaved = state.bookmarks.includes(l.id);
    const activeMemoIdx = state.memoIdx % l.lines.length;
    const displayLines = state.memo ? [{ ln: l.lines[activeMemoIdx], idx: activeMemoIdx }] : l.lines.map((ln, idx) => ({ ln, idx }));

    root.innerHTML = `<div class="screen-view">
      <div class="card">
        <div style="display:flex;gap:8px;margin-bottom:10px">
          <select onchange="openLesson(Number(this.value))" style="flex:1">
            ${lessons.map((x) => `<option value="${x.id}" ${x.id === l.id ? "selected" : ""}>${x.id}. ${escHtml(isEn() ? x.titleEn : x.titleUr)}</option>`).join("")}
          </select>
          <button class="filter-chip" onclick="toggleBookmark(${l.id})" aria-label="Bookmark">${isSaved ? "⭐" : "☆"}</button>
        </div>
        <div class="btn-row">
          <button class="btn btn-outline" onclick="speakLesson(${l.id})">🔊 ${isEn() ? "Recite" : "سنیں"}</button>
          <button class="btn btn-outline" onclick="state.hideTr=!state.hideTr;saveState();render()">${state.hideTr ? (isEn() ? "Show Meaning" : "ترجمہ دکھائیں") : (isEn() ? "Hide Meaning" : "ترجمہ چھپائیں")}</button>
          <button class="btn btn-outline" onclick="state.memo=!state.memo;state.memoIdx=0;saveState();render()">${state.memo ? (isEn() ? "Book View" : "کتابی انداز") : (isEn() ? "Hifz Mode" : "حفظ موڈ")}</button>
          <button class="btn ${isDone ? "btn-gold" : "btn-outline"}" onclick="toggleDone(${l.id})">${isDone ? "✓ " + (isEn() ? "Completed" : "مکمل") : (isEn() ? "Mark Complete" : "مکمل کریں")}</button>
        </div>
      </div>

      ${displayLines.map(({ ln, idx }) => `
        <div class="card">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
            <span class="badge">${escHtml(isEn() ? ln.labelEn : ln.labelUr)}</span>
            <button class="btn btn-outline" style="min-height:48px" onclick="speakLine(${l.id}, ${idx})">🔊</button>
          </div>
          <div class="word-grid">
            ${ln.words.map((w, wIdx) => `
              <div class="word-box" onclick="speakWord(${l.id}, ${idx}, ${wIdx})">
                <div class="arabic word-ar">${escHtml(w.ar)}</div>
                <div class="word-tr">${state.hideTr ? "•••" : escHtml(isEn() ? w.en : w.ur)}</div>
                <div class="pron">${escHtml(w.pron || "")}</div>
              </div>`).join("")}
          </div>
          <div class="full-tr-box">${state.hideTr ? "••••••" : escHtml(isEn() ? ln.fullEn : ln.fullUr)}</div>
          ${state.memo ? `
            <div class="btn-row" style="margin-top:10px">
              <button class="btn btn-outline" onclick="stepMemo(-1, ${l.lines.length})">◀ ${isEn() ? "Prev Line" : "پچھلی سطر"}</button>
              <button class="btn" onclick="stepMemo(1, ${l.lines.length})">${isEn() ? "Next Line" : "اگلی سطر"} ▶</button>
            </div>` : ""}
        </div>`).join("")}

      <div class="card">
        <b>📚 ${isEn() ? "Vocabulary (Lughat)" : "مشکل الفاظ کے معانی (لغت)"}</b>
        <div class="word-grid" style="margin-top:8px">
          ${l.lughat.map((g) => `<div class="word-box"><div class="arabic" style="font-size:1.3rem;color:var(--green)">${escHtml(g.ar)}</div><div style="font-weight:700">${escHtml(isEn() ? g.en : g.ur)}</div></div>`).join("")}
        </div>
      </div>

      <div class="btn-row">
        <button class="btn btn-outline" onclick="openLesson(${l.id > 1 ? l.id - 1 : lessons.length})">◀ ${isEn() ? "Prev" : "پچھلا"}</button>
        <button class="btn btn-gold" onclick="startQuiz(${l.id})">📝 ${isEn() ? "Quiz" : "کوئز"}</button>
        <button class="btn" onclick="openLesson(${l.id < lessons.length ? l.id + 1 : 1})">${isEn() ? "Next" : "اگلا"} ▶</button>
      </div>
    </div>`;
  } else if (state.tab === "azkar") {
    const a = AZKAR.asma[state.azkarIdx.asma];
    const h = AZKAR.hadith[state.azkarIdx.hadith];
    const s = AZKAR.salah[state.azkarIdx.salah];
    const m = AZKAR.mornEve[state.azkarIdx.mornEve];
    const j = AZKAR.janaza[state.azkarIdx.janaza];
    const tc = state.tasbeeh;

    root.innerHTML = `<div class="screen-view">
      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center"><b>1. ${isEn() ? "Asma-ul-Husna" : "اسماء الحسنیٰ"}</b><span class="badge badge-gold">${state.azkarIdx.asma + 1}/${AZKAR.asma.length}</span></div>
        <div class="azkar-box">
          <div class="arabic azkar-ar">${escHtml(a.ar)}</div>
          <div><b>${escHtml(isEn() ? a.en : a.ur)}</b> — ${escHtml(isEn() ? a.mEn : a.mUr)}</div>
        </div>
        <div class="btn-row">
          <button class="btn btn-outline" onclick="stepAzkar('asma',-1)">◀ ${isEn() ? "Prev" : "پچھلا"}</button>
          <button class="btn" onclick="speakAzkarKey('asma')">🔊 ${isEn() ? "Listen" : "سنیں"}</button>
          <button class="btn btn-outline" onclick="stepAzkar('asma',1)">${isEn() ? "Next" : "اگلا"} ▶</button>
        </div>
      </div>

      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center"><b>2. ${isEn() ? "Selected Ahadees" : "منتخب احادیث"}</b><span class="badge badge-gold">${state.azkarIdx.hadith + 1}/${AZKAR.hadith.length}</span></div>
        <div class="azkar-box">
          <div class="arabic azkar-ar">${escHtml(h.ar)}</div>
          <div style="color:var(--blue-text);font-weight:700">${escHtml(isEn() ? h.en : h.ur)}</div>
          <small style="color:var(--muted)">${escHtml(isEn() ? h.refEn : h.refUr)}</small>
        </div>
        <div class="btn-row">
          <button class="btn btn-outline" onclick="stepAzkar('hadith',-1)">◀ ${isEn() ? "Prev" : "پچھلا"}</button>
          <button class="btn" onclick="speakAzkarKey('hadith')">🔊 ${isEn() ? "Listen" : "سنیں"}</button>
          <button class="btn btn-outline" onclick="stepAzkar('hadith',1)">${isEn() ? "Next" : "اگلا"} ▶</button>
        </div>
      </div>

      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center"><b>3. ${isEn() ? "After Salah Azkar" : "بعد نماز اذکار (ترتیب وار)"}</b><span class="badge badge-gold">${s.step}/${AZKAR.salah.length}</span></div>
        <div style="margin-top:6px"><span class="badge">${escHtml(isEn() ? s.repEn : s.repUr)}</span></div>
        <div class="azkar-box">
          <div class="arabic azkar-ar">${escHtml(s.ar)}</div>
          <div style="color:var(--blue-text);font-weight:700">${escHtml(isEn() ? s.en : s.ur)}</div>
          <small style="color:var(--muted)">(${escHtml(s.ref)})</small>
        </div>
        <div class="btn-row">
          <button class="btn btn-outline" onclick="stepAzkar('salah',-1)">◀ ${isEn() ? "Prev" : "پچھلا"}</button>
          <button class="btn" onclick="speakAzkarKey('salah')">🔊 ${isEn() ? "Listen" : "سنیں"}</button>
          <button class="btn btn-outline" onclick="stepAzkar('salah',1)">${isEn() ? "Next" : "اگلا"} ▶</button>
        </div>
      </div>

      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center"><b>4. ${isEn() ? "Morning & Evening" : "صبح و شام کے اذکار"}</b><span class="badge badge-gold">${m.step}/${AZKAR.mornEve.length}</span></div>
        <div style="margin-top:6px"><span class="badge">${escHtml(isEn() ? m.repEn : m.repUr)}</span></div>
        <div class="azkar-box">
          <div class="arabic azkar-ar">${escHtml(m.ar)}</div>
          <div style="color:var(--blue-text);font-weight:700">${escHtml(isEn() ? m.en : m.ur)}</div>
          <small style="color:var(--muted)">(${escHtml(m.ref)})</small>
        </div>
        <div class="btn-row">
          <button class="btn btn-outline" onclick="stepAzkar('mornEve',-1)">◀ ${isEn() ? "Prev" : "پچھلا"}</button>
          <button class="btn" onclick="speakAzkarKey('mornEve')">🔊 ${isEn() ? "Listen" : "سنیں"}</button>
          <button class="btn btn-outline" onclick="stepAzkar('mornEve',1)">${isEn() ? "Next" : "اگلا"} ▶</button>
        </div>
      </div>

      <div class="card" style="border:2px solid var(--gold)">
        <div style="display:flex;justify-content:space-between;align-items:center"><b>5. ${isEn() ? "Namaz-e-Janaza Duas" : "نمازِ جنازہ کی مسنون دعائیں"}</b><span class="badge badge-gold">${j.step}/${AZKAR.janaza.length}</span></div>
        <div style="margin-top:6px"><span class="badge">${escHtml(isEn() ? j.repEn : j.repUr)}</span></div>
        <div class="azkar-box">
          <div class="arabic azkar-ar">${escHtml(j.ar)}</div>
          <div style="color:var(--blue-text);font-weight:700">${escHtml(isEn() ? j.en : j.ur)}</div>
          <small style="color:var(--muted)">(${escHtml(j.ref)})</small>
        </div>
        <div class="btn-row">
          <button class="btn btn-outline" onclick="stepAzkar('janaza',-1)">◀ ${isEn() ? "Prev" : "پچھلا"}</button>
          <button class="btn" onclick="speakAzkarKey('janaza')">🔊 ${isEn() ? "Listen" : "سنیں"}</button>
          <button class="btn btn-outline" onclick="stepAzkar('janaza',1)">${isEn() ? "Next" : "اگلا"} ▶</button>
        </div>
      </div>

      <div class="card" style="border:2px solid var(--gold)">
        <div style="display:flex;justify-content:space-between;align-items:center"><b>6. ${isEn() ? "Tasbeeh-e-Fatimi" : "تسبیحِ فاطمی کاؤنٹر"}</b><span class="badge badge-gold">${tc}/100</span></div>
        <div class="tasbeeh-hero">
          <div class="arabic" style="font-size:1.85rem;color:#FBE498">${getTasbeehPhrase(tc)}</div>
          <div style="font-size:2.6rem;font-weight:800">${tc}</div>
        </div>
        <div class="btn-row">
          <button class="btn" style="flex:2" onclick="incTasbeeh()">➕ ${isEn() ? "Count (+1)" : "تسبیح گنیں (+1)"}</button>
          <button class="btn btn-outline" onclick="speakTasbeeh()">🔊</button>
          <button class="btn btn-red" onclick="resetTasbeeh()">↺</button>
        </div>
      </div>
    </div>`;
  } else if (state.tab === "quiz") {
    const q = quizState.questions[quizState.idx];
    root.innerHTML = `<div class="screen-view">
      <div class="card" style="display:flex;justify-content:space-between;align-items:center;gap:8px">
        <b>⚡ ${isEn() ? "Want a quick 5-MCQ test?" : "فوری ۵ سوالات کا کوئز دیں"}</b>
        <button class="btn btn-gold" onclick="startQuickQuiz()">${isEn() ? "Quick Quiz" : "فوری کوئز"}</button>
      </div>
      ${quizState.finished ? `
        <div class="card" style="text-align:center">
          <h2>${isEn() ? "Quiz Completed!" : "کوئز مکمل ہو گیا!"}</h2>
          <div style="font-size:2.4rem;font-weight:800;color:var(--green)">${quizState.score} / 10</div>
          <div class="btn-row" style="margin-top:14px">
            <button class="btn" onclick="startQuiz(${quizState.lessonId})">🔁 ${isEn() ? "Retry" : "دوبارہ دیں"}</button>
            <button class="btn btn-outline" onclick="openLesson(${quizState.lessonId})">📖 ${isEn() ? "Review Lesson" : "سبق دیکھیں"}</button>
          </div>
        </div>
      ` : `
        <div class="card">
          <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:8px">
            <select onchange="startQuiz(Number(this.value))" style="flex:1">
              ${lessons.map((l) => `<option value="${l.id}" ${l.id === quizState.lessonId ? "selected" : ""}>${l.id}. ${escHtml(isEn() ? l.titleEn : l.titleUr)}</option>`).join("")}
            </select>
            <span class="badge badge-gold">${quizState.idx + 1}/10 • ${quizState.score}</span>
          </div>
          <h3 style="margin:6px 0">${escHtml(q.q)}</h3>
          ${q.ar ? `<div class="azkar-box arabic azkar-ar" style="margin:8px 0">${escHtml(q.ar)}</div>` : ""}
          ${q.opts.map((opt, idx) => {
            let cls = "quiz-opt";
            if (quizState.picked !== null) {
              if (idx === q.ans) cls += " correct";
              else if (idx === quizState.picked) cls += " wrong";
            }
            return `<button class="${cls}" onclick="pickQuizOption(${idx})">${escHtml(opt)}</button>`;
          }).join("")}
          ${quizState.picked !== null ? `<button class="btn" style="width:100%" onclick="nextQuizQ()">${isEn() ? "Next Question ▶" : "اگلا سوال ▶"}</button>` : ""}
        </div>
      `}
    </div>`;
  } else if (state.tab === "settings") {
    root.innerHTML = `<div class="screen-view">
      <div class="card">
        <h3 style="margin:0 0 8px 0">⚙️ ${isEn() ? "App Settings" : "ایپ سیٹنگز"}</h3>
        <div class="setting-row">
          <span>🌐 ${isEn() ? "Language (Urdu / English)" : "زبان (اردو / انگریزی)"}</span>
          <button class="btn btn-outline" onclick="toggleLang()">${isEn() ? "اردو" : "English"}</button>
        </div>
        <div class="setting-row">
          <span>🌙 ${isEn() ? "Night Mode" : "رات کا موڈ (ڈارک تھیم)"}</span>
          <button class="btn btn-outline" onclick="toggleDark()">${state.dark ? (isEn() ? "On" : "آن") : (isEn() ? "Off" : "بند")}</button>
        </div>
        <div class="setting-row">
          <span>🔠 ${isEn() ? "Large Font Size" : "بڑا فونٹ سائز"}</span>
          <button class="btn btn-outline" onclick="toggleBigFont()">${state.big ? (isEn() ? "Large" : "بڑا") : (isEn() ? "Normal" : "عام")}</button>
        </div>
        <div class="setting-row">
          <span>🔔 ${isEn() ? "Audio Chime Effects" : "کوئز اور تسبیح کی آواز"}</span>
          <button class="btn btn-outline" onclick="toggleSoundFx()">${state.soundFx ? (isEn() ? "On" : "آن") : (isEn() ? "Off" : "بند")}</button>
        </div>
      </div>

      <section class="card" dir="rtl" style="border:1.5px solid var(--gold)">
        <span class="badge badge-gold" style="margin-bottom:8px">نورِ کاشف • ترجمانِ نماز</span>
        <h3 style="margin:4px 0 10px 0;color:var(--green)">ایپ کا تعارف</h3>
        <div class="about-body">
          <p style="margin:0 0 10px 0">نورِ کاشف کو حافظ کاشف منیر بدر نے اس نیت سے ترتیب دیا ہے کہ عام فہم انداز میں نماز کے کلمات اور ان کا ترجمہ ہر خاص و عام کے لیے آسان بنایا جا سکے۔ بچوں اور بڑوں کو ابتدائی عمر ہی سے نماز کے معانی سکھانا ہماری اولین ذمہ داری ہے، اسی لیے اس ایپ کو خاص طور پر اس طرح ڈیزائن کیا گیا ہے کہ ہر لفظ کا الگ رنگ اور واضح ترجمہ دیکھ کر طالب علم باآسانی نماز کا مفہوم ذہن نشین کر سکیں۔</p>
          <p style="margin:0">یہ ایپ گھر اور مدرسے دونوں جگہ نماز کی درست ادائیگی اور فہم کے لیے ایک بہترین ساتھی ہے۔ آپ سے گزارش ہے کہ اس کاوش کو دوسروں تک پہنچائیں اور ہمیں اپنی خصوصی دعاؤں میں یاد رکھیں۔</p>
        </div>
        <div class="feedback-box">
          <h4 style="margin:0 0 6px 0;color:var(--green)">تصحیح، مشورہ اور رابطہ</h4>
          <p style="margin:0;line-height:2">اگر آپ کو ترجمے یا ٹائپنگ میں کہیں کوئی غلطی نظر آئے تو براہِ کرم ضرور مطلع فرمائیں، اور ثواب کی نیت سے اس ایپ کو اپنے دوستوں اور گھر والوں کے ساتھ شیئر کریں۔</p>
          <div class="contact-line">
            WhatsApp: <a href="https://wa.me/923036620170">+923036620170</a>
            &nbsp;|&nbsp;
            Email: <a href="mailto:kashifmunirbadr6620@gmail.com">kashifmunirbadr6620@gmail.com</a>
          </div>
          <button class="btn btn-gold" style="width:100%" onclick="shareAppHtml()">📤 ایپ شیئر کریں</button>
        </div>
      </section>

      <div class="card">
        <button class="btn btn-red" style="width:100%" onclick="resetAllOfflineData()">🗑️ ${isEn() ? "Reset Progress & Saved Data" : "تمام پیشرفت اور ڈیٹا صاف کریں"}</button>
      </div>
    </div>`;
  } else if (state.tab === "editor") {
    root.innerHTML = `<div class="screen-view">
      <div class="card" style="display:flex;justify-content:space-between;align-items:center">
        <b>⚙️ ${isEn() ? "Hidden Admin Editor" : "ایڈمن ایڈیٹر اسٹوڈیو"}</b>
        <button class="btn btn-outline" onclick="switchTab('home')">${isEn() ? "Done" : "واپس"}</button>
      </div>
      <div class="card">
        <input type="text" id="edAppUr" value="${escHtml(state.appNameUr)}" placeholder="App Name (Urdu)" style="margin-bottom:8px" />
        <input type="text" id="edAppEn" value="${escHtml(state.appNameEn)}" placeholder="App Name (English)" style="margin-bottom:8px" />
        <input type="text" id="edSchUr" value="${escHtml(state.schoolUr)}" placeholder="Subtitle (Urdu)" style="margin-bottom:8px" />
        <input type="text" id="edSchEn" value="${escHtml(state.schoolEn)}" placeholder="Subtitle (English)" style="margin-bottom:10px" />
        <button class="btn" style="width:100%" onclick="saveBranding()">💾 ${isEn() ? "Save Branding" : "محفوظ کریں"}</button>
      </div>
      <div class="card">
        <b>➕ ${isEn() ? "Add Custom Lesson" : "نیا سبق شامل کریں"}</b>
        <input type="text" id="nlTitUr" placeholder="${isEn() ? "Urdu Title" : "سبق کا اردو عنوان"}" style="margin:8px 0 6px" />
        <input type="text" id="nlTitEn" placeholder="${isEn() ? "English Title" : "انگریزی عنوان"}" style="margin-bottom:6px" />
        <input type="text" id="nlAr" placeholder="${isEn() ? "Arabic Text" : "عربی متن"}" style="margin-bottom:6px" />
        <input type="text" id="nlUr" placeholder="${isEn() ? "Urdu Translation" : "اردو ترجمہ"}" style="margin-bottom:6px" />
        <input type="text" id="nlEn" placeholder="${isEn() ? "English Translation" : "انگریزی ترجمہ"}" style="margin-bottom:10px" />
        <button class="btn btn-gold" style="width:100%" onclick="saveCustomLesson()">➕ ${isEn() ? "Save & Open Lesson" : "نیا سبق محفوظ کریں"}</button>
      </div>
    </div>`;
  }
}

/* ==========================================================================
   App Boot Sequence
   ========================================================================== */
document.addEventListener("DOMContentLoaded", () => {
  setupHiddenAdminTrigger();
  initQuiz(state.lessonId);
  pushNavHistory();
  render();
  setTimeout(hideSplashScreen, 550);
});
