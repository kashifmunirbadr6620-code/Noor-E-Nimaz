package com.example.util

import android.content.Context
import android.content.Intent
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.model.AppCustomization
import com.example.model.AppLanguage
import com.example.model.Lesson

object PrintShareHelper {

    fun shareLesson(
        context: Context,
        lesson: Lesson,
        language: AppLanguage = AppLanguage.URDU,
        appConfig: AppCustomization = AppCustomization()
    ) {
        val isEn = language == AppLanguage.ENGLISH
        val linesTxt = lesson.lines.joinToString("\n\n") { line ->
            val arabic = line.words.joinToString(" ") { it.ar }
            val label = if (isEn) "Translation: " else "ترجمہ: "
            "$arabic\n$label${line.fullTranslation(language)}"
        }
        val schoolTitle = appConfig.displaySchoolHeader(language)
        val shareBody = buildString {
            if (isEn) {
                appendLine("$schoolTitle - ${appConfig.displayAppTitle(language)}")
                appendLine("Lesson ${lesson.id}: ${lesson.titleEn}")
            } else {
                appendLine("$schoolTitle - ${appConfig.displayAppTitle(language)}")
                appendLine("سبق ${lesson.id}: ${lesson.titleUr} (${lesson.titleEn})")
            }
            appendLine()
            append(linesTxt)
        }

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(
                Intent.EXTRA_SUBJECT,
                if (isEn) "${appConfig.displayAppTitle(language)} - Lesson ${lesson.id}: ${lesson.titleEn}"
                else "${appConfig.displayAppTitle(language)} - سبق ${lesson.id}: ${lesson.titleUr}"
            )
            putExtra(Intent.EXTRA_TEXT, shareBody)
        }
        context.startActivity(
            Intent.createChooser(intent, if (isEn) "Share Lesson" else "سبق شیئر کریں")
        )
    }

    fun shareBackupJson(
        context: Context,
        backupJson: String,
        language: AppLanguage = AppLanguage.URDU
    ) {
        val isEn = language == AppLanguage.ENGLISH
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(
                Intent.EXTRA_SUBJECT,
                if (isEn) "Namaz Tarjuma - App & Lessons Backup"
                else "نماز ترجمہ — ایپ اور اسباق بیک اپ"
            )
            putExtra(Intent.EXTRA_TEXT, backupJson)
        }
        context.startActivity(
            Intent.createChooser(intent, if (isEn) "Export Backup" else "بیک اپ شیئر کریں")
        )
    }

    fun buildAppShareMessage(): String = """
        نورِ کاشف — ترجمانِ نماز
        بچوں، طلبہ، گھر اور مدرسے کے لیے لفظ بہ لفظ نماز ترجمہ، مسنون اذکار و نمازِ جنازہ کی آف لائن ایپ۔
        مرتب: حافظ کاشف منیر بدر
        WhatsApp: +923036620170 | Email: kashifmunirbadr6620@gmail.com
    """.trimIndent()

    fun shareApp(
        context: Context,
        language: AppLanguage = AppLanguage.URDU
    ): Boolean {
        val isEn = language == AppLanguage.ENGLISH
        val shareText = buildAppShareMessage()
        return try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "نورِ کاشف — ترجمانِ نماز")
                putExtra(Intent.EXTRA_TEXT, shareText)
            }
            val chooser = Intent.createChooser(
                intent,
                if (isEn) "Share App" else "ایپ شیئر کریں"
            )
            if (context !is android.app.Activity) {
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
            true
        } catch (_: Exception) {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
            clipboard?.setPrimaryClip(android.content.ClipData.newPlainText("Noor-e-Kashif", shareText))
            false
        }
    }

    fun openExternalUri(context: Context, uriString: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(uriString))
            if (context !is android.app.Activity) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun printLesson(
        context: Context,
        lesson: Lesson,
        language: AppLanguage = AppLanguage.URDU,
        appConfig: AppCustomization = AppCustomization(),
        onError: () -> Unit
    ) {
        try {
            val webView = WebView(context)
            webView.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
                    if (printManager == null) {
                        onError()
                        return
                    }
                    val jobName = "Namaz_Tarjuma_Lesson_${lesson.id}"
                    val printAdapter = webView.createPrintDocumentAdapter(jobName)
                    printManager.print(
                        jobName,
                        printAdapter,
                        PrintAttributes.Builder().build()
                    )
                }
            }
            val html = buildPrintableHtml(lesson, language, appConfig)
            webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
        } catch (_: Exception) {
            onError()
        }
    }

    private fun escapeHtml(input: String): String =
        input.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")

    private fun buildPrintableHtml(
        lesson: Lesson,
        language: AppLanguage,
        appConfig: AppCustomization
    ): String {
        val isEn = language == AppLanguage.ENGLISH
        val primaryHex = String.format("#%06X", 0xFFFFFF and appConfig.themePreset.primaryHex.toInt())
        val linesHtml = lesson.lines.joinToString("") { line ->
            val wordsHtml = line.words.joinToString("") { w ->
                """
                <div class="word-box">
                    <div class="word-ar">${escapeHtml(w.ar)}</div>
                    <div class="word-ur">${escapeHtml(w.meaning(language))}</div>
                </div>
                """.trimIndent()
            }
            val transPrefix = if (isEn) "Full Translation:" else "بامحاورہ ترجمہ:"
            """
            <div class="line-block">
                <div class="line-tag">${escapeHtml(line.displayLabel(language))}</div>
                <div class="words-grid">$wordsHtml</div>
                <div class="full-tarjuma"><strong>$transPrefix</strong> ${escapeHtml(line.fullTranslation(language))}</div>
            </div>
            """.trimIndent()
        }

        val lughatHtml = lesson.lughat.joinToString("") { item ->
            """
            <div class="lughat-item">
                <span class="lughat-ar">${escapeHtml(item.ar)}</span>
                <span class="lughat-ur">${escapeHtml(item.meaning(language))}</span>
            </div>
            """.trimIndent()
        }

        val dir = if (isEn) "ltr" else "rtl"
        val schoolHeader = escapeHtml(appConfig.displaySchoolHeader(language))
        val heading = if (isEn) "Lesson ${lesson.id}: ${escapeHtml(lesson.titleEn)}" else "سبق ${lesson.id}: ${escapeHtml(lesson.titleUr)} (${escapeHtml(lesson.titleEn)})"
        val lughatHead = if (isEn) "Vocabulary / Word Meanings" else "لغت / الفاظ کے معانی"

        return """
        <!DOCTYPE html>
        <html lang="${language.code}" dir="$dir">
        <head>
            <meta charset="UTF-8" />
            <style>
                body { font-family: sans-serif; color: #1A2421; padding: 16px; }
                .header { border-bottom: 3px solid $primaryHex; padding-bottom: 8px; margin-bottom: 16px; text-align: center; }
                .school { font-size: 13px; color: $primaryHex; font-weight: bold; }
                h1 { margin: 4px 0; font-size: 22px; color: $primaryHex; }
                .line-block { border: 1px solid #DCE5E1; border-radius: 10px; padding: 12px; margin-bottom: 14px; break-inside: avoid; }
                .line-tag { font-size: 12px; font-weight: bold; color: $primaryHex; margin-bottom: 8px; }
                .words-grid { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 10px; direction: rtl; }
                .word-box { border: 1px solid #DCE5E1; border-radius: 8px; padding: 6px 10px; text-align: center; min-width: 72px; }
                .word-ar { font-size: 22px; font-weight: bold; border-bottom: 1px dashed #DCE5E1; padding-bottom: 4px; }
                .word-ur { font-size: 13px; color: #B91C1C; font-weight: bold; padding-top: 4px; }
                .full-tarjuma { background: #EBF4FF; border-inline-start: 4px solid #2563EB; padding: 8px 12px; border-radius: 6px; font-size: 15px; color: #1E3A8A; }
                .lughat { border: 2px solid $primaryHex; border-radius: 10px; overflow: hidden; margin-top: 16px; break-inside: avoid; }
                .lughat-head { background: $primaryHex; color: #FFF; padding: 6px 12px; font-weight: bold; }
                .lughat-grid { display: flex; flex-wrap: wrap; }
                .lughat-item { width: 48%; padding: 6px 1%; border-bottom: 1px solid #EEE; display: flex; justify-content: space-between; }
                .lughat-ar { font-weight: bold; color: $primaryHex; font-size: 17px; }
                .lughat-ur { font-size: 13px; }
            </style>
        </head>
        <body>
            <div class="header">
                <div class="school">$schoolHeader</div>
                <h1>$heading</h1>
            </div>
            $linesHtml
            <div class="lughat">
                <div class="lughat-head">$lughatHead</div>
                <div class="lughat-grid">$lughatHtml</div>
            </div>
        </body>
        </html>
        """.trimIndent()
    }
}
