package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppCustomizationSerializer
import com.example.data.LessonRepository
import com.example.data.UserPreferencesRepository
import com.example.model.AppCustomization
import com.example.model.AppLanguage
import com.example.model.AppTab
import com.example.model.AppThemePreset
import com.example.model.AzkarSection
import com.example.model.EditorMode
import com.example.model.GlobalSearchCategory
import com.example.model.GlobalSearchMatch
import com.example.model.Lesson
import com.example.model.LessonLine
import com.example.model.LughatItem
import com.example.model.QuickQuizItem
import com.example.model.QuizQuestion
import com.example.model.SearchMatch
import com.example.model.UserProgressState
import com.example.model.WordItem
import com.example.util.AudioHelper
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class QuizUiState(
    val lessonId: Int = 1,
    val questions: List<QuizQuestion> = emptyList(),
    val currentIndex: Int = 0,
    val score: Int = 0,
    val selectedOptionIndex: Int? = null,
    val isFinished: Boolean = false
)

data class QuickQuizUiState(
    val isVisible: Boolean = false,
    val questions: List<QuickQuizItem> = emptyList(),
    val currentIndex: Int = 0,
    val score: Int = 0,
    val selectedOptionIndex: Int? = null,
    val isFinished: Boolean = false
)

data class LearnUiState(
    val lessonId: Int = 1,
    val hideTarjuma: Boolean = false,
    val memoMode: Boolean = false,
    val memoLineIndex: Int = 0,
    val inspectedWord: WordItem? = null,
    val inspectedWordId: String? = null
)

data class EditorUiState(
    val lessonId: Int = 1,
    val isNewLesson: Boolean = false,
    val isBuiltIn: Boolean = true,
    val isModified: Boolean = false,
    val titleUr: String = "",
    val titleEn: String = "",
    val romanKeys: String = "",
    val lines: List<LessonLine> = emptyList(),
    val lughat: List<LughatItem> = emptyList()
)

data class GlobalSearchUiState(
    val isOpen: Boolean = false,
    val query: String = "",
    val category: GlobalSearchCategory = GlobalSearchCategory.ALL,
    val results: List<GlobalSearchMatch> = emptyList()
)

data class AzkarFocusTarget(
    val section: AzkarSection,
    val index: Int,
    val requestId: Long
)

class NamazViewModel(application: Application) : AndroidViewModel(application) {

    private val prefsRepo = UserPreferencesRepository(application)
    private val audioHelper = AudioHelper(application)

    private val customOverrides: StateFlow<Map<Int, Lesson>> = prefsRepo.customLessonsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = emptyMap()
    )

    val lessons: StateFlow<List<Lesson>> = prefsRepo.customLessonsFlow
        .map { overrides -> LessonRepository.mergeLessons(overrides) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = LessonRepository.allLessons
        )

    val progressState: StateFlow<UserProgressState> = prefsRepo.progressFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = UserProgressState()
    )

    val appCustomization: StateFlow<AppCustomization> = prefsRepo.appCustomizationFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = AppCustomization()
    )

    private val _appEditorDraft = MutableStateFlow(AppCustomization())
    val appEditorDraft: StateFlow<AppCustomization> = _appEditorDraft.asStateFlow()

    private val _editorMode = MutableStateFlow(EditorMode.APP_EDITOR)
    val editorMode: StateFlow<EditorMode> = _editorMode.asStateFlow()

    private val _activeAzkarSection = MutableStateFlow(AzkarSection.SALAH_AZKAR)
    val activeAzkarSection: StateFlow<AzkarSection> = _activeAzkarSection.asStateFlow()

    private val _azkarFocusTarget = MutableStateFlow<AzkarFocusTarget?>(null)
    val azkarFocusTarget: StateFlow<AzkarFocusTarget?> = _azkarFocusTarget.asStateFlow()

    private val _currentTab = MutableStateFlow(AppTab.HOME)
    val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchResults = MutableStateFlow<List<SearchMatch>>(emptyList())
    val searchResults: StateFlow<List<SearchMatch>> = _searchResults.asStateFlow()

    private val _homeSearchCategory = MutableStateFlow(GlobalSearchCategory.ALL)
    val homeSearchCategory: StateFlow<GlobalSearchCategory> = _homeSearchCategory.asStateFlow()

    private val _homeGlobalSearchResults = MutableStateFlow<List<GlobalSearchMatch>>(emptyList())
    val homeGlobalSearchResults: StateFlow<List<GlobalSearchMatch>> = _homeGlobalSearchResults.asStateFlow()

    private val _globalSearchState = MutableStateFlow(GlobalSearchUiState())
    val globalSearchState: StateFlow<GlobalSearchUiState> = _globalSearchState.asStateFlow()

    private val _learnState = MutableStateFlow(LearnUiState())
    val learnState: StateFlow<LearnUiState> = _learnState.asStateFlow()

    private val _quizState = MutableStateFlow(QuizUiState())
    val quizState: StateFlow<QuizUiState> = _quizState.asStateFlow()

    private val _quickQuizState = MutableStateFlow(QuickQuizUiState())
    val quickQuizState: StateFlow<QuickQuizUiState> = _quickQuizState.asStateFlow()

    private val _editorState = MutableStateFlow(EditorUiState())
    val editorState: StateFlow<EditorUiState> = _editorState.asStateFlow()

    val isSpeaking: StateFlow<Boolean> = audioHelper.isSpeaking
    val activeSpeakingLineIndex: StateFlow<Int?> = audioHelper.activeLineIndex

    private val _toastEvents = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val toastEvents: SharedFlow<String> = _toastEvents.asSharedFlow()

    init {
        startQuizForLesson(1, switchTab = false)
        loadLessonIntoEditor(1, switchTab = false)
        viewModelScope.launch {
            prefsRepo.appCustomizationFlow.collect { savedConfig ->
                _appEditorDraft.value = savedConfig
                audioHelper.setSpeechRate(savedConfig.ttsSpeed)
            }
        }
    }

    private fun isEnglish(): Boolean = progressState.value.language == AppLanguage.ENGLISH

    fun switchTab(tab: AppTab) {
        audioHelper.stop()
        _currentTab.value = tab
    }

    fun toggleLanguage() {
        viewModelScope.launch {
            val next = prefsRepo.toggleLanguage()
            // Refresh current quiz in the newly chosen language if not yet answered
            val currentQuizLesson = _quizState.value.lessonId
            startQuizForLesson(currentQuizLesson, switchTab = false, languageOverride = next)
            _toastEvents.tryEmit(
                if (next == AppLanguage.ENGLISH) "Language switched to English"
                else "زبان اردو منتخب کر دی گئی"
            )
        }
    }

    fun toggleDarkMode() {
        viewModelScope.launch {
            val nextDark = !progressState.value.darkMode
            prefsRepo.toggleDarkMode()
            _toastEvents.tryEmit(
                if (isEnglish()) {
                    if (nextDark) "Night mode enabled" else "Day mode enabled"
                } else {
                    if (nextDark) "رات کا موڈ آن کر دیا گیا" else "دن کا موڈ آن کر دیا گیا"
                }
            )
        }
    }

    fun toggleBigFont() {
        viewModelScope.launch {
            val nextBig = !progressState.value.bigFont
            prefsRepo.toggleBigFont()
            _toastEvents.tryEmit(
                if (isEnglish()) {
                    if (nextBig) "Large font enabled" else "Normal font enabled"
                } else {
                    if (nextBig) "بڑا فونٹ آن کر دیا گیا" else "عام فونٹ کر دیا گیا"
                }
            )
        }
    }

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
        val currentLessons = lessons.value
        _searchResults.value = LessonRepository.search(query, currentLessons)
        _homeGlobalSearchResults.value = LessonRepository.searchAll(
            query = query,
            lessons = currentLessons,
            category = _homeSearchCategory.value
        )
    }

    fun onHomeSearchCategoryChange(category: GlobalSearchCategory) {
        _homeSearchCategory.value = category
        val q = _searchQuery.value
        _homeGlobalSearchResults.value = if (q.isBlank()) {
            emptyList()
        } else {
            LessonRepository.searchAll(q, lessons.value, category)
        }
    }

    fun clearSearch() {
        _searchQuery.value = ""
        _searchResults.value = emptyList()
        _homeGlobalSearchResults.value = emptyList()
    }

    fun openGlobalSearch(initialQuery: String = _searchQuery.value) {
        val currentCat = _globalSearchState.value.category
        val q = initialQuery
        _globalSearchState.value = GlobalSearchUiState(
            isOpen = true,
            query = q,
            category = currentCat,
            results = if (q.isBlank()) emptyList() else LessonRepository.searchAll(q, lessons.value, currentCat)
        )
    }

    fun closeGlobalSearch() {
        _globalSearchState.update { it.copy(isOpen = false) }
    }

    fun onGlobalSearchQueryChange(query: String) {
        val cat = _globalSearchState.value.category
        _globalSearchState.update {
            it.copy(
                query = query,
                results = LessonRepository.searchAll(query, lessons.value, cat)
            )
        }
    }

    fun onGlobalSearchCategoryChange(category: GlobalSearchCategory) {
        val q = _globalSearchState.value.query
        _globalSearchState.update {
            it.copy(
                category = category,
                results = LessonRepository.searchAll(q, lessons.value, category)
            )
        }
    }

    fun openGlobalSearchResult(match: GlobalSearchMatch) {
        closeGlobalSearch()
        val targetLessonId = match.lessonId
        val targetSection = match.azkarSection
        when {
            targetLessonId != null -> openLesson(targetLessonId)
            targetSection != null -> openAzkar(targetSection, match.azkarItemIndex)
        }
    }

    fun openLesson(lessonId: Int) {
        audioHelper.stop()
        val all = lessons.value
        val target = LessonRepository.getLesson(lessonId, all)
        _learnState.update {
            it.copy(
                lessonId = target.id,
                memoLineIndex = 0,
                inspectedWord = null,
                inspectedWordId = null
            )
        }
        _currentTab.value = AppTab.LEARN
        viewModelScope.launch {
            prefsRepo.setLastLessonId(target.id)
        }
    }

    fun prevLesson() {
        val all = lessons.value
        val idx = all.indexOfFirst { it.id == _learnState.value.lessonId }
        val prevIdx = if (idx > 0) idx - 1 else all.lastIndex
        openLesson(all[prevIdx].id)
    }

    fun nextLesson() {
        val all = lessons.value
        val idx = all.indexOfFirst { it.id == _learnState.value.lessonId }
        val nextIdx = if (idx in 0 until all.lastIndex) idx + 1 else 0
        openLesson(all[nextIdx].id)
    }

    fun toggleHideTarjuma() {
        _learnState.update { it.copy(hideTarjuma = !it.hideTarjuma) }
    }

    fun toggleMemoMode() {
        _learnState.update {
            it.copy(
                memoMode = !it.memoMode,
                memoLineIndex = 0
            )
        }
    }

    fun changeMemoLine(delta: Int) {
        val lesson = LessonRepository.getLesson(_learnState.value.lessonId, lessons.value)
        val total = lesson.lines.size.coerceAtLeast(1)
        _learnState.update {
            val nextIdx = ((it.memoLineIndex + delta) % total + total) % total
            it.copy(memoLineIndex = nextIdx)
        }
    }

    fun toggleCurrentLessonComplete() {
        toggleLessonComplete(_learnState.value.lessonId)
    }

    fun toggleLessonComplete(lessonId: Int) {
        viewModelScope.launch {
            val completed = prefsRepo.toggleLessonComplete(lessonId)
            _toastEvents.tryEmit(
                if (isEnglish()) {
                    if (completed) "MashaAllah! Lesson marked complete ✓" else "Lesson completion unmarked"
                } else {
                    if (completed) "ماشاء اللہ! سبق مکمل نشان زد ہو گیا ✓" else "سبق مکمل نشان ہٹا دیا گیا"
                }
            )
        }
    }

    fun inspectWord(word: WordItem, wordId: String) {
        _learnState.update {
            it.copy(inspectedWord = word, inspectedWordId = wordId)
        }
        audioHelper.speak(word.ar, lineIndex = null, silentIfUnavailable = true)
    }

    fun speakInspectedWord() {
        val word = _learnState.value.inspectedWord ?: return
        audioHelper.speak(word.ar, lineIndex = null, silentIfUnavailable = false) {
            _toastEvents.tryEmit(
                if (isEnglish()) "Arabic TTS voice is unavailable on this device — read the pronunciation guide."
                else "آپ کے ڈیوائس میں عربی آواز دستیاب نہیں — تلفظ دیکھ کر پڑھیں۔"
            )
        }
    }

    fun closeInspector() {
        _learnState.update {
            it.copy(inspectedWord = null, inspectedWordId = null)
        }
    }

    fun toggleLessonAudio() {
        if (audioHelper.isSpeaking.value) {
            audioHelper.stop()
            return
        }
        val lesson = LessonRepository.getLesson(_learnState.value.lessonId, lessons.value)
        val fullArabic = lesson.lines.joinToString(" . ") { line ->
            line.words.joinToString(" ") { it.ar }
        }
        audioHelper.speak(fullArabic, lineIndex = -1, silentIfUnavailable = false) {
            _toastEvents.tryEmit(
                if (isEnglish()) "Arabic TTS voice is not installed — please follow the pronunciation text."
                else "آپ کے ڈیوائس میں عربی آواز انسٹال نہیں — تلفظ دیکھ کر پڑھیں۔"
            )
        }
    }

    fun speakLine(arabicText: String, lineIndex: Int) {
        audioHelper.speak(arabicText, lineIndex = lineIndex, silentIfUnavailable = false) {
            _toastEvents.tryEmit(
                if (isEnglish()) "Arabic TTS voice is not installed — please follow the pronunciation text."
                else "آپ کے ڈیوائس میں عربی آواز انسٹال نہیں — تلفظ دیکھ کر پڑھیں۔"
            )
        }
    }

    fun openAzkar(section: AzkarSection = AzkarSection.SALAH_AZKAR, itemIndex: Int? = null) {
        audioHelper.stop()
        _activeAzkarSection.value = section
        if (itemIndex != null && itemIndex >= 0) {
            _azkarFocusTarget.value = AzkarFocusTarget(
                section = section,
                index = itemIndex,
                requestId = System.currentTimeMillis()
            )
        }
        _currentTab.value = AppTab.AZKAR
    }

    fun selectAzkarSection(section: AzkarSection) {
        _activeAzkarSection.value = section
    }

    fun speakAzkarText(arabicText: String) {
        audioHelper.speak(arabicText, lineIndex = null, silentIfUnavailable = false) {
            _toastEvents.tryEmit(
                if (isEnglish()) "Arabic TTS voice is not installed — please follow the Arabic text."
                else "آپ کے ڈیوائس میں عربی آواز انسٹال نہیں — عربی متن دیکھ کر پڑھیں۔"
            )
        }
    }

    fun stopAudio() {
        audioHelper.stop()
    }

    fun incrementTasbeeh() {
        viewModelScope.launch {
            val next = prefsRepo.incrementTasbeehCount()
            if (next == 100) {
                _toastEvents.tryEmit(
                    if (isEnglish()) "MashaAllah! Tasbeeh-e-Fatimi (100) completed!"
                    else "ماشاء اللہ! تسبیحِ فاطمی (۱۰۰ بار) مکمل ہو گئی ✓"
                )
            }
        }
    }

    fun resetTasbeeh() {
        viewModelScope.launch {
            prefsRepo.resetTasbeehCount()
            _toastEvents.tryEmit(
                if (isEnglish()) "Tasbeeh counter reset"
                else "تسبیح کاؤنٹر صفر کر دیا گیا"
            )
        }
    }

    fun startQuizForLesson(
        lessonId: Int,
        switchTab: Boolean = true,
        languageOverride: AppLanguage? = null
    ) {
        audioHelper.stop()
        val all = lessons.value
        val lesson = LessonRepository.getLesson(lessonId, all)
        val lang = languageOverride ?: progressState.value.language
        val questions = LessonRepository.build10QuestionsForLesson(lesson, all, lang)
        _quizState.value = QuizUiState(
            lessonId = lesson.id,
            questions = questions,
            currentIndex = 0,
            score = 0,
            selectedOptionIndex = null,
            isFinished = false
        )
        if (switchTab) {
            _currentTab.value = AppTab.QUIZ
        }
    }

    fun selectQuizAnswer(optionIndex: Int) {
        val current = _quizState.value
        if (current.selectedOptionIndex != null || current.isFinished) return
        val q = current.questions.getOrNull(current.currentIndex) ?: return
        val isCorrect = optionIndex == q.ans
        _quizState.update {
            it.copy(
                selectedOptionIndex = optionIndex,
                score = if (isCorrect) it.score + 1 else it.score
            )
        }
    }

    fun nextQuizQuestion() {
        val current = _quizState.value
        val nextIdx = current.currentIndex + 1
        if (nextIdx >= current.questions.size) {
            _quizState.update { it.copy(isFinished = true) }
            viewModelScope.launch {
                prefsRepo.saveQuizResult(current.lessonId, current.score)
            }
        } else {
            _quizState.update {
                it.copy(
                    currentIndex = nextIdx,
                    selectedOptionIndex = null
                )
            }
        }
    }

    fun startQuickQuiz(languageOverride: AppLanguage? = null) {
        audioHelper.stop()
        val lang = languageOverride ?: progressState.value.language
        val selected = LessonRepository.buildQuickQuizQuestions(
            lessons = lessons.value,
            language = lang,
            count = 5
        )
        _quickQuizState.value = QuickQuizUiState(
            isVisible = true,
            questions = selected,
            currentIndex = 0,
            score = 0,
            selectedOptionIndex = null,
            isFinished = false
        )
    }

    fun selectQuickQuizAnswer(optionIndex: Int) {
        val current = _quickQuizState.value
        if (!current.isVisible || current.selectedOptionIndex != null || current.isFinished) return
        val item = current.questions.getOrNull(current.currentIndex) ?: return
        val isCorrect = optionIndex == item.question.ans
        _quickQuizState.update {
            it.copy(
                selectedOptionIndex = optionIndex,
                score = if (isCorrect) it.score + 1 else it.score
            )
        }
    }

    fun nextQuickQuizQuestion() {
        val current = _quickQuizState.value
        val nextIdx = current.currentIndex + 1
        if (nextIdx >= current.questions.size) {
            _quickQuizState.update { it.copy(isFinished = true) }
        } else {
            _quickQuizState.update {
                it.copy(
                    currentIndex = nextIdx,
                    selectedOptionIndex = null
                )
            }
        }
    }

    fun dismissQuickQuiz() {
        _quickQuizState.update { it.copy(isVisible = false) }
    }

    fun resetProgress() {
        viewModelScope.launch {
            prefsRepo.resetAllProgress()
            _toastEvents.tryEmit(
                if (isEnglish()) "All progress records cleared."
                else "تمام ریکارڈ صاف کر دیا گیا ہے۔"
            )
        }
    }

    fun switchEditorMode(mode: EditorMode) {
        _editorMode.value = mode
    }

    fun updateAppBrandingDraft(
        schoolNameUr: String = _appEditorDraft.value.schoolNameUr,
        schoolNameEn: String = _appEditorDraft.value.schoolNameEn,
        appTitleUr: String = _appEditorDraft.value.appTitleUr,
        appTitleEn: String = _appEditorDraft.value.appTitleEn,
        heroSubtitleUr: String = _appEditorDraft.value.heroSubtitleUr,
        heroSubtitleEn: String = _appEditorDraft.value.heroSubtitleEn
    ) {
        _appEditorDraft.update {
            it.copy(
                schoolNameUr = schoolNameUr,
                schoolNameEn = schoolNameEn,
                appTitleUr = appTitleUr,
                appTitleEn = appTitleEn,
                heroSubtitleUr = heroSubtitleUr,
                heroSubtitleEn = heroSubtitleEn
            )
        }
    }

    fun saveAppBranding() {
        val draft = _appEditorDraft.value
        val cleaned = draft.copy(
            schoolNameUr = draft.schoolNameUr.trim().ifEmpty { AppCustomization.DEFAULT_SCHOOL_UR },
            schoolNameEn = draft.schoolNameEn.trim().ifEmpty { AppCustomization.DEFAULT_SCHOOL_EN },
            appTitleUr = draft.appTitleUr.trim().ifEmpty { AppCustomization.DEFAULT_APP_TITLE_UR },
            appTitleEn = draft.appTitleEn.trim().ifEmpty { AppCustomization.DEFAULT_APP_TITLE_EN },
            heroSubtitleUr = draft.heroSubtitleUr.trim().ifEmpty { AppCustomization.DEFAULT_HERO_SUBTITLE_UR },
            heroSubtitleEn = draft.heroSubtitleEn.trim().ifEmpty { AppCustomization.DEFAULT_HERO_SUBTITLE_EN }
        )
        _appEditorDraft.value = cleaned
        viewModelScope.launch {
            prefsRepo.saveAppCustomization(cleaned)
            _toastEvents.tryEmit(
                if (isEnglish()) "App branding saved ✓"
                else "اسکول اور ایپ کا نام محفوظ ہو گیا ✓"
            )
        }
    }

    fun selectThemePreset(preset: AppThemePreset) {
        val updated = _appEditorDraft.value.copy(themePreset = preset)
        _appEditorDraft.value = updated
        viewModelScope.launch {
            prefsRepo.saveAppCustomization(updated)
            _toastEvents.tryEmit(
                if (isEnglish()) "Theme updated: ${preset.titleEn}"
                else "تھیم تبدیل ہو گئی: ${preset.titleUr}"
            )
        }
    }

    fun updateFontScale(scale: Float) {
        val safe = scale.coerceIn(0.85f, 1.35f)
        val updated = _appEditorDraft.value.copy(fontScale = safe)
        _appEditorDraft.value = updated
        viewModelScope.launch {
            prefsRepo.saveAppCustomization(updated)
        }
    }

    fun updateTtsSpeed(speed: Float) {
        val safe = speed.coerceIn(0.6f, 1.15f)
        audioHelper.setSpeechRate(safe)
        val updated = _appEditorDraft.value.copy(ttsSpeed = safe)
        _appEditorDraft.value = updated
        viewModelScope.launch {
            prefsRepo.saveAppCustomization(updated)
            _toastEvents.tryEmit(
                if (isEnglish()) "Audio speed updated"
                else "تلاوت کی رفتار محفوظ ہو گئی"
            )
        }
    }

    fun toggleShowPronunciationInBoxes() {
        val updated = _appEditorDraft.value.copy(
            showPronunciationInBoxes = !_appEditorDraft.value.showPronunciationInBoxes
        )
        _appEditorDraft.value = updated
        viewModelScope.launch {
            prefsRepo.saveAppCustomization(updated)
        }
    }

    fun toggleShowSecondaryTitle() {
        val updated = _appEditorDraft.value.copy(
            showSecondaryTitle = !_appEditorDraft.value.showSecondaryTitle
        )
        _appEditorDraft.value = updated
        viewModelScope.launch {
            prefsRepo.saveAppCustomization(updated)
        }
    }

    fun buildFullBackupJson(): String =
        AppCustomizationSerializer.encodeFullBackup(
            config = appCustomization.value,
            customLessons = customOverrides.value
        )

    fun importBackupJson(rawJson: String) {
        val payload = AppCustomizationSerializer.decodeFullBackup(rawJson)
        if (payload == null) {
            _toastEvents.tryEmit(
                if (isEnglish()) "Invalid backup JSON format."
                else "غلط بیک اپ JSON فارمیٹ — دوبارہ چیک کریں۔"
            )
            return
        }
        viewModelScope.launch {
            prefsRepo.importBackup(payload.appCustomization, payload.customLessons)
            payload.appCustomization?.let { audioHelper.setSpeechRate(it.ttsSpeed) }
            _toastEvents.tryEmit(
                if (isEnglish()) "Backup imported successfully ✓"
                else "بیک اپ کامیابی سے بحال ہو گیا ✓"
            )
        }
    }

    fun resetAppCustomizationDefaults() {
        viewModelScope.launch {
            prefsRepo.resetAppCustomization()
            audioHelper.setSpeechRate(AppCustomization().ttsSpeed)
            _toastEvents.tryEmit(
                if (isEnglish()) "App customization reset to GRS Memorial default"
                else "ایپ کی تمام ترتیبات اصل حالت پر بحال ہو گئیں"
            )
        }
    }

    // =========================================================================
    // LESSON EDITOR ACTIONS
    // =========================================================================
    fun loadLessonIntoEditor(lessonId: Int, switchTab: Boolean = true) {
        val all = lessons.value
        val lesson = LessonRepository.getLesson(lessonId, all)
        val isBuiltIn = LessonRepository.isBuiltInLesson(lesson.id)
        val isModified = isBuiltIn && customOverrides.value.containsKey(lesson.id)
        _editorState.value = EditorUiState(
            lessonId = lesson.id,
            isNewLesson = false,
            isBuiltIn = isBuiltIn,
            isModified = isModified,
            titleUr = lesson.titleUr,
            titleEn = lesson.titleEn,
            romanKeys = lesson.romanKeys,
            lines = lesson.lines,
            lughat = lesson.lughat
        )
        if (switchTab) {
            audioHelper.stop()
            _editorMode.value = EditorMode.LESSON_EDITOR
            _currentTab.value = AppTab.EDITOR
        }
    }

    fun startNewLessonInEditor() {
        val nextId = (lessons.value.maxOfOrNull { it.id } ?: 14) + 1
        _editorState.value = EditorUiState(
            lessonId = nextId,
            isNewLesson = true,
            isBuiltIn = false,
            isModified = false,
            titleUr = "",
            titleEn = "",
            romanKeys = "",
            lines = listOf(
                LessonLine(
                    label = "سطر ۱",
                    words = listOf(WordItem(ar = "", ur = "", pron = "", en = "")),
                    fullUr = "",
                    labelEn = "Line 1",
                    fullEn = ""
                )
            ),
            lughat = listOf(LughatItem(ar = "", ur = "", en = ""))
        )
        audioHelper.stop()
        _currentTab.value = AppTab.EDITOR
    }

    fun updateEditorTitleUr(value: String) {
        _editorState.update { it.copy(titleUr = value) }
    }

    fun updateEditorTitleEn(value: String) {
        _editorState.update { it.copy(titleEn = value) }
    }

    fun updateEditorRomanKeys(value: String) {
        _editorState.update { it.copy(romanKeys = value) }
    }

    fun updateEditorLineLabel(lineIdx: Int, label: String) {
        _editorState.update { state ->
            val updated = state.lines.mapIndexed { idx, line ->
                if (idx == lineIdx) line.copy(label = label) else line
            }
            state.copy(lines = updated)
        }
    }

    fun updateEditorLineFullUr(lineIdx: Int, fullUr: String) {
        _editorState.update { state ->
            val updated = state.lines.mapIndexed { idx, line ->
                if (idx == lineIdx) line.copy(fullUr = fullUr) else line
            }
            state.copy(lines = updated)
        }
    }

    fun updateEditorLineFullEn(lineIdx: Int, fullEn: String) {
        _editorState.update { state ->
            val updated = state.lines.mapIndexed { idx, line ->
                if (idx == lineIdx) line.copy(fullEn = fullEn) else line
            }
            state.copy(lines = updated)
        }
    }

    fun addEditorLine() {
        _editorState.update { state ->
            val nextNum = state.lines.size + 1
            val newLine = LessonLine(
                label = "سطر $nextNum",
                words = listOf(WordItem(ar = "", ur = "", pron = "", en = "")),
                fullUr = "",
                labelEn = "Line $nextNum",
                fullEn = ""
            )
            state.copy(lines = state.lines + newLine)
        }
    }

    fun removeEditorLine(lineIdx: Int) {
        _editorState.update { state ->
            if (state.lines.size <= 1) return@update state
            state.copy(lines = state.lines.filterIndexed { idx, _ -> idx != lineIdx })
        }
    }

    fun updateEditorWord(
        lineIdx: Int,
        wordIdx: Int,
        ar: String,
        ur: String,
        en: String,
        pron: String
    ) {
        _editorState.update { state ->
            val updatedLines = state.lines.mapIndexed { idx, line ->
                if (idx == lineIdx) {
                    val updatedWords = line.words.mapIndexed { wIdx, w ->
                        if (wIdx == wordIdx) WordItem(ar = ar, ur = ur, pron = pron, en = en) else w
                    }
                    line.copy(words = updatedWords)
                } else {
                    line
                }
            }
            state.copy(lines = updatedLines)
        }
    }

    fun addEditorWord(lineIdx: Int) {
        _editorState.update { state ->
            val updatedLines = state.lines.mapIndexed { idx, line ->
                if (idx == lineIdx) {
                    line.copy(words = line.words + WordItem(ar = "", ur = "", pron = "", en = ""))
                } else {
                    line
                }
            }
            state.copy(lines = updatedLines)
        }
    }

    fun removeEditorWord(lineIdx: Int, wordIdx: Int) {
        _editorState.update { state ->
            val updatedLines = state.lines.mapIndexed { idx, line ->
                if (idx == lineIdx && line.words.size > 1) {
                    line.copy(words = line.words.filterIndexed { wIdx, _ -> wIdx != wordIdx })
                } else {
                    line
                }
            }
            state.copy(lines = updatedLines)
        }
    }

    fun updateEditorLughat(index: Int, ar: String, ur: String, en: String) {
        _editorState.update { state ->
            val updated = state.lughat.mapIndexed { idx, item ->
                if (idx == index) LughatItem(ar = ar, ur = ur, en = en) else item
            }
            state.copy(lughat = updated)
        }
    }

    fun addEditorLughat() {
        _editorState.update { state ->
            state.copy(lughat = state.lughat + LughatItem(ar = "", ur = "", en = ""))
        }
    }

    fun removeEditorLughat(index: Int) {
        _editorState.update { state ->
            state.copy(lughat = state.lughat.filterIndexed { idx, _ -> idx != index })
        }
    }

    fun saveEditedLesson(openInLearn: Boolean = false) {
        val state = _editorState.value
        val cleanTitleUr = state.titleUr.trim()
        val cleanTitleEn = state.titleEn.trim()
        if (cleanTitleUr.isEmpty() && cleanTitleEn.isEmpty()) {
            _toastEvents.tryEmit(
                if (isEnglish()) "Please enter a lesson title."
                else "براہ کرم سبق کا عنوان درج کریں۔"
            )
            return
        }

        val cleanedLines = state.lines.mapIndexed { idx, line ->
            val validWords = line.words
                .map { WordItem(it.ar.trim(), it.ur.trim(), it.pron.trim(), it.en.trim()) }
                .filter { it.ar.isNotEmpty() || it.ur.isNotEmpty() || it.en.isNotEmpty() }
            LessonLine(
                label = line.label.trim().ifEmpty { "سطر ${idx + 1}" },
                words = validWords.ifEmpty { listOf(WordItem("—", "—", "", "—")) },
                fullUr = line.fullUr.trim(),
                labelEn = line.labelEn.trim().ifEmpty { "Line ${idx + 1}" },
                fullEn = line.fullEn.trim()
            )
        }.filter { it.words.isNotEmpty() }

        if (cleanedLines.isEmpty()) {
            _toastEvents.tryEmit(
                if (isEnglish()) "Please add at least one Arabic word and meaning."
                else "کم از کم ایک عربی لفظ اور ترجمہ شامل کریں۔"
            )
            return
        }

        val cleanedLughat = state.lughat
            .map { LughatItem(it.ar.trim(), it.ur.trim(), it.en.trim()) }
            .filter { it.ar.isNotEmpty() && (it.ur.isNotEmpty() || it.en.isNotEmpty()) }

        val existingLesson = lessons.value.find { it.id == state.lessonId }
        val lessonToSave = Lesson(
            id = state.lessonId,
            titleUr = cleanTitleUr.ifEmpty { cleanTitleEn },
            titleEn = cleanTitleEn.ifEmpty { "Lesson ${state.lessonId}" },
            romanKeys = state.romanKeys.trim(),
            lines = cleanedLines,
            lughat = cleanedLughat.ifEmpty {
                cleanedLines.flatMap { it.words }
                    .filter { it.ar.isNotBlank() && (it.ur.isNotBlank() || it.en.isNotBlank()) }
                    .take(8)
                    .map { LughatItem(it.ar, it.ur.ifBlank { it.en }, it.en.ifBlank { it.ur }) }
            },
            customQuiz = existingLesson?.customQuiz,
            isCustom = !state.isBuiltIn
        )

        viewModelScope.launch {
            prefsRepo.saveCustomLesson(lessonToSave)
            _editorState.update {
                it.copy(
                    isNewLesson = false,
                    isModified = state.isBuiltIn,
                    titleUr = lessonToSave.titleUr,
                    titleEn = lessonToSave.titleEn,
                    romanKeys = lessonToSave.romanKeys,
                    lines = lessonToSave.lines,
                    lughat = lessonToSave.lughat
                )
            }
            val updatedList = LessonRepository.mergeLessons(customOverrides.value + (lessonToSave.id to lessonToSave))
            if (_searchQuery.value.isNotBlank()) {
                _searchResults.value = LessonRepository.search(_searchQuery.value, updatedList)
                _homeGlobalSearchResults.value = LessonRepository.searchAll(
                    _searchQuery.value,
                    updatedList,
                    _homeSearchCategory.value
                )
            }
            if (_globalSearchState.value.query.isNotBlank()) {
                val gs = _globalSearchState.value
                _globalSearchState.value = gs.copy(
                    results = LessonRepository.searchAll(gs.query, updatedList, gs.category)
                )
            }
            _toastEvents.tryEmit(
                if (isEnglish()) "Lesson saved successfully ✓"
                else "سبق کامیابی سے محفوظ ہو گیا ✓"
            )
            if (openInLearn) {
                openLesson(lessonToSave.id)
            }
        }
    }

    fun resetBuiltInLessonToDefault() {
        val state = _editorState.value
        if (!state.isBuiltIn) return
        viewModelScope.launch {
            prefsRepo.removeCustomLesson(state.lessonId)
            val original = LessonRepository.getLesson(state.lessonId, LessonRepository.allLessons)
            _editorState.value = EditorUiState(
                lessonId = original.id,
                isNewLesson = false,
                isBuiltIn = true,
                isModified = false,
                titleUr = original.titleUr,
                titleEn = original.titleEn,
                romanKeys = original.romanKeys,
                lines = original.lines,
                lughat = original.lughat
            )
            _toastEvents.tryEmit(
                if (isEnglish()) "Lesson restored to default"
                else "سبق اپنی اصل حالت میں بحال ہو گیا"
            )
        }
    }

    fun deleteCustomLesson() {
        val state = _editorState.value
        if (state.isBuiltIn) return
        viewModelScope.launch {
            prefsRepo.removeCustomLesson(state.lessonId)
            if (_learnState.value.lessonId == state.lessonId) {
                _learnState.update { it.copy(lessonId = 1, memoLineIndex = 0) }
            }
            loadLessonIntoEditor(1, switchTab = false)
            _toastEvents.tryEmit(
                if (isEnglish()) "Custom lesson deleted"
                else "نیا سبق حذف کر دیا گیا"
            )
        }
    }

    fun saveDailyReminder(enabled: Boolean, hour: Int, minute: Int) {
        val safeHour = hour.coerceIn(0, 23)
        val safeMinute = minute.coerceIn(0, 59)
        val appContext = getApplication<Application>()
        viewModelScope.launch {
            prefsRepo.setDailyReminder(enabled = enabled, hour = safeHour, minute = safeMinute)
            if (enabled) {
                com.example.util.StudyReminderHelper.scheduleDailyReminder(appContext, safeHour, safeMinute)
                val formatted = com.example.util.StudyReminderHelper.formatTimeDisplay(
                    safeHour,
                    safeMinute,
                    progressState.value.language
                )
                _toastEvents.tryEmit(
                    if (isEnglish()) "Daily reminder set for $formatted"
                    else "روزانہ سبق کی یاددہانی $formatted پر سیٹ کر دی گئی"
                )
            } else {
                com.example.util.StudyReminderHelper.cancelDailyReminder(appContext)
                _toastEvents.tryEmit(
                    if (isEnglish()) "Daily study reminder turned off"
                    else "روزانہ سبق کی یاددہانی بند کر دی گئی"
                )
            }
        }
    }

    fun sendTestStudyReminder() {
        val appContext = getApplication<Application>()
        val progress = progressState.value
        val all = lessons.value
        val activeIds = all.map { it.id }.toSet()
        val doneCount = progress.completedLessons.count { it in activeIds }
        val nextTitle = com.example.util.StudyReminderHelper.pickNextLessonTitle(
            lessons = all,
            completedLessons = progress.completedLessons,
            lastLessonId = progress.lastLessonId,
            language = progress.language
        )
        val posted = com.example.util.StudyReminderHelper.showStudyReminderNotification(
            context = appContext,
            completedCount = doneCount,
            totalCount = all.size,
            nextLessonTitle = nextTitle,
            language = progress.language
        )
        _toastEvents.tryEmit(
            if (posted) {
                if (isEnglish()) "Test reminder notification sent!"
                else "ٹیسٹ یاددہانی نوٹیفکیشن بھیج دیا گیا!"
            } else {
                if (isEnglish()) "Please allow notifications to receive study reminders."
                else "یاددہانی کے لیے براہِ کرم نوٹیفکیشن کی اجازت دیں۔"
            }
        )
    }

    fun emitToast(message: String) {
        _toastEvents.tryEmit(message)
    }

    override fun onCleared() {
        super.onCleared()
        audioHelper.release()
    }
}
