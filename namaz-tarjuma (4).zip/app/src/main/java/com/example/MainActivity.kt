package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Quiz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.LessonRepository
import com.example.model.AppLanguage
import com.example.model.AppTab
import com.example.ui.NamazViewModel
import com.example.ui.ProvideSafeTextToolbar
import com.example.ui.appStrings
import com.example.ui.components.AboutModal
import com.example.ui.components.GlobalSearchModal
import com.example.ui.components.QuickQuizModal
import com.example.ui.components.StudyReminderModal
import com.example.ui.components.TopAppHeader
import com.example.ui.rememberDismissTextControls
import com.example.ui.screens.AzkarScreen
import com.example.ui.screens.EditorScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LearnScreen
import com.example.ui.screens.ProgressScreen
import com.example.ui.screens.QuizScreen
import com.example.ui.theme.LocalNamazColors
import com.example.ui.theme.NamazTarjumaTheme
import com.example.ui.theme.RomanFontFamily
import com.example.ui.theme.UrduFontFamily
import com.example.util.PrintShareHelper

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ProvideSafeTextToolbar {
                NamazTarjumaApp()
            }
        }
    }
}

private data class NavDestinationItem(
    val tab: AppTab,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

@Composable
fun NamazTarjumaApp(viewModel: NamazViewModel = viewModel()) {
    val progress by viewModel.progressState.collectAsStateWithLifecycle()
    val appConfig by viewModel.appCustomization.collectAsStateWithLifecycle()
    val appDraftConfig by viewModel.appEditorDraft.collectAsStateWithLifecycle()
    val editorMode by viewModel.editorMode.collectAsStateWithLifecycle()
    val allLessons by viewModel.lessons.collectAsStateWithLifecycle()
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val activeAzkarSection by viewModel.activeAzkarSection.collectAsStateWithLifecycle()
    val azkarFocusTarget by viewModel.azkarFocusTarget.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val homeSearchCategory by viewModel.homeSearchCategory.collectAsStateWithLifecycle()
    val homeGlobalSearchResults by viewModel.homeGlobalSearchResults.collectAsStateWithLifecycle()
    val globalSearchState by viewModel.globalSearchState.collectAsStateWithLifecycle()
    val learnState by viewModel.learnState.collectAsStateWithLifecycle()
    val quizState by viewModel.quizState.collectAsStateWithLifecycle()
    val quickQuizState by viewModel.quickQuizState.collectAsStateWithLifecycle()
    val editorState by viewModel.editorState.collectAsStateWithLifecycle()
    val isSpeaking by viewModel.isSpeaking.collectAsStateWithLifecycle()
    val activeSpeakingLineIndex by viewModel.activeSpeakingLineIndex.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val dismissTextControls = rememberDismissTextControls()
    val language = progress.language
    val strings = remember(language) { appStrings(language) }
    val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily
    val layoutDirection = if (language == AppLanguage.ENGLISH) LayoutDirection.Ltr else LayoutDirection.Rtl

    LaunchedEffect(Unit) {
        viewModel.toastEvents.collect { msg ->
            snackbarHostState.currentSnackbarData?.dismiss()
            snackbarHostState.showSnackbar(msg)
        }
    }

    DisposableEffect(lifecycleOwner, dismissTextControls) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE || event == Lifecycle.Event.ON_STOP) {
                dismissTextControls()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            dismissTextControls()
        }
    }

    BackHandler(enabled = currentTab != AppTab.HOME) {
        dismissTextControls()
        viewModel.switchTab(AppTab.HOME)
    }

    var adminTapCount by remember { mutableIntStateOf(0) }
    var lastAdminTapMs by remember { mutableLongStateOf(0L) }
    var showAdminPasswordDialog by remember { mutableStateOf(false) }
    var adminPinInput by remember { mutableStateOf("") }
    var adminPinError by remember { mutableStateOf(false) }
    var showAboutModal by remember { mutableStateOf(false) }
    var showReminderModal by remember { mutableStateOf(false) }

    val quickReminderPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted || com.example.util.StudyReminderHelper.hasNotificationPermission(context)) {
            viewModel.saveDailyReminder(true, progress.reminderHour, progress.reminderMinute)
        } else {
            showReminderModal = true
            viewModel.emitToast(strings.reminderPermissionNeeded)
        }
    }

    val handleHeaderTitleTap: () -> Unit = {
        val now = System.currentTimeMillis()
        if (now - lastAdminTapMs > 2000L) {
            adminTapCount = 1
        } else {
            adminTapCount += 1
        }
        lastAdminTapMs = now
        if (adminTapCount >= 5) {
            adminTapCount = 0
            lastAdminTapMs = 0L
            dismissTextControls()
            adminPinInput = ""
            adminPinError = false
            showAdminPasswordDialog = true
        }
    }

    val navItems = remember(strings) {
        listOf(
            NavDestinationItem(AppTab.HOME, strings.navHome, Icons.Filled.Home, Icons.Outlined.Home, "nav_home"),
            NavDestinationItem(AppTab.LEARN, strings.navLearn, Icons.AutoMirrored.Filled.MenuBook, Icons.AutoMirrored.Outlined.MenuBook, "nav_learn"),
            NavDestinationItem(AppTab.QUIZ, strings.navQuiz, Icons.Filled.Quiz, Icons.Outlined.Quiz, "nav_quiz"),
            NavDestinationItem(AppTab.PROGRESS, strings.navProgress, Icons.Filled.EmojiEvents, Icons.Outlined.EmojiEvents, "nav_progress")
        )
    }

    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
        NamazTarjumaTheme(
            darkTheme = progress.darkMode,
            bigFont = progress.bigFont,
            themePreset = appConfig.themePreset,
            fontScale = appConfig.fontScale
        ) {
            val extended = LocalNamazColors.current
            val currentLesson = remember(learnState.lessonId, allLessons) {
                LessonRepository.getLesson(learnState.lessonId, allLessons)
            }

            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val useNavRail = maxWidth >= 840.dp

                Scaffold(
                    containerColor = MaterialTheme.colorScheme.background,
                    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                    topBar = {
                        TopAppHeader(
                            language = language,
                            strings = strings,
                            appConfig = appConfig,
                            darkMode = progress.darkMode,
                            bigFont = progress.bigFont,
                            onToggleLanguage = {
                                dismissTextControls()
                                viewModel.toggleLanguage()
                            },
                            onToggleBigFont = viewModel::toggleBigFont,
                            onToggleDarkMode = viewModel::toggleDarkMode,
                            onOpenGlobalSearch = {
                                dismissTextControls()
                                viewModel.openGlobalSearch()
                            },
                            onHeaderTitleTap = handleHeaderTitleTap
                        )
                    },
                    bottomBar = {
                        if (!useNavRail) {
                            Column {
                                HorizontalDivider(color = extended.gold, thickness = 2.dp)
                                NavigationBar(
                                    containerColor = extended.cardSurface
                                ) {
                                    navItems.forEach { item ->
                                        val selected = currentTab == item.tab
                                        NavigationBarItem(
                                            selected = selected,
                                            onClick = {
                                                dismissTextControls()
                                                viewModel.switchTab(item.tab)
                                            },
                                            icon = {
                                                Icon(
                                                    imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                                    contentDescription = item.label
                                                )
                                            },
                                            label = {
                                                Text(
                                                    text = item.label,
                                                    fontFamily = uiFont,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                                    maxLines = 1
                                                )
                                            },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = extended.arabicAccent,
                                                selectedTextColor = extended.arabicAccent,
                                                indicatorColor = extended.greenSurface,
                                                unselectedIconColor = extended.mutedText,
                                                unselectedTextColor = extended.mutedText
                                            ),
                                            modifier = Modifier.testTag(item.testTag)
                                        )
                                    }
                                }
                            }
                        }
                    }
                ) { innerPadding ->
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        if (useNavRail) {
                            NavigationRail(
                                containerColor = extended.cardSurface,
                                modifier = Modifier.fillMaxHeight()
                            ) {
                                navItems.forEach { item ->
                                    val selected = currentTab == item.tab
                                    NavigationRailItem(
                                        selected = selected,
                                        onClick = {
                                            dismissTextControls()
                                            viewModel.switchTab(item.tab)
                                        },
                                        icon = {
                                            Icon(
                                                imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                                contentDescription = item.label
                                            )
                                        },
                                        label = {
                                            Text(
                                                text = item.label,
                                                fontFamily = uiFont,
                                                fontSize = 11.sp,
                                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                            )
                                        },
                                        colors = NavigationRailItemDefaults.colors(
                                            selectedIconColor = extended.arabicAccent,
                                            selectedTextColor = extended.arabicAccent,
                                            indicatorColor = extended.greenSurface,
                                            unselectedIconColor = extended.mutedText,
                                            unselectedTextColor = extended.mutedText
                                        ),
                                        modifier = Modifier.testTag(item.testTag)
                                    )
                                }
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight(),
                            contentAlignment = Alignment.TopCenter
                        ) {
                            val contentModifier = Modifier
                                .fillMaxWidth()
                                .widthIn(max = 960.dp)
                                .fillMaxHeight()

                            when (currentTab) {
                                AppTab.HOME -> HomeScreen(
                                    language = language,
                                    strings = strings,
                                    appConfig = appConfig,
                                    lessons = allLessons,
                                    progress = progress,
                                    searchQuery = searchQuery,
                                    searchResults = searchResults,
                                    onSearchQueryChange = viewModel::onSearchQueryChange,
                                    onClearSearch = viewModel::clearSearch,
                                    onOpenLesson = { id ->
                                        dismissTextControls()
                                        viewModel.openLesson(id)
                                    },
                                    onStartQuiz = { id ->
                                        dismissTextControls()
                                        viewModel.startQuizForLesson(id, switchTab = true)
                                    },
                                    onStartQuickQuiz = {
                                        dismissTextControls()
                                        viewModel.startQuickQuiz()
                                    },
                                    onToggleLessonComplete = { id ->
                                        dismissTextControls()
                                        viewModel.toggleLessonComplete(id)
                                    },
                                    onOpenProgress = {
                                        dismissTextControls()
                                        viewModel.switchTab(AppTab.PROGRESS)
                                    },
                                    onOpenAzkar = { section ->
                                        dismissTextControls()
                                        viewModel.openAzkar(section)
                                    },
                                    onToggleReminder = { enabled ->
                                        dismissTextControls()
                                        if (!enabled) {
                                            viewModel.saveDailyReminder(false, progress.reminderHour, progress.reminderMinute)
                                        } else if (com.example.util.StudyReminderHelper.hasNotificationPermission(context)) {
                                            viewModel.saveDailyReminder(true, progress.reminderHour, progress.reminderMinute)
                                        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                            quickReminderPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                        } else {
                                            viewModel.saveDailyReminder(true, progress.reminderHour, progress.reminderMinute)
                                        }
                                    },
                                    onOpenReminderSettings = {
                                        dismissTextControls()
                                        showReminderModal = true
                                    },
                                    onOpenAbout = {
                                        dismissTextControls()
                                        showAboutModal = true
                                    },
                                    onShareApp = {
                                        dismissTextControls()
                                        val launched = PrintShareHelper.shareApp(context, language)
                                        if (!launched) {
                                            viewModel.emitToast(
                                                if (language == AppLanguage.ENGLISH) "App info copied to clipboard"
                                                else "ایپ کی تفصیل کلپ بورڈ پر کاپی ہو گئی ہے"
                                            )
                                        }
                                    },
                                    homeSearchCategory = homeSearchCategory,
                                    homeGlobalSearchResults = homeGlobalSearchResults,
                                    onHomeSearchCategoryChange = viewModel::onHomeSearchCategoryChange,
                                    onOpenGlobalSearchResult = { match ->
                                        dismissTextControls()
                                        viewModel.openGlobalSearchResult(match)
                                    },
                                    onOpenFullSearch = {
                                        dismissTextControls()
                                        viewModel.openGlobalSearch()
                                    },
                                    modifier = contentModifier
                                )

                                AppTab.AZKAR -> AzkarScreen(
                                    language = language,
                                    activeSection = activeAzkarSection,
                                    tasbeehCount = progress.tasbeehCount,
                                    isSpeaking = isSpeaking,
                                    onSelectSection = viewModel::selectAzkarSection,
                                    onBackHome = {
                                        dismissTextControls()
                                        viewModel.switchTab(AppTab.HOME)
                                    },
                                    onSpeakText = viewModel::speakAzkarText,
                                    onStopAudio = viewModel::stopAudio,
                                    onIncrementTasbeeh = viewModel::incrementTasbeeh,
                                    onResetTasbeeh = viewModel::resetTasbeeh,
                                    onOpenLesson = { id ->
                                        dismissTextControls()
                                        viewModel.openLesson(id)
                                    },
                                    focusTarget = azkarFocusTarget,
                                    modifier = contentModifier
                                )

                                AppTab.LEARN -> LearnScreen(
                                    language = language,
                                    strings = strings,
                                    appConfig = appConfig,
                                    allLessons = allLessons,
                                    currentLesson = currentLesson,
                                    learnState = learnState,
                                    isCompleted = progress.completedLessons.contains(currentLesson.id),
                                    isSpeaking = isSpeaking,
                                    activeSpeakingLineIndex = activeSpeakingLineIndex,
                                    onSelectLesson = viewModel::openLesson,
                                    onPrevLesson = viewModel::prevLesson,
                                    onNextLesson = viewModel::nextLesson,
                                    onToggleAudio = viewModel::toggleLessonAudio,
                                    onSpeakLine = viewModel::speakLine,
                                    onToggleHideTarjuma = viewModel::toggleHideTarjuma,
                                    onToggleMemoMode = viewModel::toggleMemoMode,
                                    onChangeMemoLine = viewModel::changeMemoLine,
                                    onToggleLessonComplete = viewModel::toggleCurrentLessonComplete,
                                    onStartQuiz = { id -> viewModel.startQuizForLesson(id, switchTab = true) },
                                    onPrintLesson = { lesson ->
                                        PrintShareHelper.printLesson(context, lesson, language, appConfig) {
                                            viewModel.emitToast(
                                                if (language == AppLanguage.ENGLISH) "Print service unavailable."
                                                else "پرنٹ سروس دستیاب نہیں ہے۔"
                                            )
                                        }
                                    },
                                    onShareLesson = { lesson ->
                                        PrintShareHelper.shareLesson(context, lesson, language, appConfig)
                                    },
                                    onInspectWord = viewModel::inspectWord,
                                    onSpeakInspectedWord = viewModel::speakInspectedWord,
                                    onCloseInspector = viewModel::closeInspector,
                                    modifier = contentModifier
                                )

                                AppTab.QUIZ -> QuizScreen(
                                    language = language,
                                    strings = strings,
                                    allLessons = allLessons,
                                    quizState = quizState,
                                    onSelectQuizLesson = { id -> viewModel.startQuizForLesson(id, switchTab = false) },
                                    onRestartQuiz = { viewModel.startQuizForLesson(quizState.lessonId, switchTab = false) },
                                    onStartQuickQuiz = viewModel::startQuickQuiz,
                                    onSelectAnswer = viewModel::selectQuizAnswer,
                                    onNextQuestion = viewModel::nextQuizQuestion,
                                    onOpenLesson = viewModel::openLesson,
                                    onOpenProgress = { viewModel.switchTab(AppTab.PROGRESS) },
                                    modifier = contentModifier
                                )

                                AppTab.EDITOR -> EditorScreen(
                                    language = language,
                                    strings = strings,
                                    editorMode = editorMode,
                                    onSwitchEditorMode = viewModel::switchEditorMode,
                                    appDraftConfig = appDraftConfig,
                                    darkMode = progress.darkMode,
                                    bigFont = progress.bigFont,
                                    onUpdateAppBrandingDraft = { sUr, sEn, tUr, tEn, hUr, hEn ->
                                        viewModel.updateAppBrandingDraft(sUr, sEn, tUr, tEn, hUr, hEn)
                                    },
                                    onSaveAppBranding = viewModel::saveAppBranding,
                                    onSelectThemePreset = viewModel::selectThemePreset,
                                    onUpdateFontScale = viewModel::updateFontScale,
                                    onToggleDarkMode = viewModel::toggleDarkMode,
                                    onToggleBigFont = viewModel::toggleBigFont,
                                    onToggleLanguage = {
                                        dismissTextControls()
                                        viewModel.toggleLanguage()
                                    },
                                    onToggleShowPronunciationInBoxes = viewModel::toggleShowPronunciationInBoxes,
                                    onToggleShowSecondaryTitle = viewModel::toggleShowSecondaryTitle,
                                    onUpdateTtsSpeed = viewModel::updateTtsSpeed,
                                    onBuildBackupJson = viewModel::buildFullBackupJson,
                                    onShareBackupJson = { json ->
                                        dismissTextControls()
                                        PrintShareHelper.shareBackupJson(context, json, language)
                                    },
                                    onImportBackupJson = viewModel::importBackupJson,
                                    onResetAppDefaults = viewModel::resetAppCustomizationDefaults,
                                    onEmitToast = viewModel::emitToast,
                                    allLessons = allLessons,
                                    editorState = editorState,
                                    onSelectLessonToEdit = { id -> viewModel.loadLessonIntoEditor(id, switchTab = false) },
                                    onCreateNewLesson = viewModel::startNewLessonInEditor,
                                    onTitleUrChange = viewModel::updateEditorTitleUr,
                                    onTitleEnChange = viewModel::updateEditorTitleEn,
                                    onRomanKeysChange = viewModel::updateEditorRomanKeys,
                                    onLineLabelChange = viewModel::updateEditorLineLabel,
                                    onLineFullUrChange = viewModel::updateEditorLineFullUr,
                                    onLineFullEnChange = viewModel::updateEditorLineFullEn,
                                    onAddLine = viewModel::addEditorLine,
                                    onRemoveLine = viewModel::removeEditorLine,
                                    onWordChange = viewModel::updateEditorWord,
                                    onAddWord = viewModel::addEditorWord,
                                    onRemoveWord = viewModel::removeEditorWord,
                                    onLughatChange = viewModel::updateEditorLughat,
                                    onAddLughat = viewModel::addEditorLughat,
                                    onRemoveLughat = viewModel::removeEditorLughat,
                                    onSave = viewModel::saveEditedLesson,
                                    onResetToDefault = viewModel::resetBuiltInLessonToDefault,
                                    onDeleteCustomLesson = viewModel::deleteCustomLesson,
                                    modifier = contentModifier
                                )

                                AppTab.PROGRESS -> ProgressScreen(
                                    language = language,
                                    strings = strings,
                                    allLessons = allLessons,
                                    progress = progress,
                                    onOpenLesson = viewModel::openLesson,
                                    onStartQuiz = { id -> viewModel.startQuizForLesson(id, switchTab = true) },
                                    onResetProgress = viewModel::resetProgress,
                                    modifier = contentModifier
                                )
                            }
                        }
                    }
                }

                QuickQuizModal(
                    language = language,
                    strings = strings,
                    state = quickQuizState,
                    totalBankSize = allLessons.size * 10,
                    onSelectAnswer = viewModel::selectQuickQuizAnswer,
                    onNextQuestion = viewModel::nextQuickQuizQuestion,
                    onRestart = { viewModel.startQuickQuiz() },
                    onDismiss = viewModel::dismissQuickQuiz
                )

                GlobalSearchModal(
                    language = language,
                    strings = strings,
                    state = globalSearchState,
                    onQueryChange = viewModel::onGlobalSearchQueryChange,
                    onCategoryChange = viewModel::onGlobalSearchCategoryChange,
                    onResultClick = viewModel::openGlobalSearchResult,
                    onDismiss = viewModel::closeGlobalSearch
                )

                AboutModal(
                    isVisible = showAboutModal,
                    language = language,
                    strings = strings,
                    onDismiss = { showAboutModal = false }
                )

                StudyReminderModal(
                    isVisible = showReminderModal,
                    language = language,
                    strings = strings,
                    currentEnabled = progress.reminderEnabled,
                    currentHour = progress.reminderHour,
                    currentMinute = progress.reminderMinute,
                    onSaveReminder = viewModel::saveDailyReminder,
                    onSendTestReminder = viewModel::sendTestStudyReminder,
                    onDismiss = { showReminderModal = false }
                )

                if (showAdminPasswordDialog) {
                    val verifyAdminPin = {
                        if (adminPinInput.trim() == "7860") {
                            dismissTextControls()
                            showAdminPasswordDialog = false
                            adminPinInput = ""
                            adminPinError = false
                            viewModel.switchTab(AppTab.EDITOR)
                        } else {
                            adminPinError = true
                        }
                    }

                    AlertDialog(
                        onDismissRequest = {
                            dismissTextControls()
                            showAdminPasswordDialog = false
                            adminPinInput = ""
                            adminPinError = false
                        },
                        title = {
                            Text(
                                text = strings.adminPasswordDialogTitle,
                                fontFamily = uiFont,
                                fontWeight = FontWeight.Bold
                            )
                        },
                        text = {
                            ProvideSafeTextToolbar {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = adminPinInput,
                                        onValueChange = {
                                            adminPinInput = it
                                            adminPinError = false
                                        },
                                        label = { Text(strings.adminPasswordLabel, fontFamily = uiFont) },
                                        singleLine = true,
                                        isError = adminPinError,
                                        visualTransformation = PasswordVisualTransformation(),
                                        keyboardOptions = KeyboardOptions(
                                            keyboardType = KeyboardType.NumberPassword,
                                            imeAction = ImeAction.Done
                                        ),
                                        keyboardActions = KeyboardActions(onDone = { verifyAdminPin() }),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("admin_password_input")
                                    )
                                    if (adminPinError) {
                                        Text(
                                            text = strings.adminPasswordError,
                                            color = Color(0xFFDC2626),
                                            fontFamily = uiFont,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.testTag("admin_password_error")
                                        )
                                    }
                                }
                            }
                        },
                        confirmButton = {
                            Button(
                                onClick = verifyAdminPin,
                                modifier = Modifier.testTag("admin_password_confirm_button")
                            ) {
                                Text(
                                    text = strings.adminPasswordConfirm,
                                    fontFamily = uiFont,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        },
                        dismissButton = {
                            TextButton(
                                onClick = {
                                    dismissTextControls()
                                    showAdminPasswordDialog = false
                                    adminPinInput = ""
                                    adminPinError = false
                                }
                            ) {
                                Text(
                                    text = strings.cancelNo,
                                    fontFamily = uiFont,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    )
                }
            }
        }
    }
}
