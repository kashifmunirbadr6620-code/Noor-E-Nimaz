import com.google.gms.googleservices.GoogleServicesPlugin.MissingGoogleServicesStrategy

plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
  alias(libs.plugins.google.devtools.ksp)
  alias(libs.plugins.secrets)
  alias(libs.plugins.google.services)
}

android {
  namespace = "com.example"
  compileSdk { version = release(36) { minorApiLevel = 1 } }

  defaultConfig {
    applicationId = "com.aistudio.namaztarjuma.grsmem"
    minSdk = 24
    targetSdk = 36
    versionCode = 1
    versionName = "1.0"

    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
  }

  // Do not remove or modify these signingConfigs. They are necessary for building, installing,
  // and updating Android apps in AI Studio.
  signingConfigs {
    create("release") {
      val keystorePath = System.getenv("KEYSTORE_PATH") ?: "${rootDir}/my-upload-key.jks"
      storeFile = file(keystorePath)
      storePassword = System.getenv("STORE_PASSWORD")
      keyAlias = "upload"
      keyPassword = System.getenv("KEY_PASSWORD")
    }
    create("debugConfig") {
      storeFile = file("${rootDir}/debug.keystore")
      storePassword = "android"
      keyAlias = "androiddebugkey"
      keyPassword = "android"
    }
  }

  buildTypes {
    release {
      isCrunchPngs = false
      isMinifyEnabled = false
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      // Do not remove or modify this signingConfig assignment. It is necessary for Android apps in
      // AI Studio.
      signingConfig = signingConfigs.getByName("release")
    }
    debug {
      // Do not remove or modify this signingConfig assignment. It is necessary for Android apps in
      // AI Studio.
      signingConfig = signingConfigs.getByName("debugConfig")
    }
  }
  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }
  buildFeatures {
    compose = true
    buildConfig = true
  }
  testOptions { unitTests { isIncludeAndroidResources = true } }
  dependenciesInfo {
    includeInApk = false
    includeInBundle = true
  }
}

// Configure the Secrets Gradle Plugin to use .env and .env.example files
// to match the convention used in Web projects.
secrets {
  propertiesFileName = ".env"
  defaultPropertiesFileName = ".env.example"
  ignoreList.add("FIREBASE_APPCHECK_DEBUG_TOKEN")
}

googleServices { missingGoogleServicesStrategy = MissingGoogleServicesStrategy.WARN }

// Some unused dependencies are commented out below instead of being removed.
// This makes it easy to add them back in the future if needed.
dependencies {
  implementation(platform(libs.androidx.compose.bom))
  // implementation(platform(libs.firebase.bom))
  // implementation(libs.accompanist.permissions)
  implementation(libs.androidx.activity.compose)
  // implementation(libs.androidx.camera.camera2)
  // implementation(libs.androidx.camera.core)
  // implementation(libs.androidx.camera.lifecycle)
  // implementation(libs.androidx.camera.view)
  implementation(libs.androidx.compose.material.icons.core)
  implementation(libs.androidx.compose.material.icons.extended)
  implementation(libs.androidx.compose.material3)
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.graphics)
  implementation(libs.androidx.compose.ui.tooling.preview)
  implementation(libs.androidx.core.ktx)
  implementation(libs.androidx.datastore.preferences)
  implementation(libs.androidx.lifecycle.runtime.compose)
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.androidx.lifecycle.viewmodel.compose)
  // implementation(libs.androidx.navigation.compose)
  // implementation(libs.androidx.room.ktx)
  // implementation(libs.androidx.room.runtime)
  // implementation(libs.coil.compose)
  // implementation(libs.converter.moshi)
  // implementation(libs.firebase.ai)
  // Uncomment to use Firestore:
  // implementation(libs.firebase.firestore)

  // Uncomment ALL FOUR of the following dependencies together to use Firebase Auth and Google
  // Sign-In via Credential Manager:
  // implementation(libs.firebase.auth)
  // implementation(libs.androidx.credentials)
  // implementation(libs.androidx.credentials.play.services)
  // implementation(libs.googleid)
  // implementation(libs.firebase.appcheck.recaptcha)
  // implementation(libs.firebase.appcheck.debug)
  implementation(libs.kotlinx.coroutines.android)
  implementation(libs.kotlinx.coroutines.core)
  // implementation(libs.logging.interceptor)
  // implementation(libs.moshi.kotlin)
  // implementation(libs.okhttp)
  // implementation(libs.play.services.location)
  // implementation(libs.retrofit)
  testImplementation(libs.androidx.compose.ui.test.junit4)
  testImplementation(libs.androidx.core)
  testImplementation(libs.androidx.junit)
  testImplementation(libs.junit)
  testImplementation(libs.kotlinx.coroutines.test)
  testImplementation(libs.robolectric)
  androidTestImplementation(platform(libs.androidx.compose.bom))
  androidTestImplementation(libs.androidx.compose.ui.test.junit4)
  androidTestImplementation(libs.androidx.espresso.core)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.androidx.runner)
  debugImplementation(libs.androidx.compose.ui.test.manifest)
  debugImplementation(libs.androidx.compose.ui.tooling)
  // "ksp"(libs.androidx.room.compiler)
  // "ksp"(libs.moshi.kotlin.codegen)
}

/*
 * ============================================================================
 * Signed Release APK Setup & ProGuard Verification Guide
 * ============================================================================
 * The `release` signingConfig above reads:
 *   - KEYSTORE_PATH  (defaults to `${rootDir}/my-upload-key.jks`)
 *   - STORE_PASSWORD (keystore password env var)
 *   - keyAlias       = "upload"
 *   - KEY_PASSWORD   (key password env var)
 *
 * 1. Create the upload keystore (.jks) via keytool (run from project root):
 *      keytool -genkeypair -v -keystore my-upload-key.jks -alias upload \
 *        -keyalg RSA -keysize 2048 -validity 10000
 *
 * 2. Export signing environment variables (Linux/macOS; use `set` or `$env:` on Windows):
 *      export KEYSTORE_PATH="$(pwd)/my-upload-key.jks"
 *      export STORE_PASSWORD="<your-keystore-password>"
 *      export KEY_PASSWORD="<your-key-password>"
 *
 * 3. ProGuard / R8 release rules (`app/proguard-rules.pro`):
 *    Already configured to preserve all educational content and runtime components:
 *      - `com.example.model.**` (lessons, lines, word-by-word meanings, Azkar, quizzes)
 *      - `com.example.data.**` (17-lesson repository, 170-MCQ bank, Azkar/Janaza data, DataStore repo)
 *      - `NamazViewModel`, `QuizUiState`, `QuickQuizUiState`, `LearnUiState`, `EditorUiState`
 *      - `AudioHelper`, `PrintShareHelper`, `SafeTextToolbar`, `org.json.**`, DataStore, fonts (`R$*`)
 *    When building locally for production distribution, toggle `isMinifyEnabled = true`
 *    in `buildTypes.release` if code shrinking/obfuscation is desired.
 *
 * 4. Verify setup & build the signed release APK:
 *      gradle :app:verifyReleaseSigningSetup
 *      gradle :app:assembleRelease
 *    Output APK: app/build/outputs/apk/release/app-release.apk
 *    Or in Android Studio: Build > Generate Signed Bundle / APK... > APK.
 * ============================================================================
 */
tasks.register("verifyReleaseSigningSetup") {
  group = "verification"
  description = "Checks release keystore, signing env vars, and proguard-rules.pro readiness without exposing secrets."
  val defaultKeystorePath = rootProject.layout.projectDirectory.file("my-upload-key.jks").asFile.absolutePath
  val envKeystoreProvider = providers.environmentVariable("KEYSTORE_PATH")
  val storePasswordProvider = providers.environmentVariable("STORE_PASSWORD")
  val keyPasswordProvider = providers.environmentVariable("KEY_PASSWORD")
  val proguardFile = layout.projectDirectory.file("proguard-rules.pro").asFile

  doLast {
    val envKeystorePath = envKeystoreProvider.orNull
    val resolvedKeystore = if (!envKeystorePath.isNullOrBlank()) File(envKeystorePath) else File(defaultKeystorePath)
    val hasStorePassword = !storePasswordProvider.orNull.isNullOrBlank()
    val hasKeyPassword = !keyPasswordProvider.orNull.isNullOrBlank()
    val proguardText = if (proguardFile.exists()) proguardFile.readText() else ""
    val requiredRules = listOf(
      "com.example.model.**",
      "com.example.data.**",
      "com.example.ui.NamazViewModel",
      "com.example.ui.QuickQuizUiState",
      "com.example.util.AudioHelper",
      "com.example.util.PrintShareHelper",
      "androidx.datastore.**"
    )
    val missingRules = requiredRules.filterNot { proguardText.contains(it) }

    println("=== Namaz Tarjuma Release Signing & ProGuard Check ===")
    println("Keystore file (${resolvedKeystore.absolutePath}): ${if (resolvedKeystore.exists()) "FOUND" else "MISSING"}")
    println("KEYSTORE_PATH env var: ${if (!envKeystorePath.isNullOrBlank()) "SET" else "UNSET (using default root my-upload-key.jks)"}")
    println("STORE_PASSWORD env var: ${if (hasStorePassword) "SET" else "MISSING"}")
    println("KEY_PASSWORD env var: ${if (hasKeyPassword) "SET" else "MISSING"}")
    println("Required key alias: upload")
    println("ProGuard file (${proguardFile.name}): ${if (missingRules.isEmpty()) "ALL ESSENTIAL EDUCATIONAL RULES PRESENT" else "MISSING RULES: $missingRules"}")
    println("Next step to build signed APK: gradle :app:assembleRelease")
  }
}
