package com.example.data

import com.example.model.AppLanguage
import com.example.model.AzkarSection
import com.example.model.GlobalSearchCategory
import com.example.model.GlobalSearchMatch
import com.example.model.Lesson
import com.example.model.QuickQuizItem
import com.example.model.QuizQuestion
import com.example.model.SearchMatch

object LessonRepository {

    val allLessons: List<Lesson> by lazy {
        (lessonsPart1 + lessonsPart2).map { LessonEnglishData.enrich(it) }
    }

    fun mergeLessons(overrides: Map<Int, Lesson>): List<Lesson> {
        val base = allLessons.map { lesson ->
            overrides[lesson.id]?.let { LessonEnglishData.enrich(it) } ?: lesson
        }
        val extraCustom = overrides.values
            .filter { override -> allLessons.none { it.id == override.id } }
            .sortedBy { it.id }
        return base + extraCustom
    }

    fun isBuiltInLesson(id: Int): Boolean = allLessons.any { it.id == id }

    fun getLesson(id: Int, lessons: List<Lesson> = allLessons): Lesson =
        lessons.find { it.id == id } ?: lessons.first()

    fun normalizeArabic(input: String): String {
        return input
            .replace(Regex("[\\u064B-\\u065F\\u0670\\u06D6-\\u06ED]"), "")
            .replace(Regex("[أإآٱ]"), "ا")
            .replace("ى", "ي")
            .replace("ة", "ه")
            .lowercase()
            .trim()
    }

    fun search(query: String, lessons: List<Lesson> = allLessons): List<SearchMatch> {
        val qRaw = query.trim()
        if (qRaw.isEmpty()) return emptyList()

        val qNorm = normalizeArabic(qRaw)
        val qLower = qRaw.lowercase()
        val matches = mutableListOf<SearchMatch>()

        for (lesson in lessons) {
            val seenInLesson = mutableSetOf<String>()
            val lessonKeyMatch = lesson.titleUr.contains(qRaw) ||
                lesson.titleEn.lowercase().contains(qLower) ||
                lesson.romanKeys.lowercase().contains(qLower)

            for (line in lesson.lines) {
                for (w in line.words) {
                    val arNorm = normalizeArabic(w.ar)
                    val urMatch = w.ur.contains(qRaw)
                    val enMatch = w.en.lowercase().contains(qLower)
                    val pronMatch = w.pron.lowercase().contains(qLower)
                    val arMatch = qNorm.isNotEmpty() && arNorm.contains(qNorm)
                    if ((arMatch || urMatch || enMatch || pronMatch || lessonKeyMatch) && seenInLesson.add(w.ar)) {
                        matches.add(
                            SearchMatch(
                                lessonId = lesson.id,
                                lessonTitleUr = lesson.titleUr,
                                lessonTitleEn = lesson.titleEn,
                                ar = w.ar,
                                ur = w.ur,
                                en = w.en,
                                pron = w.pron
                            )
                        )
                    }
                }
            }

            for (lg in lesson.lughat) {
                val arNorm = normalizeArabic(lg.ar)
                val arMatch = qNorm.isNotEmpty() && arNorm.contains(qNorm)
                val enMatch = lg.en.lowercase().contains(qLower)
                if ((arMatch || lg.ur.contains(qRaw) || enMatch) && seenInLesson.add(lg.ar)) {
                    matches.add(
                        SearchMatch(
                            lessonId = lesson.id,
                            lessonTitleUr = lesson.titleUr,
                            lessonTitleEn = lesson.titleEn,
                            ar = lg.ar,
                            ur = lg.ur,
                            en = lg.en,
                            pron = ""
                        )
                    )
                }
            }
        }
        return matches.take(25)
    }

    private fun matchesQuery(candidate: String, qRaw: String, qNorm: String, qLower: String): Boolean {
        if (candidate.isBlank()) return false
        if (candidate.contains(qRaw) || candidate.lowercase().contains(qLower)) return true
        return qNorm.isNotEmpty() && normalizeArabic(candidate).contains(qNorm)
    }

    fun searchAll(
        query: String,
        lessons: List<Lesson> = allLessons,
        category: GlobalSearchCategory = GlobalSearchCategory.ALL
    ): List<GlobalSearchMatch> {
        val qRaw = query.trim()
        if (qRaw.isEmpty()) return emptyList()

        val qNorm = normalizeArabic(qRaw)
        val qLower = qRaw.lowercase()

        val lessonMatches = mutableListOf<GlobalSearchMatch>()
        if (category == GlobalSearchCategory.ALL || category == GlobalSearchCategory.LESSON) {
            for (lesson in lessons) {
                val seenInLesson = mutableSetOf<String>()
                val lessonTagKey = "lesson ${lesson.id} سبق ${lesson.id}"
                val lessonMetaMatch = matchesQuery(lesson.titleUr, qRaw, qNorm, qLower) ||
                    matchesQuery(lesson.titleEn, qRaw, qNorm, qLower) ||
                    matchesQuery(lesson.romanKeys, qRaw, qNorm, qLower) ||
                    matchesQuery(lessonTagKey, qRaw, qNorm, qLower)

                if (lessonMetaMatch) {
                    val firstLine = lesson.lines.firstOrNull()
                    val previewAr = firstLine?.words?.take(5)?.joinToString(" ") { it.ar }.orEmpty()
                    lessonMatches.add(
                        GlobalSearchMatch(
                            id = "lesson_overview_${lesson.id}",
                            category = GlobalSearchCategory.LESSON,
                            titleUr = "سبق ${lesson.id}: ${lesson.titleUr}",
                            titleEn = "Lesson ${lesson.id}: ${lesson.titleEn.ifBlank { lesson.titleUr }}",
                            arabic = previewAr,
                            meaningUr = firstLine?.fullUr.orEmpty(),
                            meaningEn = firstLine?.fullEn?.ifBlank { firstLine.fullUr }.orEmpty(),
                            subtitleUr = firstLine?.label.orEmpty(),
                            subtitleEn = firstLine?.labelEn?.ifBlank { firstLine.label }.orEmpty(),
                            lessonId = lesson.id
                        )
                    )
                }

                for ((lineIdx, line) in lesson.lines.withIndex()) {
                    var wordMatchedInLine = false
                    for (w in line.words) {
                        val hit = matchesQuery(w.ar, qRaw, qNorm, qLower) ||
                            matchesQuery(w.ur, qRaw, qNorm, qLower) ||
                            matchesQuery(w.en, qRaw, qNorm, qLower) ||
                            matchesQuery(w.pron, qRaw, qNorm, qLower)
                        if (hit) {
                            wordMatchedInLine = true
                            if (seenInLesson.add(w.ar)) {
                                lessonMatches.add(
                                    GlobalSearchMatch(
                                        id = "lesson_word_${lesson.id}_${w.ar}",
                                        category = GlobalSearchCategory.LESSON,
                                        titleUr = "سبق ${lesson.id}: ${lesson.titleUr}",
                                        titleEn = "Lesson ${lesson.id}: ${lesson.titleEn.ifBlank { lesson.titleUr }}",
                                        arabic = w.ar,
                                        meaningUr = w.ur,
                                        meaningEn = w.en.ifBlank { w.ur },
                                        subtitleUr = w.pron,
                                        subtitleEn = w.pron,
                                        lessonId = lesson.id
                                    )
                                )
                            }
                        }
                    }

                    if (!wordMatchedInLine) {
                        val lineHit = matchesQuery(line.fullUr, qRaw, qNorm, qLower) ||
                            matchesQuery(line.fullEn, qRaw, qNorm, qLower) ||
                            matchesQuery(line.label, qRaw, qNorm, qLower) ||
                            matchesQuery(line.labelEn, qRaw, qNorm, qLower)
                        if (lineHit && seenInLesson.add("line_$lineIdx")) {
                            lessonMatches.add(
                                GlobalSearchMatch(
                                    id = "lesson_line_${lesson.id}_$lineIdx",
                                    category = GlobalSearchCategory.LESSON,
                                    titleUr = "سبق ${lesson.id}: ${lesson.titleUr}",
                                    titleEn = "Lesson ${lesson.id}: ${lesson.titleEn.ifBlank { lesson.titleUr }}",
                                    arabic = line.words.joinToString(" ") { it.ar },
                                    meaningUr = line.fullUr,
                                    meaningEn = line.fullEn.ifBlank { line.fullUr },
                                    subtitleUr = line.label,
                                    subtitleEn = line.labelEn.ifBlank { line.label },
                                    lessonId = lesson.id
                                )
                            )
                        }
                    }
                }

                for (lg in lesson.lughat) {
                    val lgHit = matchesQuery(lg.ar, qRaw, qNorm, qLower) ||
                        matchesQuery(lg.ur, qRaw, qNorm, qLower) ||
                        matchesQuery(lg.en, qRaw, qNorm, qLower)
                    if (lgHit && seenInLesson.add(lg.ar)) {
                        lessonMatches.add(
                            GlobalSearchMatch(
                                id = "lesson_lughat_${lesson.id}_${lg.ar}",
                                category = GlobalSearchCategory.LESSON,
                                titleUr = "سبق ${lesson.id}: ${lesson.titleUr}",
                                titleEn = "Lesson ${lesson.id}: ${lesson.titleEn.ifBlank { lesson.titleUr }}",
                                arabic = lg.ar,
                                meaningUr = lg.ur,
                                meaningEn = lg.en.ifBlank { lg.ur },
                                subtitleUr = "لغت",
                                subtitleEn = "Vocabulary",
                                lessonId = lesson.id
                            )
                        )
                    }
                }
            }
        }

        val duaMatches = mutableListOf<GlobalSearchMatch>()
        if (category == GlobalSearchCategory.ALL || category == GlobalSearchCategory.DUA) {
            fun scanZikrList(
                items: List<com.example.model.ZikrItem>,
                section: AzkarSection,
                sectionTitleUr: String,
                sectionTitleEn: String,
                sectionKeywords: String
            ) {
                val sectionHit = matchesQuery(sectionKeywords, qRaw, qNorm, qLower)
                items.forEachIndexed { idx, item ->
                    val contentHit = matchesQuery(item.arabic, qRaw, qNorm, qLower) ||
                        matchesQuery(item.speakText, qRaw, qNorm, qLower) ||
                        matchesQuery(item.translationUr, qRaw, qNorm, qLower) ||
                        matchesQuery(item.translationEn, qRaw, qNorm, qLower) ||
                        matchesQuery(item.repeatUr, qRaw, qNorm, qLower) ||
                        matchesQuery(item.repeatEn, qRaw, qNorm, qLower) ||
                        matchesQuery(item.refUr, qRaw, qNorm, qLower) ||
                        matchesQuery(item.refEn, qRaw, qNorm, qLower)
                    if (contentHit || sectionHit) {
                        duaMatches.add(
                            GlobalSearchMatch(
                                id = "dua_${section.name.lowercase()}_${item.orderNumber}",
                                category = GlobalSearchCategory.DUA,
                                titleUr = "$sectionTitleUr (#${item.orderNumber})",
                                titleEn = "$sectionTitleEn (#${item.orderNumber})",
                                arabic = item.arabic,
                                meaningUr = item.translationUr,
                                meaningEn = item.translationEn,
                                subtitleUr = "${item.repeatUr} • ${item.refUr}",
                                subtitleEn = "${item.repeatEn} • ${item.refEn}",
                                azkarSection = section,
                                azkarItemIndex = idx
                            )
                        )
                    }
                }
            }

            scanZikrList(
                items = AzkarData.afterSalahAzkarList,
                section = AzkarSection.SALAH_AZKAR,
                sectionTitleUr = "نماز کے بعد مسنون دعا",
                sectionTitleEn = "After Salah Dua",
                sectionKeywords = "after salah azkar zikr prayer dua tasbeeh kursi istighfar نماز کے بعد اذکار دعا استغفار تسبیح"
            )
            scanZikrList(
                items = AzkarData.morningEveningAzkarList,
                section = AzkarSection.MORNING_EVENING,
                sectionTitleUr = "صبح و شام کی دعا",
                sectionTitleEn = "Morning & Evening Dua",
                sectionKeywords = "morning evening subah shaam azkar dua صبح شام اذکار دعا"
            )
            scanZikrList(
                items = AzkarData.janazaDuasList,
                section = AzkarSection.JANAZA_DUAS,
                sectionTitleUr = "نمازِ جنازہ کی دعا",
                sectionTitleEn = "Namaz-e-Janaza Dua",
                sectionKeywords = "janaza funeral mayyit child dua نماز جنازہ میت دعا"
            )

            val asmaSectionHit = matchesQuery("asma ul husna allah names اسماء الحسنی صفاتی نام", qRaw, qNorm, qLower)
            AzkarData.asmaUlHusnaList.forEachIndexed { idx, item ->
                val hit = asmaSectionHit ||
                    matchesQuery(item.arabic, qRaw, qNorm, qLower) ||
                    matchesQuery(item.nameUr, qRaw, qNorm, qLower) ||
                    matchesQuery(item.nameEn, qRaw, qNorm, qLower) ||
                    matchesQuery(item.meaningUr, qRaw, qNorm, qLower) ||
                    matchesQuery(item.meaningEn, qRaw, qNorm, qLower)
                if (hit) {
                    duaMatches.add(
                        GlobalSearchMatch(
                            id = "asma_${item.number}",
                            category = GlobalSearchCategory.DUA,
                            titleUr = "اسماء الحسنیٰ (#${item.number}): ${item.nameUr}",
                            titleEn = "Asma-ul-Husna (#${item.number}): ${item.nameEn}",
                            arabic = item.arabic,
                            meaningUr = item.meaningUr,
                            meaningEn = item.meaningEn,
                            subtitleUr = "اللہ تعالیٰ کا صفاتی نام",
                            subtitleEn = "Beautiful Name of Allah",
                            azkarSection = AzkarSection.ASMA_UL_HUSNA,
                            azkarItemIndex = idx
                        )
                    )
                }
            }
        }

        val hadithMatches = mutableListOf<GlobalSearchMatch>()
        if (category == GlobalSearchCategory.ALL || category == GlobalSearchCategory.HADITH) {
            val hadithSectionHit = matchesQuery("hadith hadees ahadees ahadith sunnah حدیث احادیث", qRaw, qNorm, qLower)
            AzkarData.childrenHadithList.forEachIndexed { idx, hadith ->
                val hit = hadithSectionHit ||
                    matchesQuery(hadith.arabic, qRaw, qNorm, qLower) ||
                    matchesQuery(hadith.translationUr, qRaw, qNorm, qLower) ||
                    matchesQuery(hadith.translationEn, qRaw, qNorm, qLower) ||
                    matchesQuery(hadith.refUr, qRaw, qNorm, qLower) ||
                    matchesQuery(hadith.refEn, qRaw, qNorm, qLower)
                if (hit) {
                    hadithMatches.add(
                        GlobalSearchMatch(
                            id = "hadith_${hadith.number}",
                            category = GlobalSearchCategory.HADITH,
                            titleUr = "حدیثِ نبوی ﷺ #${hadith.number}",
                            titleEn = "Hadith #${hadith.number}",
                            arabic = hadith.arabic,
                            meaningUr = hadith.translationUr,
                            meaningEn = hadith.translationEn,
                            subtitleUr = hadith.refUr,
                            subtitleEn = hadith.refEn,
                            azkarSection = AzkarSection.AHADEES,
                            azkarItemIndex = idx
                        )
                    )
                }
            }
        }

        return when (category) {
            GlobalSearchCategory.ALL -> lessonMatches.take(10) + duaMatches.take(10) + hadithMatches.take(10)
            GlobalSearchCategory.LESSON -> lessonMatches.take(25)
            GlobalSearchCategory.DUA -> duaMatches.take(25)
            GlobalSearchCategory.HADITH -> hadithMatches.take(25)
        }
    }

    fun build10QuestionsForLesson(
        lesson: Lesson,
        lessons: List<Lesson> = allLessons,
        language: AppLanguage = AppLanguage.URDU
    ): List<QuizQuestion> {
        if (language == AppLanguage.URDU) {
            val custom = lesson.customQuiz
            if (custom != null && custom.size >= 10) {
                return custom.take(10)
            }
        } else {
            val customEn = LessonEnglishData.customEnglishQuiz(lesson.id)
            if (customEn != null && customEn.size >= 10 && !lesson.isCustom) {
                return customEn.take(10)
            }
        }

        val uniqueMeanings = lessons
            .flatMap { l ->
                l.lughat.map { it.meaning(language) } +
                    l.lines.flatMap { ln -> ln.words.map { it.meaning(language) } }
            }
            .filter { it.isNotBlank() }
            .distinct()

        val uniqueTranslations = lessons
            .flatMap { l -> l.lines.map { it.fullTranslation(language) } }
            .filter { it.isNotBlank() }
            .distinct()

        val allArabicWords = lessons
            .flatMap { l -> l.lughat.map { it.ar } }
            .filter { it.isNotBlank() }
            .distinct()

        val questions = mutableListOf<QuizQuestion>()
        val usedKeys = mutableSetOf<String>()

        val wordCandidates = buildList {
            lesson.lughat.forEach { add(it.ar to it.meaning(language)) }
            lesson.lines.forEach { ln -> ln.words.forEach { add(it.ar to it.meaning(language)) } }
        }.filter { it.first.isNotBlank() && it.second.isNotBlank() }

        for ((ar, meaning) in wordCandidates) {
            if (questions.size >= 7) break
            if (!usedKeys.add(ar)) continue

            val distractors = uniqueMeanings.filter { it != meaning }.shuffled().take(3)
            if (distractors.size < 3) continue
            val opts = (listOf(meaning) + distractors).shuffled()
            val prompt = if (language == AppLanguage.ENGLISH) {
                "What is the meaning of \"$ar\"?"
            } else {
                "\"$ar\" کا اردو مطلب کیا ہے؟"
            }
            questions.add(
                QuizQuestion(
                    q = prompt,
                    ar = ar,
                    opts = opts,
                    ans = opts.indexOf(meaning)
                )
            )
        }

        for (ln in lesson.lines) {
            if (questions.size >= 10) break
            val arSentence = ln.words.joinToString(" ") { it.ar }
            val targetTranslation = ln.fullTranslation(language)
            val distractors = uniqueTranslations.filter { it != targetTranslation }.shuffled().take(3)
            if (distractors.size < 3) continue
            val opts = (listOf(targetTranslation) + distractors).shuffled()
            val prompt = if (language == AppLanguage.ENGLISH) {
                "Choose the correct English translation for this line:"
            } else {
                "اس عبارت کا درست اردو ترجمہ منتخب کریں:"
            }
            questions.add(
                QuizQuestion(
                    q = prompt,
                    ar = arSentence,
                    opts = opts,
                    ans = opts.indexOf(targetTranslation)
                )
            )
        }

        for ((ar, meaning) in wordCandidates) {
            if (questions.size >= 10) break
            val revKey = "rev-$meaning"
            if (!usedKeys.add(revKey)) continue
            val distractors = allArabicWords.filter { it != ar }.shuffled().take(3)
            if (distractors.size < 3) continue
            val opts = (listOf(ar) + distractors).shuffled()
            val prompt = if (language == AppLanguage.ENGLISH) {
                "Which Arabic word means \"$meaning\"?"
            } else {
                "\"$meaning\" کے لیے درست عربی لفظ کون سا ہے؟"
            }
            questions.add(
                QuizQuestion(
                    q = prompt,
                    ar = "",
                    opts = opts,
                    ans = opts.indexOf(ar)
                )
            )
        }

        return questions.take(10)
    }

    fun buildQuickQuizQuestions(
        lessons: List<Lesson> = allLessons,
        language: AppLanguage = AppLanguage.URDU,
        count: Int = 5
    ): List<QuickQuizItem> {
        val fullBank = lessons.flatMap { lesson ->
            build10QuestionsForLesson(lesson, lessons, language).map { q ->
                QuickQuizItem(
                    lessonId = lesson.id,
                    lessonTitleUr = lesson.titleUr,
                    lessonTitleEn = lesson.titleEn,
                    question = q
                )
            }
        }
        return fullBank.shuffled().take(count)
    }
}
