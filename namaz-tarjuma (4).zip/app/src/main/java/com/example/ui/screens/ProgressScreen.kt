package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.Lesson
import com.example.model.UserProgressState
import com.example.ui.UiStrings
import com.example.ui.theme.LocalNamazColors
import com.example.ui.theme.RomanFontFamily
import com.example.ui.theme.UrduFontFamily

@Composable
fun ProgressScreen(
    language: AppLanguage,
    strings: UiStrings,
    allLessons: List<Lesson>,
    progress: UserProgressState,
    onOpenLesson: (Int) -> Unit,
    onStartQuiz: (Int) -> Unit,
    onResetProgress: () -> Unit,
    modifier: Modifier = Modifier
) {
    val extended = LocalNamazColors.current
    val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily
    var showResetDialog by remember { mutableStateOf(false) }

    val activeIds = remember(allLessons) { allLessons.map { it.id }.toSet() }
    val doneCount = progress.completedLessons.count { it in activeIds }
    val total = allLessons.size.coerceAtLeast(1)
    val pct = ((doneCount * 100f) / total).toInt()
    val quizzesDone = progress.quizScores.keys.count { it in activeIds }
    val totalQuizPts = progress.quizScores.filterKeys { it in activeIds }.values.sum()

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = {
                Text(
                    text = strings.resetDialogTitle,
                    fontFamily = uiFont,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = strings.resetDialogBody,
                    fontFamily = uiFont
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showResetDialog = false
                        onResetProgress()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text(strings.confirmYesClear, fontFamily = uiFont, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text(strings.cancelNo, fontFamily = uiFont, fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    LazyColumn(
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = modifier.fillMaxSize()
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = strings.progressTitle,
                    fontFamily = uiFont,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                    color = extended.arabicAccent
                )
                Button(
                    onClick = { showResetDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .heightIn(min = 48.dp)
                        .testTag("reset_progress_button")
                ) {
                    Text(
                        text = strings.resetProgressBtn,
                        fontFamily = uiFont,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatBoxCard(
                        value = "$doneCount / $total",
                        label = strings.statCompletedLessons,
                        uiFont = uiFont,
                        modifier = Modifier.weight(1f)
                    )
                    StatBoxCard(
                        value = "$pct%",
                        label = strings.statTotalProgress,
                        uiFont = uiFont,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatBoxCard(
                        value = "$quizzesDone / $total",
                        label = strings.statQuizzesDone,
                        uiFont = uiFont,
                        modifier = Modifier.weight(1f)
                    )
                    StatBoxCard(
                        value = "$totalQuizPts",
                        label = strings.statTotalQuizScore,
                        uiFont = uiFont,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        items(allLessons, key = { it.id }) { lesson ->
            val isDone = progress.completedLessons.contains(lesson.id)
            val bestScore = progress.quizScores[lesson.id]

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = extended.cardSurface),
                border = BorderStroke(1.dp, extended.cardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${strings.lessonTag(lesson.id)}: ${lesson.displayTitle(language)}",
                            fontFamily = uiFont,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        val statusText = if (isDone) strings.statusCompleted else strings.statusInProgress
                        val scoreText = if (bestScore != null) strings.bestQuizLabel(bestScore) else strings.noQuizYet
                        Text(
                            text = "${strings.statusLabel}$statusText$scoreText",
                            fontFamily = uiFont,
                            fontSize = 12.sp,
                            color = extended.mutedText
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = { onOpenLesson(lesson.id) },
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) {
                            Text(
                                text = strings.learnAction,
                                fontFamily = uiFont,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        OutlinedButton(
                            onClick = { onStartQuiz(lesson.id) },
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, extended.gold),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = extended.goldLight,
                                contentColor = extended.goldText
                            ),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) {
                            Text(
                                text = strings.quizAction,
                                fontFamily = uiFont,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatBoxCard(
    value: String,
    label: String,
    uiFont: androidx.compose.ui.text.font.FontFamily,
    modifier: Modifier = Modifier
) {
    val extended = LocalNamazColors.current
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = extended.cardSurface),
        border = BorderStroke(1.dp, extended.cardBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = value,
                    fontFamily = RomanFontFamily,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = extended.arabicAccent,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = label,
                    fontFamily = uiFont,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .background(extended.gold)
            )
        }
    }
}
