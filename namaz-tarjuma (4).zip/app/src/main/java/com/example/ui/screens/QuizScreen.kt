package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.Lesson
import com.example.ui.QuizUiState
import com.example.ui.UiStrings
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.theme.CorrectBgLight
import com.example.ui.theme.CorrectBorder
import com.example.ui.theme.CorrectTextLight
import com.example.ui.theme.LocalNamazColors
import com.example.ui.theme.RomanFontFamily
import com.example.ui.theme.UrduFontFamily
import com.example.ui.theme.WrongBgLight
import com.example.ui.theme.WrongBorder
import com.example.ui.theme.WrongTextLight

@Composable
fun QuizScreen(
    language: AppLanguage,
    strings: UiStrings,
    allLessons: List<Lesson>,
    quizState: QuizUiState,
    onSelectQuizLesson: (Int) -> Unit,
    onRestartQuiz: () -> Unit,
    onStartQuickQuiz: () -> Unit,
    onSelectAnswer: (Int) -> Unit,
    onNextQuestion: () -> Unit,
    onOpenLesson: (Int) -> Unit,
    onOpenProgress: () -> Unit,
    modifier: Modifier = Modifier
) {
    val extended = LocalNamazColors.current
    val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily
    val currentLesson = allLessons.find { it.id == quizState.lessonId } ?: allLessons.first()
    var dropdownExpanded by remember { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = modifier.fillMaxSize()
    ) {
        // Quick Quiz 5-Question Random Challenge Banner
        item {
            Card(
                onClick = onStartQuickQuiz,
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = extended.greenSurface),
                border = BorderStroke(1.5.dp, extended.gold),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("quiz_screen_quick_quiz_button")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = extended.gold,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.Bolt,
                                contentDescription = null,
                                tint = Color(0xFF1A1A1A),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.quickQuizBtn,
                            fontFamily = uiFont,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = extended.arabicAccent
                        )
                        Text(
                            text = strings.quickQuizSubtitle(allLessons.size * 10),
                            fontFamily = uiFont,
                            fontSize = 12.sp,
                            color = extended.mutedText,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Button(
                        onClick = onStartQuickQuiz,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = extended.gold,
                            contentColor = Color(0xFF1A1A1A)
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Text(
                            text = strings.quizAction,
                            fontFamily = uiFont,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // Quiz Lesson Selector Bar
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = extended.cardSurface),
                border = BorderStroke(1.dp, extended.cardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        Surface(
                            onClick = { dropdownExpanded = true },
                            shape = RoundedCornerShape(11.dp),
                            color = MaterialTheme.colorScheme.background,
                            border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .testTag("quiz_lesson_dropdown")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = strings.quizHeaderPrefix(currentLesson.id, currentLesson.displayTitle(language)),
                                    fontFamily = uiFont,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Icon(
                                    imageVector = Icons.Filled.ArrowDropDown,
                                    contentDescription = null
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false }
                        ) {
                            allLessons.forEach { item ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = "${strings.lessonTag(item.id)}: ${item.displayTitle(language)}",
                                            fontFamily = uiFont
                                        )
                                    },
                                    onClick = {
                                        dropdownExpanded = false
                                        onSelectQuizLesson(item.id)
                                    }
                                )
                            }
                        }
                    }

                    Button(
                        onClick = onRestartQuiz,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = extended.gold,
                            contentColor = Color(0xFF1A1A1A)
                        ),
                        shape = RoundedCornerShape(11.dp),
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .testTag("restart_quiz_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = strings.newQuiz,
                            fontFamily = uiFont,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // Quiz Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = extended.cardSurface),
                border = BorderStroke(2.dp, extended.gold),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (quizState.isFinished) {
                    val total = quizState.questions.size.coerceAtLeast(1)
                    val stars = when {
                        quizState.score >= 9 -> "⭐⭐⭐"
                        quizState.score >= 6 -> "⭐⭐"
                        else -> "⭐"
                    }
                    val message = if (quizState.score >= 7) strings.quizPassMsg else strings.quizRetryMsg

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(text = stars, fontSize = 40.sp)
                        Text(
                            text = strings.quizCompletedTitle,
                            fontFamily = uiFont,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = extended.arabicAccent
                        )
                        Text(
                            text = strings.quizScoreText(quizState.score, total),
                            fontFamily = uiFont,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = message,
                            fontFamily = uiFont,
                            fontSize = 14.sp,
                            color = extended.mutedText,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = onRestartQuiz,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = extended.gold,
                                    contentColor = Color(0xFF1A1A1A)
                                ),
                                shape = RoundedCornerShape(11.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 48.dp)
                                    .testTag("quiz_retry_button")
                            ) {
                                Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(strings.retryQuiz, fontFamily = uiFont, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = {
                                    val nextId = if (currentLesson.id < allLessons.size) currentLesson.id + 1 else 1
                                    onOpenLesson(nextId)
                                },
                                shape = RoundedCornerShape(11.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 48.dp)
                                    .testTag("quiz_next_lesson_button")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(strings.nextLessonBtn, fontFamily = uiFont, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = onOpenProgress,
                                shape = RoundedCornerShape(11.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 48.dp)
                                    .testTag("quiz_view_progress_button")
                            ) {
                                Icon(Icons.Filled.EmojiEvents, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(strings.viewProgressBtn, fontFamily = uiFont, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else {
                    val q = quizState.questions.getOrNull(quizState.currentIndex)
                    val total = quizState.questions.size.coerceAtLeast(1)
                    if (q != null) {
                        val selectedIdx = quizState.selectedOptionIndex
                        val answered = selectedIdx != null

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${strings.lessonTag(currentLesson.id)}: ${currentLesson.displayTitle(language)}",
                                    fontFamily = uiFont,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = strings.questionCounter(quizState.currentIndex + 1, total, quizState.score),
                                    fontFamily = uiFont,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }

                            LinearProgressIndicator(
                                progress = { quizState.currentIndex.toFloat() / total.toFloat() },
                                color = MaterialTheme.colorScheme.primary,
                                trackColor = extended.cardBorder,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(9.dp)
                                    .clip(RoundedCornerShape(999.dp))
                            )

                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = extended.greenSurface,
                                border = BorderStroke(1.dp, extended.cardBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    if (q.ar.isNotBlank()) {
                                        Text(
                                            text = q.ar,
                                            fontFamily = AmiriFontFamily,
                                            fontSize = 28.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = extended.arabicAccent,
                                            textAlign = TextAlign.Center
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                    }
                                    Text(
                                        text = q.q,
                                        fontFamily = uiFont,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }

                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                q.opts.forEachIndexed { idx, opt ->
                                    val isCorrectOption = idx == q.ans
                                    val isChosenWrong = answered && idx == selectedIdx && !isCorrectOption

                                    val bgColor = when {
                                        answered && isCorrectOption -> CorrectBgLight
                                        isChosenWrong -> WrongBgLight
                                        else -> MaterialTheme.colorScheme.background
                                    }
                                    val borderColor = when {
                                        answered && isCorrectOption -> CorrectBorder
                                        isChosenWrong -> WrongBorder
                                        else -> extended.cardBorder
                                    }
                                    val textColor = when {
                                        answered && isCorrectOption -> CorrectTextLight
                                        isChosenWrong -> WrongTextLight
                                        else -> MaterialTheme.colorScheme.onSurface
                                    }

                                    Surface(
                                        onClick = { if (!answered) onSelectAnswer(idx) },
                                        shape = RoundedCornerShape(12.dp),
                                        color = bgColor,
                                        border = BorderStroke(2.dp, borderColor),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .heightIn(min = 52.dp)
                                            .testTag("quiz_option_$idx")
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 14.dp, vertical = 12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Surface(
                                                shape = RoundedCornerShape(999.dp),
                                                color = MaterialTheme.colorScheme.primary
                                            ) {
                                                Text(
                                                    text = strings.quizOptionLabels.getOrElse(idx) { "${idx + 1}" },
                                                    color = Color.White,
                                                    fontFamily = uiFont,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                                                )
                                            }
                                            Text(
                                                text = opt,
                                                fontFamily = uiFont,
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = textColor,
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                    }
                                }
                            }

                            if (answered) {
                                val isRight = selectedIdx == q.ans
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (isRight) CorrectBgLight else WrongBgLight)
                                        .padding(12.dp)
                                ) {
                                    Text(
                                        text = if (isRight) strings.correctFeedback else strings.wrongFeedback(q.opts[q.ans]),
                                        fontFamily = uiFont,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = if (isRight) CorrectTextLight else WrongTextLight
                                    )
                                }

                                Button(
                                    onClick = onNextQuestion,
                                    shape = RoundedCornerShape(11.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 48.dp)
                                        .testTag("quiz_next_question_button")
                                ) {
                                    Text(
                                        text = if (quizState.currentIndex + 1 >= total) strings.viewResultBtn else strings.nextQuestionBtn,
                                        fontFamily = uiFont,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
