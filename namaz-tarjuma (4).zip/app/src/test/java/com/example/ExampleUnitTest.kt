package com.example

import com.example.data.AzkarData
import com.example.data.LessonRepository
import com.example.model.AppLanguage
import com.example.model.AzkarSection
import com.example.model.GlobalSearchCategory
import com.example.util.PrintShareHelper
import com.example.util.StudyReminderHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class ExampleUnitTest {

    @Test
    fun all17LessonsArePresentAndOrdered() {
        val lessons = LessonRepository.allLessons
        assertEquals(17, lessons.size)
        assertEquals((1..17).toList(), lessons.map { it.id })
        lessons.forEach { lesson ->
            assertTrue("Lesson ${lesson.id} should have lines", lesson.lines.isNotEmpty())
            assertTrue("Lesson ${lesson.id} should have lughat", lesson.lughat.isNotEmpty())
            assertTrue("Lesson ${lesson.id} should have English title", lesson.titleEn.isNotBlank())
            lesson.lines.forEach { line ->
                assertTrue("Lesson ${lesson.id} line should have fullEn", line.fullEn.isNotBlank())
                line.words.forEach { word ->
                    assertTrue("Lesson ${lesson.id} word '${word.ar}' should have English meaning", word.en.isNotBlank())
                }
            }
            lesson.lughat.forEach { lg ->
                assertTrue("Lesson ${lesson.id} lughat '${lg.ar}' should have English meaning", lg.en.isNotBlank())
            }
        }
    }

    @Test
    fun eachLessonGenerates10ValidMcqsTotal170InBothLanguages() {
        var totalUrduQuestions = 0
        var totalEnglishQuestions = 0
        LessonRepository.allLessons.forEach { lesson ->
            val urduQuestions = LessonRepository.build10QuestionsForLesson(lesson, language = AppLanguage.URDU)
            assertEquals("Lesson ${lesson.id} should have 10 Urdu MCQs", 10, urduQuestions.size)
            urduQuestions.forEach { q ->
                assertEquals(4, q.opts.size)
                assertTrue(q.ans in 0..3)
            }
            totalUrduQuestions += urduQuestions.size

            val englishQuestions = LessonRepository.build10QuestionsForLesson(lesson, language = AppLanguage.ENGLISH)
            assertEquals("Lesson ${lesson.id} should have 10 English MCQs", 10, englishQuestions.size)
            englishQuestions.forEach { q ->
                assertEquals(4, q.opts.size)
                assertTrue(q.ans in 0..3)
            }
            totalEnglishQuestions += englishQuestions.size
        }
        assertEquals(170, totalUrduQuestions)
        assertEquals(170, totalEnglishQuestions)
    }

    @Test
    fun arabicRomanUrduAndEnglishSearchFindsMatches() {
        val arabicMatches = LessonRepository.search("رب")
        assertTrue(arabicMatches.isNotEmpty())

        val romanMatches = LessonRepository.search("RABB")
        assertTrue(romanMatches.isNotEmpty())

        val urduMatches = LessonRepository.search("پاک")
        assertTrue(urduMatches.isNotEmpty())

        val englishMatches = LessonRepository.search("Greatest")
        assertTrue(englishMatches.isNotEmpty())

        val janazaMatches = LessonRepository.search("Janaza")
        assertTrue(janazaMatches.any { it.lessonId == 17 })

        val istighfarMatches = LessonRepository.search("استغفر")
        assertTrue(istighfarMatches.any { it.lessonId == 15 })
    }

    @Test
    fun azkarDataSectionsAndJanazaDuasAreOrderedAndComplete() {
        assertTrue(AzkarData.asmaUlHusnaList.size >= 5)
        assertTrue(AzkarData.childrenHadithList.size >= 3)
        assertEquals((1..AzkarData.afterSalahAzkarList.size).toList(), AzkarData.afterSalahAzkarList.map { it.orderNumber })
        assertEquals((1..AzkarData.morningEveningAzkarList.size).toList(), AzkarData.morningEveningAzkarList.map { it.orderNumber })
        assertEquals(listOf(1, 2, 3, 4), AzkarData.janazaDuasList.map { it.orderNumber })
        assertTrue(AzkarData.janazaDuasList[0].arabic.contains("لِحَيِّنَا وَمَيِّتِنَا"))
        assertTrue(AzkarData.janazaDuasList[1].arabic.contains("وَارْحَمْهُ وَعَافِهِ وَاعْفُ عَنْهُ"))
        assertTrue(AzkarData.janazaDuasList[2].arabic.contains("فِيْ ذِمَّتِكَ"))
        assertTrue(AzkarData.janazaDuasList[3].arabic.contains("فَرَطًا"))
        assertTrue(AzkarData.janazaDuasList.none { it.repeatUr.contains("تکبیر") || it.arabic.contains("رَبِّ الْعَالَمِيْنَ") })
        assertTrue(AzkarData.afterSalahAzkarList.first().arabic.contains("أَسْتَغْفِرُ"))
        val janazaLesson = LessonRepository.getLesson(17)
        assertTrue(janazaLesson.lines.any { it.words.any { w -> w.ar.contains("وَاعْفُ عَنْهُ") } })
        assertTrue(janazaLesson.lines.none { it.label.contains("تکبیر") || it.label.contains("سورۃ الفاتحہ") })
    }

    @Test
    fun mergeLessonsOverridesBuiltInAndAppendsCustom() {
        val editedLesson1 = LessonRepository.getLesson(1).copy(titleUr = "تکبیرِ تحریمہ (ترمیم شدہ)")
        val customLesson18 = LessonRepository.getLesson(1).copy(
            id = 18,
            titleUr = "نیا سبق",
            titleEn = "Custom Lesson 18",
            isCustom = true
        )
        val merged = LessonRepository.mergeLessons(mapOf(1 to editedLesson1, 18 to customLesson18))
        assertEquals(18, merged.size)
        assertEquals("تکبیرِ تحریمہ (ترمیم شدہ)", merged.first().titleUr)
        assertEquals(18, merged.last().id)
        assertTrue(merged.last().isCustom)
    }

    @Test
    fun quickQuizSelects5ValidQuestionsFrom170BankInBothLanguages() {
        val urduQuick = LessonRepository.buildQuickQuizQuestions(language = AppLanguage.URDU)
        assertEquals(5, urduQuick.size)
        urduQuick.forEach { item ->
            assertTrue(item.lessonId in 1..17)
            assertEquals(4, item.question.opts.size)
            assertTrue(item.question.ans in 0..3)
        }

        val englishQuick = LessonRepository.buildQuickQuizQuestions(language = AppLanguage.ENGLISH)
        assertEquals(5, englishQuick.size)
        englishQuick.forEach { item ->
            assertTrue(item.lessonId in 1..17)
            assertEquals(4, item.question.opts.size)
            assertTrue(item.question.ans in 0..3)
        }
    }

    @Test
    fun appShareMessageIncludesUpdatedNoorEKashifContacts() {
        val message = PrintShareHelper.buildAppShareMessage()
        assertTrue(message.contains("نورِ کاشف"))
        assertTrue(message.contains("حافظ کاشف منیر بدر"))
        assertTrue(message.contains("+923036620170"))
        assertTrue(message.contains("kashifmunirbadr6620@gmail.com"))
    }

    @Test
    fun studyReminderSchedulesNextOccurrenceAndBuildsProgressText() {
        val baseCal = Calendar.getInstance().apply {
            set(2026, Calendar.NOVEMBER, 22, 10, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val sameDayTrigger = StudyReminderHelper.computeNextTriggerMillis(18, 30, baseCal.timeInMillis)
        val sameDayCal = Calendar.getInstance().apply { timeInMillis = sameDayTrigger }
        assertEquals(22, sameDayCal.get(Calendar.DAY_OF_MONTH))
        assertEquals(18, sameDayCal.get(Calendar.HOUR_OF_DAY))
        assertEquals(30, sameDayCal.get(Calendar.MINUTE))

        val nextDayTrigger = StudyReminderHelper.computeNextTriggerMillis(8, 0, baseCal.timeInMillis)
        val nextDayCal = Calendar.getInstance().apply { timeInMillis = nextDayTrigger }
        assertEquals(23, nextDayCal.get(Calendar.DAY_OF_MONTH))
        assertEquals(8, nextDayCal.get(Calendar.HOUR_OF_DAY))

        val (enTitle, enBody) = StudyReminderHelper.buildReminderNotificationContent(
            completedCount = 5,
            totalCount = 17,
            nextLessonTitle = "Surah Al-Fatihah",
            language = AppLanguage.ENGLISH
        )
        assertTrue(enTitle.contains("Study Reminder"))
        assertTrue(enBody.contains("5 / 17") && enBody.contains("12 remaining") && enBody.contains("Surah Al-Fatihah"))

        val (_, urDoneBody) = StudyReminderHelper.buildReminderNotificationContent(
            completedCount = 17,
            totalCount = 17,
            nextLessonTitle = "نمازِ جنازہ",
            language = AppLanguage.URDU
        )
        assertTrue(urDoneBody.contains("17") && urDoneBody.contains("نمازِ جنازہ"))
        assertEquals("6:30 PM", StudyReminderHelper.formatTimeDisplay(18, 30, AppLanguage.ENGLISH))
    }

    @Test
    fun globalSearchFindsLessonsDuasAndAhadeesByKeyword() {
        // 1. Cross-category keyword "Janaza" / "جنازہ" finds both Lesson 17 and Janaza Duas
        val janazaAll = LessonRepository.searchAll("Janaza")
        assertTrue(janazaAll.any { it.category == GlobalSearchCategory.LESSON && it.lessonId == 17 })
        assertTrue(janazaAll.any { it.category == GlobalSearchCategory.DUA && it.azkarSection == AzkarSection.JANAZA_DUAS })

        // 2. Specific Dua Arabic keyword without diacritics resolves to exact Janaza Dua #4 (index 3)
        val childJanazaDua = LessonRepository.searchAll("فرطا", category = GlobalSearchCategory.DUA)
        assertTrue(childJanazaDua.isNotEmpty())
        val firstJanaza = childJanazaDua.first { it.azkarSection == AzkarSection.JANAZA_DUAS }
        assertEquals(3, firstJanaza.azkarItemIndex)

        // 3. Hadith keyword finds exact Ahadees & respects category filtering
        val bukhariOnly = LessonRepository.searchAll("Bukhari", category = GlobalSearchCategory.HADITH)
        assertTrue(bukhariOnly.isNotEmpty())
        assertTrue(bukhariOnly.all { it.category == GlobalSearchCategory.HADITH && it.azkarSection == AzkarSection.AHADEES })
        assertTrue(bukhariOnly.any { it.azkarItemIndex == 0 })

        val intentionsHadith = LessonRepository.searchAll("intentions")
        assertTrue(intentionsHadith.any { it.category == GlobalSearchCategory.HADITH && it.azkarItemIndex == 0 })

        // 4. Morning/Evening Dua and After Salah Dua search
        val morningDuas = LessonRepository.searchAll("morning", category = GlobalSearchCategory.DUA)
        assertTrue(morningDuas.any { it.azkarSection == AzkarSection.MORNING_EVENING })

        val istighfarDuas = LessonRepository.searchAll("Istighfar", category = GlobalSearchCategory.DUA)
        assertTrue(istighfarDuas.any { it.azkarSection == AzkarSection.SALAH_AZKAR && it.azkarItemIndex == 0 })

        // 5. Category filter isolation
        val lessonOnly = LessonRepository.searchAll("Allah", category = GlobalSearchCategory.LESSON)
        assertTrue(lessonOnly.isNotEmpty())
        assertTrue(lessonOnly.all { it.category == GlobalSearchCategory.LESSON && it.lessonId != null })

        // 6. Blank query returns empty
        assertTrue(LessonRepository.searchAll("   ").isEmpty())
    }
}
