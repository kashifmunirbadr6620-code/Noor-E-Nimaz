package com.example.model

enum class AppLanguage(val code: String) {
    URDU("ur"),
    ENGLISH("en");

    companion object {
        fun fromCode(code: String?): AppLanguage =
            if (code == ENGLISH.code) ENGLISH else URDU
    }
}

data class WordItem(
    val ar: String,
    val ur: String,
    val pron: String,
    val en: String = ""
) {
    fun meaning(language: AppLanguage): String =
        if (language == AppLanguage.ENGLISH) en.ifBlank { ur } else ur
}

data class LessonLine(
    val label: String,
    val words: List<WordItem>,
    val fullUr: String,
    val labelEn: String = "",
    val fullEn: String = ""
) {
    fun displayLabel(language: AppLanguage): String =
        if (language == AppLanguage.ENGLISH) labelEn.ifBlank { label } else label

    fun fullTranslation(language: AppLanguage): String =
        if (language == AppLanguage.ENGLISH) fullEn.ifBlank { fullUr } else fullUr
}

data class LughatItem(
    val ar: String,
    val ur: String,
    val en: String = ""
) {
    fun meaning(language: AppLanguage): String =
        if (language == AppLanguage.ENGLISH) en.ifBlank { ur } else ur
}

data class QuizQuestion(
    val q: String,
    val ar: String,
    val opts: List<String>,
    val ans: Int
)

data class QuickQuizItem(
    val lessonId: Int,
    val lessonTitleUr: String,
    val lessonTitleEn: String,
    val question: QuizQuestion
) {
    fun displayLessonTitle(language: AppLanguage): String =
        if (language == AppLanguage.ENGLISH) lessonTitleEn.ifBlank { lessonTitleUr } else lessonTitleUr
}

data class Lesson(
    val id: Int,
    val titleUr: String,
    val titleEn: String,
    val romanKeys: String,
    val lines: List<LessonLine>,
    val lughat: List<LughatItem>,
    val customQuiz: List<QuizQuestion>? = null,
    val isCustom: Boolean = false
) {
    fun displayTitle(language: AppLanguage): String =
        if (language == AppLanguage.ENGLISH) titleEn.ifBlank { titleUr } else titleUr
}

data class SearchMatch(
    val lessonId: Int,
    val lessonTitleUr: String,
    val lessonTitleEn: String,
    val ar: String,
    val ur: String,
    val en: String,
    val pron: String
) {
    fun displayLessonTitle(language: AppLanguage): String =
        if (language == AppLanguage.ENGLISH) lessonTitleEn.ifBlank { lessonTitleUr } else lessonTitleUr

    fun displayMeaning(language: AppLanguage): String =
        if (language == AppLanguage.ENGLISH) en.ifBlank { ur } else ur
}

enum class GlobalSearchCategory {
    ALL,
    LESSON,
    DUA,
    HADITH
}

data class GlobalSearchMatch(
    val id: String,
    val category: GlobalSearchCategory,
    val titleUr: String,
    val titleEn: String,
    val arabic: String,
    val meaningUr: String,
    val meaningEn: String,
    val subtitleUr: String = "",
    val subtitleEn: String = "",
    val lessonId: Int? = null,
    val azkarSection: AzkarSection? = null,
    val azkarItemIndex: Int? = null
) {
    fun displayTitle(language: AppLanguage): String =
        if (language == AppLanguage.ENGLISH) titleEn.ifBlank { titleUr } else titleUr

    fun displayMeaning(language: AppLanguage): String =
        if (language == AppLanguage.ENGLISH) meaningEn.ifBlank { meaningUr } else meaningUr

    fun displaySubtitle(language: AppLanguage): String =
        if (language == AppLanguage.ENGLISH) subtitleEn.ifBlank { subtitleUr } else subtitleUr
}

data class UserProgressState(
    val completedLessons: Set<Int> = emptySet(),
    val quizScores: Map<Int, Int> = emptyMap(),
    val darkMode: Boolean = false,
    val bigFont: Boolean = false,
    val lastLessonId: Int = 1,
    val language: AppLanguage = AppLanguage.URDU,
    val tasbeehCount: Int = 0,
    val reminderEnabled: Boolean = false,
    val reminderHour: Int = 18,
    val reminderMinute: Int = 0
)

enum class AppTab(val route: String) {
    HOME("home"),
    LEARN("learn"),
    QUIZ("quiz"),
    PROGRESS("progress"),
    EDITOR("editor"),
    AZKAR("azkar")
}

enum class AzkarSection {
    ASMA_UL_HUSNA,
    AHADEES,
    SALAH_AZKAR,
    MORNING_EVENING,
    JANAZA_DUAS,
    TASBEEH_COUNTER
}

data class AsmaUlHusnaItem(
    val number: Int,
    val arabic: String,
    val nameUr: String,
    val nameEn: String,
    val meaningUr: String,
    val meaningEn: String
)

data class HadithItem(
    val number: Int,
    val arabic: String,
    val translationUr: String,
    val translationEn: String,
    val refUr: String,
    val refEn: String
)

data class ZikrItem(
    val orderNumber: Int,
    val arabic: String,
    val speakText: String,
    val repeatUr: String,
    val repeatEn: String,
    val translationUr: String,
    val translationEn: String,
    val refUr: String,
    val refEn: String
)

enum class EditorMode {
    APP_EDITOR,
    LESSON_EDITOR
}

enum class AppThemePreset(
    val id: String,
    val primaryHex: Long,
    val primaryDarkHex: Long,
    val surfaceLightHex: Long,
    val primaryNightHex: Long,
    val goldHex: Long,
    val titleUr: String,
    val titleEn: String
) {
    EMERALD_GOLD(
        id = "emerald",
        primaryHex = 0xFF0F5D4A,
        primaryDarkHex = 0xFF093E31,
        surfaceLightHex = 0xFFE8F5F1,
        primaryNightHex = 0xFF2EA887,
        goldHex = 0xFFC9A227,
        titleUr = "زمرد و سنہری",
        titleEn = "Emerald Gold"
    ),
    ROYAL_TEAL(
        id = "teal",
        primaryHex = 0xFF0E5A6D,
        primaryDarkHex = 0xFF083946,
        surfaceLightHex = 0xFFE6F4F8,
        primaryNightHex = 0xFF38BDF8,
        goldHex = 0xFFD4A338,
        titleUr = "مدینہ ٹیل",
        titleEn = "Madina Teal"
    ),
    KAABA_CHARCOAL(
        id = "kaaba",
        primaryHex = 0xFF23272F,
        primaryDarkHex = 0xFF14171C,
        surfaceLightHex = 0xFFF1F2F4,
        primaryNightHex = 0xFFD9A426,
        goldHex = 0xFFD9A426,
        titleUr = "کعبہ گولڈ",
        titleEn = "Kaaba Gold"
    ),
    OLIVE_HERITAGE(
        id = "olive",
        primaryHex = 0xFF3E5C29,
        primaryDarkHex = 0xFF273B18,
        surfaceLightHex = 0xFFEFF5E9,
        primaryNightHex = 0xFF84CC16,
        goldHex = 0xFFC69214,
        titleUr = "زیتون و بادامی",
        titleEn = "Olive Heritage"
    ),
    SAPPHIRE_INK(
        id = "sapphire",
        primaryHex = 0xFF1E3A8A,
        primaryDarkHex = 0xFF172554,
        surfaceLightHex = 0xFFEBF2FF,
        primaryNightHex = 0xFF60A5FA,
        goldHex = 0xFFD9A426,
        titleUr = "نیلم و طلائی",
        titleEn = "Sapphire Ink"
    );

    companion object {
        fun fromId(id: String?): AppThemePreset =
            entries.find { it.id == id } ?: EMERALD_GOLD
    }
}

data class AppCustomization(
    val schoolNameUr: String = DEFAULT_SCHOOL_UR,
    val schoolNameEn: String = DEFAULT_SCHOOL_EN,
    val appTitleUr: String = DEFAULT_APP_TITLE_UR,
    val appTitleEn: String = DEFAULT_APP_TITLE_EN,
    val heroSubtitleUr: String = DEFAULT_HERO_SUBTITLE_UR,
    val heroSubtitleEn: String = DEFAULT_HERO_SUBTITLE_EN,
    val themePreset: AppThemePreset = AppThemePreset.EMERALD_GOLD,
    val fontScale: Float = 1.0f,
    val ttsSpeed: Float = 0.82f,
    val showPronunciationInBoxes: Boolean = false,
    val showSecondaryTitle: Boolean = true
) {
    fun displaySchoolHeader(language: AppLanguage): String =
        if (language == AppLanguage.ENGLISH) {
            schoolNameEn.ifBlank { DEFAULT_SCHOOL_EN }
        } else {
            schoolNameUr.ifBlank { DEFAULT_SCHOOL_UR }
        }

    fun displayAppTitle(language: AppLanguage): String =
        if (language == AppLanguage.ENGLISH) {
            appTitleEn.ifBlank { DEFAULT_APP_TITLE_EN }
        } else {
            appTitleUr.ifBlank { DEFAULT_APP_TITLE_UR }
        }

    fun displayHeroSubtitle(language: AppLanguage): String =
        if (language == AppLanguage.ENGLISH) {
            heroSubtitleEn.ifBlank { DEFAULT_HERO_SUBTITLE_EN }
        } else {
            heroSubtitleUr.ifBlank { DEFAULT_HERO_SUBTITLE_UR }
        }

    companion object {
        const val DEFAULT_SCHOOL_UR = "جی آر ایس میموریل ہائی اسکول • GRS Memorial High School"
        const val DEFAULT_SCHOOL_EN = "GRS Memorial High School"
        const val DEFAULT_APP_TITLE_UR = "نماز ترجمہ — آسان اسلامی تعلیم"
        const val DEFAULT_APP_TITLE_EN = "Namaz Tarjuma — Easy Islamic Learning"
        const val DEFAULT_HERO_SUBTITLE_UR = "کلاس اول تا دہم اور مدرسہ کے طلبہ کے لیے لفظ بہ لفظ نماز ترجمہ"
        const val DEFAULT_HERO_SUBTITLE_EN = "Word-by-word Namaz translation for Class 1–10 & Madrasa students"
    }
}

