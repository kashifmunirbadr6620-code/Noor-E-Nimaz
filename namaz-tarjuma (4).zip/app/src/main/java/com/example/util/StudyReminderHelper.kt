package com.example.util

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.model.AppLanguage
import com.example.model.Lesson
import java.util.Calendar

object StudyReminderHelper {

    const val CHANNEL_ID = "namaz_daily_study_reminder"
    const val NOTIFICATION_ID = 7861
    const val REMINDER_REQUEST_CODE = 7862

    fun hasNotificationPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun computeNextTriggerMillis(
        hour: Int,
        minute: Int,
        nowMillis: Long = System.currentTimeMillis()
    ): Long {
        val safeHour = hour.coerceIn(0, 23)
        val safeMinute = minute.coerceIn(0, 59)
        val cal = Calendar.getInstance().apply {
            timeInMillis = nowMillis
            set(Calendar.HOUR_OF_DAY, safeHour)
            set(Calendar.MINUTE, safeMinute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= nowMillis) {
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return cal.timeInMillis
    }

    fun formatTimeDisplay(hour: Int, minute: Int, language: AppLanguage): String {
        val safeHour = hour.coerceIn(0, 23)
        val safeMinute = minute.coerceIn(0, 59)
        val isPm = safeHour >= 12
        val hour12 = when {
            safeHour == 0 -> 12
            safeHour > 12 -> safeHour - 12
            else -> safeHour
        }
        val minPadded = safeMinute.toString().padStart(2, '0')
        return if (language == AppLanguage.ENGLISH) {
            val suffix = if (isPm) "PM" else "AM"
            "$hour12:$minPadded $suffix"
        } else {
            val periodUr = when {
                safeHour in 4..11 -> "صبح"
                safeHour in 12..15 -> "دوپہر"
                safeHour in 16..19 -> "شام"
                else -> "رات"
            }
            "$periodUr $hour12:$minPadded"
        }
    }

    fun pickNextLessonTitle(
        lessons: List<Lesson>,
        completedLessons: Set<Int>,
        lastLessonId: Int,
        language: AppLanguage
    ): String {
        val nextUncompleted = lessons.firstOrNull { !completedLessons.contains(it.id) }
            ?: lessons.find { it.id == lastLessonId }
            ?: lessons.firstOrNull()
        return nextUncompleted?.displayTitle(language)
            ?: if (language == AppLanguage.ENGLISH) "Namaz Lesson" else "نماز سبق"
    }

    fun buildReminderNotificationContent(
        completedCount: Int,
        totalCount: Int,
        nextLessonTitle: String,
        language: AppLanguage
    ): Pair<String, String> {
        val safeTotal = totalCount.coerceAtLeast(1)
        val safeDone = completedCount.coerceIn(0, safeTotal)
        val remaining = (safeTotal - safeDone).coerceAtLeast(0)

        return if (safeDone >= safeTotal) {
            if (language == AppLanguage.ENGLISH) {
                "Namaz Tarjuma — Daily Review Time" to
                    "MashaAllah! All $safeTotal lessons completed — review \"$nextLessonTitle\" today."
            } else {
                "نماز ترجمہ — روزانہ دہرائی کا وقت" to
                    "ماشاء اللہ! آپ نے تمام $safeTotal اسباق مکمل کر لیے ہیں — آج «$nextLessonTitle» دہرائیں۔"
            }
        } else {
            if (language == AppLanguage.ENGLISH) {
                "Namaz Tarjuma — Daily Study Reminder" to
                    "Progress: $safeDone / $safeTotal lessons completed ($remaining remaining). Tap to study \"$nextLessonTitle\"!"
            } else {
                "نماز ترجمہ — روزانہ سبق کا وقت" to
                    "پیشرفت: $safeDone / $safeTotal اسباق مکمل ($remaining باقی) • آج «$nextLessonTitle» پڑھیں!"
            }
        }
    }

    fun ensureNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            val existing = manager.getNotificationChannel(CHANNEL_ID)
            if (existing != null) return
            val channel = NotificationChannel(
                CHANNEL_ID,
                context.getString(R.string.reminder_channel_name),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = context.getString(R.string.reminder_channel_desc)
            }
            manager.createNotificationChannel(channel)
        }
    }

    fun scheduleDailyReminder(context: Context, hour: Int, minute: Int) {
        ensureNotificationChannel(context)
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val pendingIntent = buildReminderPendingIntent(context)
        val triggerAtMillis = computeNextTriggerMillis(hour, minute)
        // Use Doze-friendly inexact alarm (no SCHEDULE_EXACT_ALARM special permission required)
        alarmManager.setAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            triggerAtMillis,
            pendingIntent
        )
    }

    fun cancelDailyReminder(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val pendingIntent = buildReminderPendingIntent(context)
        alarmManager.cancel(pendingIntent)
        pendingIntent.cancel()
    }

    fun showStudyReminderNotification(
        context: Context,
        completedCount: Int,
        totalCount: Int,
        nextLessonTitle: String,
        language: AppLanguage
    ): Boolean {
        if (!hasNotificationPermission(context)) return false
        ensureNotificationChannel(context)

        val (title, body) = buildReminderNotificationContent(
            completedCount = completedCount,
            totalCount = totalCount,
            nextLessonTitle = nextLessonTitle,
            language = language
        )

        val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            context,
            NOTIFICATION_ID,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification_reminder)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(contentPendingIntent)
            .build()

        return try {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
            true
        } catch (_: SecurityException) {
            false
        }
    }

    private fun buildReminderPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, StudyReminderReceiver::class.java)
        return PendingIntent.getBroadcast(
            context,
            REMINDER_REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
