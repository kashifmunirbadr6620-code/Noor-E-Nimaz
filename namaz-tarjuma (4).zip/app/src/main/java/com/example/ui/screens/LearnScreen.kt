package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppCustomization
import com.example.model.AppLanguage
import com.example.model.Lesson
import com.example.model.LessonLine
import com.example.model.WordItem
import com.example.ui.LearnUiState
import com.example.ui.UiStrings
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.theme.LocalNamazColors
import com.example.ui.theme.LocalNamazFontSizes
import com.example.ui.theme.RomanFontFamily
import com.example.ui.theme.UrduFontFamily

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LearnScreen(
    language: AppLanguage,
    strings: UiStrings,
    appConfig: AppCustomization,
    allLessons: List<Lesson>,
    currentLesson: Lesson,
    learnState: LearnUiState,
    isCompleted: Boolean,
    isSpeaking: Boolean,
    activeSpeakingLineIndex: Int?,
    onSelectLesson: (Int) -> Unit,
    onPrevLesson: () -> Unit,
    onNextLesson: () -> Unit,
    onToggleAudio: () -> Unit,
    onSpeakLine: (String, Int) -> Unit,
    onToggleHideTarjuma: () -> Unit,
    onToggleMemoMode: () -> Unit,
    onChangeMemoLine: (Int) -> Unit,
    onToggleLessonComplete: () -> Unit,
    onStartQuiz: (Int) -> Unit,
    onPrintLesson: (Lesson) -> Unit,
    onShareLesson: (Lesson) -> Unit,
    onInspectWord: (WordItem, String) -> Unit,
    onSpeakInspectedWord: () -> Unit,
    onCloseInspector: () -> Unit,
    modifier: Modifier = Modifier
) {
    val extended = LocalNamazColors.current
    val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily
    var dropdownExpanded by remember { mutableStateOf(false) }

    val linesToShow: List<Pair<Int, LessonLine>> = if (learnState.memoMode) {
        val safeIdx = learnState.memoLineIndex.coerceIn(0, (currentLesson.lines.size - 1).coerceAtLeast(0))
        listOf(safeIdx to currentLesson.lines[safeIdx])
    } else {
        currentLesson.lines.mapIndexed { index, line -> index to line }
    }

    LazyColumn(
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = modifier.fillMaxSize()
    ) {
        // Navigation & Action Toolbar
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = extended.cardSurface),
                border = BorderStroke(1.dp, extended.cardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = onPrevLesson,
                            shape = RoundedCornerShape(11.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("prev_lesson_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = strings.prevShort,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = strings.prevShort,
                                fontFamily = uiFont,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Box(modifier = Modifier.weight(1f)) {
                            Surface(
                                onClick = { dropdownExpanded = true },
                                shape = RoundedCornerShape(11.dp),
                                color = MaterialTheme.colorScheme.background,
                                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 48.dp)
                                    .testTag("lesson_dropdown_button")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${strings.lessonTag(currentLesson.id)}: ${currentLesson.displayTitle(language)}",
                                        fontFamily = uiFont,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Icon(
                                        imageVector = Icons.Filled.ArrowDropDown,
                                        contentDescription = null
                                    )
                                }
                            }

                            DropdownMenu(
                                expanded = dropdownExpanded,
                                onDismissRequest = { dropdownExpanded = false }
                            ) {
                                allLessons.forEach { item ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                text = "${strings.lessonTag(item.id)}: ${item.displayTitle(language)}",
                                                fontFamily = uiFont,
                                                fontWeight = if (item.id == currentLesson.id) FontWeight.Bold else FontWeight.Normal
                                            )
                                        },
                                        onClick = {
                                            dropdownExpanded = false
                                            onSelectLesson(item.id)
                                        }
                                    )
                                }
                            }
                        }

                        Button(
                            onClick = onNextLesson,
                            shape = RoundedCornerShape(11.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("next_lesson_button")
                        ) {
                            Text(
                                text = strings.nextShort,
                                fontFamily = uiFont,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = strings.nextShort,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onToggleAudio,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSpeaking) extended.redMeaning else MaterialTheme.colorScheme.primary
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("audio_recitation_button")
                        ) {
                            Icon(
                                imageVector = if (isSpeaking) Icons.Filled.Stop else Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = if (isSpeaking) strings.stopAudio else strings.listenAudio,
                                fontFamily = uiFont,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = onToggleHideTarjuma,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = extended.gold,
                                contentColor = Color(0xFF1A1A1A)
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("hide_tarjuma_button")
                        ) {
                            Icon(
                                imageVector = if (learnState.hideTarjuma) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = if (learnState.hideTarjuma) strings.showTarjuma else strings.hideTarjuma,
                                fontFamily = uiFont,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = onToggleMemoMode,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (learnState.memoMode) extended.gold else Color(0xFF1D4ED8),
                                contentColor = if (learnState.memoMode) Color(0xFF1A1A1A) else Color.White
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("memo_mode_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Psychology,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = if (learnState.memoMode) strings.bookMode else strings.memoMode,
                                fontFamily = uiFont,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (isCompleted) {
                            Button(
                                onClick = onToggleLessonComplete,
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .testTag("complete_lesson_button")
                            ) {
                                Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(strings.markedComplete, fontFamily = uiFont, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            OutlinedButton(
                                onClick = onToggleLessonComplete,
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .testTag("complete_lesson_button")
                            ) {
                                Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(strings.markComplete, fontFamily = uiFont, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        OutlinedButton(
                            onClick = { onStartQuiz(currentLesson.id) },
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("learn_quiz_button")
                        ) {
                            Icon(Icons.Filled.Quiz, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(strings.quizAction, fontFamily = uiFont, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { onPrintLesson(currentLesson) },
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("print_lesson_button")
                        ) {
                            Icon(Icons.Filled.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(strings.printAction, fontFamily = uiFont, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { onShareLesson(currentLesson) },
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("share_lesson_button")
                        ) {
                            Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(strings.shareAction, fontFamily = uiFont, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Interactive Word Inspector Card
        item {
            AnimatedVisibility(visible = learnState.inspectedWord != null) {
                val word = learnState.inspectedWord
                if (word != null) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(2.dp, extended.gold),
                        colors = CardDefaults.cardColors(containerColor = extended.goldLight),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("word_inspector_card")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(extended.goldLight, extended.cardSurface)
                                    )
                                )
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = extended.cardSurface,
                                    border = BorderStroke(1.dp, extended.gold)
                                ) {
                                    Text(
                                        text = word.ar,
                                        fontFamily = AmiriFontFamily,
                                        fontSize = 28.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = extended.arabicAccent,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${strings.meaningPrefix}${word.meaning(language)}",
                                        fontFamily = uiFont,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = extended.redMeaning
                                    )
                                    if (word.pron.isNotBlank()) {
                                        Text(
                                            text = "${strings.pronPrefix}${word.pron}",
                                            fontFamily = UrduFontFamily,
                                            fontSize = 13.sp,
                                            color = extended.mutedText
                                        )
                                    }
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = onSpeakInspectedWord,
                                    modifier = Modifier.testTag("speak_inspected_word_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                        contentDescription = strings.listenAudio,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                                IconButton(
                                    onClick = onCloseInspector,
                                    modifier = Modifier.testTag("close_inspector_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Close,
                                        contentDescription = "Close"
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Textbook Book Page Container
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = extended.cardSurface),
                border = BorderStroke(2.dp, extended.gold),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "${strings.lessonTag(currentLesson.id)}: ${currentLesson.displayTitle(language)}",
                            fontFamily = uiFont,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = extended.arabicAccent,
                            textAlign = TextAlign.Center
                        )
                        if (appConfig.showSecondaryTitle) {
                            Text(
                                text = if (language == AppLanguage.ENGLISH) currentLesson.titleUr else currentLesson.titleEn,
                                fontFamily = if (language == AppLanguage.ENGLISH) UrduFontFamily else RomanFontFamily,
                                fontSize = 13.sp,
                                color = extended.mutedText,
                                textAlign = TextAlign.Center
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = strings.tapWordTip,
                            fontFamily = uiFont,
                            fontSize = 12.sp,
                            color = extended.mutedText,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = extended.gold.copy(alpha = 0.6f), thickness = 1.5.dp)
                    }

                    linesToShow.forEach { (realIndex, line) ->
                        val isLineSpeaking = isSpeaking && activeSpeakingLineIndex == realIndex
                        LineBlockCard(
                            language = language,
                            strings = strings,
                            showPronunciationInBox = appConfig.showPronunciationInBoxes,
                            line = line,
                            realIndex = realIndex,
                            hideTarjuma = learnState.hideTarjuma,
                            isLineSpeaking = isLineSpeaking,
                            inspectedWordId = learnState.inspectedWordId,
                            memoMode = learnState.memoMode,
                            memoLineIndex = learnState.memoLineIndex,
                            totalLines = currentLesson.lines.size,
                            onSpeakLine = {
                                val lineAr = line.words.joinToString(" ") { it.ar }
                                onSpeakLine(lineAr, realIndex)
                            },
                            onInspectWord = onInspectWord,
                            onChangeMemoLine = onChangeMemoLine
                        )
                    }

                    if (!learnState.memoMode) {
                        LughatFooterCard(
                            language = language,
                            strings = strings,
                            lesson = currentLesson
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun LineBlockCard(
    language: AppLanguage,
    strings: UiStrings,
    showPronunciationInBox: Boolean,
    line: LessonLine,
    realIndex: Int,
    hideTarjuma: Boolean,
    isLineSpeaking: Boolean,
    inspectedWordId: String?,
    memoMode: Boolean,
    memoLineIndex: Int,
    totalLines: Int,
    onSpeakLine: () -> Unit,
    onInspectWord: (WordItem, String) -> Unit,
    onChangeMemoLine: (Int) -> Unit
) {
    val extended = LocalNamazColors.current
    val fontSizes = LocalNamazFontSizes.current
    val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily
    val borderColor = if (isLineSpeaking) extended.gold else extended.cardBorder
    val borderWidth = if (isLineSpeaking) 2.dp else 1.dp

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.background,
        border = BorderStroke(borderWidth, borderColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = extended.greenSurface
                ) {
                    Text(
                        text = line.displayLabel(language),
                        color = extended.arabicAccent,
                        fontFamily = uiFont,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                OutlinedButton(
                    onClick = onSpeakLine,
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier
                        .heightIn(min = 48.dp)
                        .testTag("speak_line_button_$realIndex")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = strings.listenLine,
                        fontFamily = uiFont,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Arabic words ALWAYS flow right-to-left for authentic Arabic reading order
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    line.words.forEachIndexed { wordIndex, word ->
                        val wordId = "wbox_${realIndex}_$wordIndex"
                        val isSelected = inspectedWordId == wordId

                        Surface(
                            onClick = { onInspectWord(word, wordId) },
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) extended.goldLight else extended.cardSurface,
                            border = BorderStroke(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) extended.gold else extended.cardBorder
                            ),
                            shadowElevation = 1.dp,
                            modifier = Modifier
                                .widthIn(min = 82.dp)
                                .testTag(wordId)
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = word.ar,
                                    fontFamily = AmiriFontFamily,
                                    fontSize = fontSizes.arabicWordSize,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                HorizontalDivider(color = extended.cardBorder)
                                Spacer(modifier = Modifier.height(6.dp))
                                if (hideTarjuma) {
                                    Box(
                                        modifier = Modifier
                                            .width(64.dp)
                                            .height(18.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(extended.cardBorder)
                                    )
                                } else {
                                    Text(
                                        text = word.meaning(language),
                                        fontFamily = uiFont,
                                        fontSize = fontSizes.wordUrduSize,
                                        fontWeight = FontWeight.Bold,
                                        color = extended.redMeaning,
                                        textAlign = TextAlign.Center
                                    )
                                    if (showPronunciationInBox && word.pron.isNotBlank()) {
                                        Text(
                                            text = word.pron,
                                            fontFamily = UrduFontFamily,
                                            fontSize = 11.sp,
                                            color = extended.mutedText,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Full Translation Blue Box
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(extended.blueBg)
            ) {
                Box(
                    modifier = Modifier
                        .width(5.dp)
                        .heightIn(min = 52.dp)
                        .background(extended.blueBorder)
                )
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = extended.blueBorder
                    ) {
                        Text(
                            text = strings.fullTarjumaBadge,
                            color = Color.White,
                            fontFamily = uiFont,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (hideTarjuma) strings.hiddenPlaceholder else line.fullTranslation(language),
                        fontFamily = uiFont,
                        fontSize = if (hideTarjuma) 13.sp else fontSizes.fullUrduSize,
                        fontWeight = FontWeight.Bold,
                        color = extended.blueText
                    )
                }
            }

            if (memoMode) {
                HorizontalDivider(color = extended.cardBorder)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { onChangeMemoLine(-1) },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .testTag("memo_prev_line_button")
                    ) {
                        Text(
                            text = strings.prevLine,
                            fontFamily = uiFont,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Text(
                        text = strings.memoStepLabel(memoLineIndex + 1, totalLines),
                        fontFamily = uiFont,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )

                    Button(
                        onClick = { onChangeMemoLine(1) },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .testTag("memo_next_line_button")
                    ) {
                        Text(
                            text = strings.nextLine,
                            fontFamily = uiFont,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LughatFooterCard(
    language: AppLanguage,
    strings: UiStrings,
    lesson: Lesson
) {
    val extended = LocalNamazColors.current
    val uiFont = if (language == AppLanguage.ENGLISH) RomanFontFamily else UrduFontFamily
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = extended.cardSurface,
        border = BorderStroke(2.dp, extended.greenHeader),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(extended.greenHeader)
                    .padding(horizontal = 14.dp, vertical = 9.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = strings.lughatHeader,
                    color = Color.White,
                    fontFamily = uiFont,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = strings.lessonTag(lesson.id),
                    color = Color.White.copy(alpha = 0.9f),
                    fontFamily = uiFont,
                    fontSize = 12.sp
                )
            }

            lesson.lughat.forEachIndexed { index, item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 9.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = item.ar,
                        fontFamily = AmiriFontFamily,
                        fontSize = 21.sp,
                        fontWeight = FontWeight.Bold,
                        color = extended.arabicAccent
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = item.meaning(language),
                        fontFamily = uiFont,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.End,
                        modifier = Modifier.weight(1f)
                    )
                }
                if (index < lesson.lughat.lastIndex) {
                    HorizontalDivider(color = extended.cardBorder)
                }
            }
        }
    }
}
